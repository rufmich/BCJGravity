(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
<|"Graph" -> {{-1}, {-2}, {-3}, {-4}, {-65, -6, -5}, {-66, 2, 1}, 
   {66, -7, 65}, {3, 7, 70}, {-70, 71, 6}, {-71, 5, 4}}, 
 "momCons" -> {k[4] -> -k[1] - k[2] - k[3], 
   k[7] -> k[1] + k[2] - k[5] - k[6], k[65] -> -k[5] - k[6], 
   k[66] -> k[1] + k[2], k[70] -> -k[1] - k[2] - k[3] + k[5] + k[6], 
   k[71] -> -k[1] - k[2] - k[3] + k[5]}, "cutLines" -> k[5, 6, 7], 
 "extraOS" -> <|d[k[1], k[1]] :> 0, d[ep[1], k[1]] :> 0, 
   d[epT[1], k[1]] :> 0, d[k[2], k[2]] :> 0, d[ep[2], k[2]] :> 0, 
   d[epT[2], k[2]] :> 0, d[k[3], k[3]] :> 0, d[ep[3], k[3]] :> 0, 
   d[epT[3], k[3]] :> 0, d[k[4], k[4]] :> 0, d[ep[4], k[4]] :> 0, 
   d[epT[4], k[4]] :> 0, d[k[1], k[3]] :> -d[k[1], k[2]] - d[k[2], k[3]], 
   d[ep[4], k[3]] :> -d[ep[4], k[1]] - d[ep[4], k[2]], 
   d[epT[4], k[3]] :> -d[epT[4], k[1]] - d[epT[4], k[2]], d[l[5], l[5]] :> 0, 
   d[l[5], l[6]] :> -d[k[1], k[2]] + d[k[1], k[5]] + d[k[1], k[6]] + 
     d[k[2], k[5]] + d[k[2], k[6]], d[l[6], l[6]] :> 0|>, 
 "cutExpression" -> ((64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[1], k[2]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]] + 
     64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[2]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]] - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[1], k[2]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[1], k[2]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[2]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] - 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]] + 512*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]] - 
     128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]] + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]] - 
     512*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]] + 512*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 512*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]] - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[2]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[1], k[2]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[2]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[1], k[2]] - 384*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[2]] - 
     384*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[2]] + 384*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[2]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[2]] + 384*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
     192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     192*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 192*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 192*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
     192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
     192*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]] + 128*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[2]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[2]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 384*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[2]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     384*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[2]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]^2 - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]^2 + 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]^2 + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]^2 + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]^2 - 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]^2 - 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[2]]^2 + 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[1], k[2]]^2 - 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[2]]^2 + 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[k[1], k[2]]^2 - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[1], k[2]]^2 + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[k[1], k[2]]^2 + 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*
      d[k[1], k[2]]^2 - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[1], k[2]]^2 + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[2]]^2 - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[2]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[2]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]]^2 + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[2]]^2 - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]]^2 + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[1], k[2]]^2 - 64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[5]]*d[k[1], k[2]]^2 - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]]^2 + 64*DsT*d[epT[1], epT[3]]*
      d[epT[2], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]^2 - 
     192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]^2 - 
     256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]^2 + 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[1], k[2]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[2]]^2 + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*
      d[k[1], k[2]]^2 - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]]^2 + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]]^2 + 64*DsT*d[epT[1], epT[2]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[2]]^2 - 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[2]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[1], k[2]]^2 - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[2]]^2 - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[5]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] + 
     256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[1], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[1], k[5]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]] + 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]] - 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     640*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 192*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 640*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]] - 192*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]] - 640*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
     192*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
     640*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[5]] - 192*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[1], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 192*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[1], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[1], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
     320*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[5]] - 64*DsT*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 320*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     320*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[5]] - 320*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]] - 256*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
     256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     320*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 320*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 320*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     320*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 320*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     320*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 128*DsT*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     384*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] - 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 + 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 + 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 - 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]^2 + 
     192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[5]]^2 - 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]^2 + 
     192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]^2 + 
     128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[1], k[5]]^2 - 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[k[1], k[5]]^2 + 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 + 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 + 
     256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 + 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 - 
     256*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 + 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*d[k[1], k[5]]^2 - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[1], k[5]]^2 - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]]^2 + 64*DsT*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]]^2 + 64*DsT*d[epT[1], epT[2]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[5]]^2 + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[5]]^2 - 
     192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^3 + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[1], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[6]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[6]] - 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[6]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[6]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[2]]*
      d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[6]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[6]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[6]] - 256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[6]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
     64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]] - 320*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
     192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
     320*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
     192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[1], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[6]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[6]] - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[6]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[6]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[6]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[6]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 192*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]^2*d[k[1], k[6]] - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 256*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
      d[k[1], k[6]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 - 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[1], k[6]]^2 + 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*
      d[k[1], k[6]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[3]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[3]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     384*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[3]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[3]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[3]] + 192*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[3]] + 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*
      d[k[2], k[3]] + 192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[3]] + 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     320*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[3]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[3]] - 
     256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[3]] - 256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[3]] + 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]]*d[k[2], k[3]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]^2*d[k[2], k[3]] - 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[3]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[3]] + 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]]*d[k[2], k[3]] + 192*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 
     192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[6]]*
      d[k[2], k[3]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[6]]*d[k[2], k[3]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[6]]*d[k[2], k[3]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]]*
      d[k[2], k[3]] - 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[6]]*d[k[2], k[3]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[3]] - 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]^2*d[k[2], k[3]] - 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
     256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[5]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[2], k[5]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[2]]*
      d[k[2], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[2], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[5]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[5]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 256*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 640*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 192*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 640*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
     192*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
     640*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[5]] + 192*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[5]] + 640*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]] - 192*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[2], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
     192*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[2], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[2], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[2], k[5]] + 320*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
     320*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
     128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 320*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
     320*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[2], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[2], k[5]] + 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[2], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[2], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 320*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 320*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     320*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 320*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     384*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 320*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 192*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 128*DsT*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     512*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 384*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     128*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     128*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     384*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 384*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 384*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     384*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 256*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     320*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 320*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 128*DsT*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     384*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
      d[k[2], k[5]] - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]^2*d[k[2], k[5]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[3]]*d[k[2], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[2], k[3]]*d[k[2], k[5]] + 320*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[2], k[3]]*
      d[k[2], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[3]]*d[k[2], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[2], k[3]]*d[k[2], k[5]] + 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] - 256*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[3]]*
      d[k[2], k[5]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 + 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 - 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 - 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[2], k[5]]^2 + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[2], k[5]]^2 - 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[2], k[5]]^2 + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[k[2], k[5]]^2 + 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*
      d[k[2], k[5]]^2 - 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[2], k[5]]^2 + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[2], k[5]]^2 - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[2], k[5]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[2], k[5]]^2 - 256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[5]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[2], k[5]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[5]]^2 + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[2], k[5]]^2 - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[5]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[5]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*
      d[k[2], k[5]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[5]]^2 + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[2], k[5]]^2 - 64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[5]]*d[k[2], k[5]]^2 - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]]^2 + 64*DsT*d[epT[1], epT[3]]*
      d[epT[2], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]]^2 - 
     192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]]^2 + 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[5]]^2 - 320*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[5]]^2 + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[2], k[5]]^2 - 64*DsT*d[epT[1], epT[2]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[5]]^2 + 
     256*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[2], k[5]]^2 - 
     128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[2], k[5]]^2 + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*
      d[k[2], k[5]]^2 - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]]^2 + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]]^2 + 64*DsT*d[epT[1], epT[2]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[5]]^2 - 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[2], k[5]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[2], k[5]]^2 - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[2], k[5]]^2 + 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[5]]^2 + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[2], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[6]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[2], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[6]] - 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[6]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[6]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[2]]*
      d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[2], k[6]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[6]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[6]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[6]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[2], k[6]] - 256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[6]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[6]] - 
     64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[6]] - 320*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[6]] - 
     192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[6]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[6]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[6]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[6]] - 
     320*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[6]] - 
     192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[2], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[6]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[2], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[6]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[2], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[2], k[6]] - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[6]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[6]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[6]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[6]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 192*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     320*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     640*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     512*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[2], k[6]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 192*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     320*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 256*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     256*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     576*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     512*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     256*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
      d[k[2], k[6]] + 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 256*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 256*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 320*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     192*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[3]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[3]]*
      d[k[2], k[6]] + 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[3]]*d[k[2], k[6]] + 192*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] - 
     192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[2], k[3]]*d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[2], k[3]]*d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[6]] - 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     192*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 320*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 192*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     640*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     576*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     256*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[2], k[3]]*d[k[2], k[5]]*d[k[2], k[6]] + 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]^2*d[k[2], k[6]] + 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2 - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2 - 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2 + 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2 - 
     128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*d[k[2], k[6]]^2 + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[k[2], k[6]]^2 + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[2], k[6]]^2 - 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[2], k[6]]^2 + 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[2], k[6]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[6]]^2 - 
     256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[6]]^2 + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[6]]^2 - 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[2], k[6]]^2 + 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[6]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[2], k[6]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[6]]^2 - 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*d[k[2], k[6]]^2 + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*d[k[2], k[6]]^2 - 
     320*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[6]]^2 + 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[6]]^2 - 256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[6]]^2 + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[6]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[2], k[6]]^2 - 64*DsT*d[epT[1], epT[2]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[6]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]]^2 + 
     192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[6]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]]^2 - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[3], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[3], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[3], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[3], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[3], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[3], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[3], k[5]] + 128*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[3], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[3], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[3], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[3], k[5]] + 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[3], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[3], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[3], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[3], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[3], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[3], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[3], k[5]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[2]]*
      d[k[3], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[3], k[5]] + 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[3], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[3], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[3], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[3], k[5]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[3], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[3], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[3], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[3], k[5]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[3], k[5]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[3], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[3], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[3], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[3], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[3], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[3], k[5]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[3], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[3], k[5]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[3], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[3], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[3], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[3], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[3], k[5]] + 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[3], k[5]] - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[3], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[3], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[3], k[5]] - 192*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[3], k[5]] + 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[3], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[3], k[5]] - 
     128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[3], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[3], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[3], k[5]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[3], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[3], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[3], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[3], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[3], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[3], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[3], k[5]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[3], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[3], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[3], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[3], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[3], k[5]] + 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[3], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[3], k[5]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[3], k[5]] + 128*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 320*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*
      d[k[3], k[5]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     192*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 128*d[epT[1], epT[2]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[3]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[3]]*
      d[k[3], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[3]]*d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[3]]*d[k[3], k[5]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[3]]*
      d[k[3], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[3]]*d[k[3], k[5]] - 192*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[2], k[3]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[3]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[3]]*d[k[3], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[2], k[3]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[2], k[3]]*
      d[k[3], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[3]]*d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[3]]*d[k[3], k[5]] - 128*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[3]]*d[k[3], k[5]] + 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 192*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 320*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2*
      d[k[3], k[5]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[5]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 320*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 128*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[2], k[6]]^2*d[k[3], k[5]] + 128*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[3], k[5]]^2 - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[3], k[5]]^2 - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[3], k[5]]^2 - 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[3], k[5]]^2 + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[3], k[5]]^2 + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[3], k[5]]^2 + 64*d[epT[1], k[2]]*
      d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[3], k[5]]^2 - 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[3], k[5]]^2 + 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[3], k[5]]^2 - 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[3], k[5]]^2 - 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*d[k[3], k[5]]^2 + 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[k[3], k[5]]^2 - 
     128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[3], k[5]]^2 + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[k[3], k[5]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[3], k[5]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[3], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[3], k[5]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[3], k[5]]^2 - 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*d[k[3], k[5]]^2 + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*d[k[3], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[3], k[5]]^2 + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[3], k[5]]^2 - 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*d[k[3], k[5]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[3], k[5]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]]^2 + 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[3], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[5]]^2 + 
     64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[3], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[1]]*d[k[3], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[3], k[6]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[3], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[3], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[3], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[3], k[6]] - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[3], k[6]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[3], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[3], k[6]] - 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[3], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[3], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[3], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[3], k[6]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[3], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[3], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[3], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[3], k[6]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[3], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[2]]*
      d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[2]]*d[k[3], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[3], k[6]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[3], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[3], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[3], k[6]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[3], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[3], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[3], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[3], k[6]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[3], k[6]] - 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[3], k[6]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[3], k[6]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[3], k[6]] - 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[3], k[6]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[3], k[6]] - 192*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[3], k[6]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[3], k[6]] + 192*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[3], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[3], k[6]] + 128*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[3], k[6]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[3], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[3], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[3], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[3], k[6]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[3], k[6]] + 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[3], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[3], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[3], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[3], k[6]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[3], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[3], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[3], k[6]] + 
     192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[3], k[6]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[3], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[3], k[6]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[3], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[3], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[3], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[3], k[6]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[3], k[6]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[3], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[3], k[6]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[3], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[3], k[6]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[6]]*
      d[k[3], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[3], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[3], k[6]] - 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[3], k[6]] + 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]^2*d[k[3], k[6]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] - 128*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]^2*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[3]]*
      d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[3]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[2], k[3]]*d[k[3], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[3]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[3]]*d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[3]]*d[k[3], k[6]] - 
     192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*d[k[2], k[3]]*
      d[k[3], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[3]]*d[k[3], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[3]]*d[k[3], k[6]] + 
     192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[3]]*
      d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[3]]*d[k[3], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[3]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[3]]*d[k[3], k[6]] + 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 128*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[1]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[2], k[3]]*d[k[2], k[5]]*d[k[3], k[6]] + 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]^2*d[k[3], k[6]] - 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[2], k[6]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[1]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[2]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[6]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[5]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[6]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[6]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]]*
      d[k[3], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2*d[k[3], k[6]] + 
     64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[3], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[3], k[5]]*d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[3], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[3], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[3], k[5]]*d[k[3], k[6]] - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[6]]*d[k[3], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[k[3], k[5]]*d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[3], k[5]]*
      d[k[3], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[3], k[5]]*d[k[3], k[6]] + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[3], k[5]]*
      d[k[3], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[6]]*
      d[k[3], k[5]]*d[k[3], k[6]] - 128*d[epT[1], epT[3]]*d[epT[2], k[1]]*
      d[epT[4], k[6]]*d[k[3], k[5]]*d[k[3], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[3], k[5]]*
      d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[5]]*d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[5]]*
      d[k[3], k[6]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[3], k[6]]^2 + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[3], k[6]]^2 + 128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[3], k[6]]^2 + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[3], k[6]]^2 + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[k[3], k[6]]^2 + 64*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[5]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[k[3], k[6]]^2 + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[3], k[6]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[3], k[6]]^2 + 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[3], k[6]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[5]]*
      d[k[3], k[6]]^2 + 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[5]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[3], k[6]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[6]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[3]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[6]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
      d[k[3], k[6]]^2)*(-4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[2]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
     16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
     16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[2]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
     16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
     16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[2]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
     4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
     4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]] - 12*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
     12*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
     12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
     12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[2]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
     12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[2]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
     12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[2]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[2]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
     16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
     16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]] - 12*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
     4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]] + 12*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
     314*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 64*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 2*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     314*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 6*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 58*d[ep[1], k[6]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     64*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 6*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 42*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
     2*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 58*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 42*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
     314*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 64*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 2*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     314*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 6*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 58*d[ep[1], k[6]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     64*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 6*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 42*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
     2*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 58*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 42*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     74*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 2*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 104*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
     74*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 18*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 110*d[ep[1], k[6]]*d[ep[2], k[3]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
     2*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 18*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 10*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
     104*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 110*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 10*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     138*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 308*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 166*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
     138*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 70*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 122*d[ep[1], k[6]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     308*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 70*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 22*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     166*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 122*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 22*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     292*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]] - 160*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 194*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     292*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 64*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 160*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
     64*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]] - 26*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 194*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     26*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]] - 292*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 160*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
     194*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 292*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 64*d[ep[1], k[5]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     160*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]] - 64*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 26*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     194*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 26*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 164*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
     36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]] - 102*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 164*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
     96*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 32*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 36*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     96*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]] - 6*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 102*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
     32*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 6*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 96*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     214*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 140*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 96*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
     116*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 12*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 214*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     116*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[2]] - 6*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 140*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
     12*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 6*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 80*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 6*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 18*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 80*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 24*d[ep[1], k[5]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 24*d[ep[1], k[6]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 6*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 24*d[ep[1], k[3]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 4*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 18*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 24*d[ep[1], k[3]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 4*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 78*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]^2 - 16*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]^2 + 14*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]^2 - 14*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]^2 - 78*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[1], k[2]]^2 + 16*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[k[1], k[2]]^2 - 14*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[k[1], k[2]]^2 + 14*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[k[1], k[2]]^2 + 78*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]^2 - 16*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]^2 + 14*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]^2 - 14*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]^2 - 78*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[k[1], k[2]]^2 + 16*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[k[1], k[2]]^2 - 14*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[k[1], k[2]]^2 + 14*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[k[1], k[2]]^2 + 10*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]^2 + 6*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]^2 + 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]^2 - 10*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[5]]*d[k[1], k[2]]^2 - 6*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[k[1], k[2]]^2 - 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[k[1], k[2]]^2 - 66*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]^2 + 4*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]^2 + 6*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]^2 + 6*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]^2 + 66*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[1], k[2]]^2 - 4*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[k[1], k[2]]^2 - 6*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[k[1], k[2]]^2 - 6*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 + 16*d[ep[1], k[3]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 + 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 - 16*d[ep[1], ep[3]]*d[ep[2], k[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 + 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 - 12*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 + 44*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 + 52*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 - 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 + 16*d[ep[1], k[3]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 + 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 - 16*d[ep[1], ep[3]]*d[ep[2], k[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 + 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 - 12*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 - 56*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 - 48*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 + 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]^2 - 200*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 - 108*d[ep[1], k[3]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 - 40*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 + 44*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 + 200*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 + 108*d[ep[1], ep[3]]*d[ep[2], k[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 + 40*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 - 44*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 + 72*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 + 236*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 - 34*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 - 82*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]]^2 + 104*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]^2 + 80*d[ep[1], k[3]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]^2 - 48*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]^2 - 104*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]]^2 - 80*d[ep[1], ep[3]]*d[ep[2], k[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]^2 + 48*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]]^2 - 110*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]]^2 - 182*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]]^2 + 98*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]]^2 + 48*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[2]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]^3 + 16*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^3 + 
     44*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^3 + 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 44*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 44*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
     52*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 252*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
     52*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]] - 252*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
     60*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[5]] - 248*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[5]] - 60*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
     248*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
     44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
     44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
     44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
     44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[5]] - 52*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
     252*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]] + 52*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
     252*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]] + 60*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[5]] - 248*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
     60*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[5]] + 248*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[5]] - 264*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]] + 164*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[5]] + 264*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]] - 164*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[5]] - 264*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[5]] + 164*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[5]] + 264*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[5]] - 164*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[5]] + 76*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
     24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[5]] - 76*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
     24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
     44*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
     44*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[5]] + 272*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
     20*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[5]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 272*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
     20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[5]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[5]] + 272*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
     20*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 272*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
     20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 312*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
     60*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[5]] - 76*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[5]] + 312*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
     60*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[5]] + 76*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 312*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
     28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[5]] + 312*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
     28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 144*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     6*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 10*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 144*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     44*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 6*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     44*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 44*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 10*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     44*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 44*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 110*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     58*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 70*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 110*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     58*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 70*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 110*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     58*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 70*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 110*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     58*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 70*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 30*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     8*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 54*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 74*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     30*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 54*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     74*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 42*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 32*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     74*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 54*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 42*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     32*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 74*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 54*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     44*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 44*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     44*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 62*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 62*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 64*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 44*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     44*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 44*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 44*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     54*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 54*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     236*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 80*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 6*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     26*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 236*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 80*d[ep[1], ep[3]]*d[ep[2], k[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     6*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 26*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 48*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     252*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 22*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 188*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     40*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 12*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     16*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 12*d[ep[1], ep[3]]*d[ep[2], k[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 278*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     238*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 180*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 318*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     12*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*d[k[1], k[5]] - 
     12*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] - 
     86*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] + 
     112*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
     80*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
     112*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
     80*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
     76*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 - 
     76*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 + 
     76*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 - 
     76*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 - 
     84*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[5]]^2 + 
     84*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]^2 - 
     100*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]^2 + 
     100*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]^2 - 
     56*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
     56*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
     10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
     46*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
     46*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
     74*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
     56*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
     56*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
     86*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
     30*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
     38*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
     174*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
     4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
     4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
     2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
     6*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
     12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 + 
     22*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
     24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
     22*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
     2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
     30*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
     14*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
     16*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[1], k[5]]^2 + 
     16*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]^2 + 
     70*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]^2 - 
     4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^3 + 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[6]] - 92*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[6]] + 92*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[6]] - 92*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[6]] + 92*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[6]] + 188*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[6]] - 188*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
     108*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[6]] - 184*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[6]] - 108*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
     184*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
     92*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
     92*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
     92*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
     92*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[6]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
     188*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
     188*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[6]] + 108*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[6]] - 184*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
     108*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[6]] + 184*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[6]] - 324*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[6]] + 116*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[6]] + 324*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[6]] - 116*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[6]] - 324*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[6]] + 116*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[6]] + 324*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[6]] - 116*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[6]] + 320*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
     40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[6]] - 320*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
     380*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[6]] - 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[6]] - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
     380*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[6]] + 36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
     212*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[6]] - 28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[6]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
     212*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[6]] + 28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
     212*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[6]] - 28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[6]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
     212*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[6]] + 28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
     68*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[6]] - 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[6]] - 68*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
     68*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[6]] + 36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[6]] + 68*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
     68*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[6]] - 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
     68*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[6]] + 36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
     8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 138*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 138*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 28*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 28*d[ep[1], k[6]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     138*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 28*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 28*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     138*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 28*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 28*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     184*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 32*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 72*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     24*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 184*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 32*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     72*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 184*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     32*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 72*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 24*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     184*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 32*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 72*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     24*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 112*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 16*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     64*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 112*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     16*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 64*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 32*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     184*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 56*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 84*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     12*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 184*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 56*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     84*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 12*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     32*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 44*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 44*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     12*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 124*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 116*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     74*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 174*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     32*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 44*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 44*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     12*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 104*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 112*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     74*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 66*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     52*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 20*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     64*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 52*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     20*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 176*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 224*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     264*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 154*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 68*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     40*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 10*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 6*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     68*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 40*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 10*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     6*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 174*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 226*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     36*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 98*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]^2*d[k[1], k[6]] - 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
      d[k[1], k[2]]^2*d[k[1], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2*d[k[1], k[6]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     60*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 88*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     60*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 88*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     88*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 88*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 88*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 104*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     104*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     86*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 54*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 162*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     40*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 34*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 98*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     144*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 88*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 88*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     42*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 130*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     34*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 60*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 60*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     52*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 56*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     38*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 98*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     10*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[1], k[6]] - 
     80*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
     52*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
     8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
     80*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
     52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
     8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
     76*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 - 
     76*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
     76*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 - 
     76*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 - 
     44*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[6]]^2 + 
     44*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[6]]^2 - 
     68*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[6]]^2 + 
     68*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[6]]^2 + 
     24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
     96*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
     72*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
     116*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
     34*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
     24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
     20*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
     4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
     72*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
     34*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
     52*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 - 
     52*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 - 
     32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 - 
     84*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 + 
     20*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 + 
     4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 - 
     4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 + 
     4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 - 
     38*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 - 
     34*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 + 
     34*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 + 
     32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 + 
     8*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[1], k[6]]^2 - 
     8*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]^2 - 
     120*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]^2 + 
     18*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]^2 + 
     4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^3 - 
     4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[3]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[3]] + 
     4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[3]] + 308*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[3]] + 
     308*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 68*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[3]] - 164*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     292*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 292*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[3]] + 196*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[3]] + 
     96*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[3]] + 88*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
      d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[3]] - 
     52*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[3]] + 60*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[3]] - 52*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 60*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[3]] - 
     264*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[3]] - 264*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 76*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[3]] + 272*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 272*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[3]] - 
     312*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[3]] - 312*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[3]] - 144*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[3]] + 112*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[2], k[3]] + 
     4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[3]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[3]] + 
     108*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[3]] - 
     4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[3]] + 108*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[3]] - 324*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 
     324*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*
      d[k[2], k[3]] + 320*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[6]]*d[k[2], k[3]] + 380*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] + 
     212*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]*
      d[k[2], k[3]] + 212*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[6]]*d[k[2], k[3]] - 68*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[3]] - 
     68*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]]*
      d[k[2], k[3]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]]*d[k[2], k[3]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 80*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[3]] + 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[2], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[2], k[5]] + 44*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[5]] + 44*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
     52*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[2], k[5]] + 252*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
     52*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[2], k[5]] - 252*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
     60*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[5]] - 248*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[2], k[5]] - 60*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
     248*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
     44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
     44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
     44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[2], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
     44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[2], k[5]] - 52*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
     252*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[5]] + 52*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
     252*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[5]] + 60*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[5]] - 248*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
     60*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[5]] + 248*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[5]] - 264*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[5]] + 164*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[5]] + 264*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[5]] - 164*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[5]] - 264*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[2], k[5]] + 164*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[5]] + 264*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[2], k[5]] - 164*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[5]] + 76*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
     24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[2], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[2], k[5]] - 76*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
     24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[2], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
     44*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[2], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
     44*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[2], k[5]] + 272*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
     20*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[5]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[5]] - 272*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
     20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[5]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[5]] + 272*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
     20*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[5]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[5]] - 272*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
     20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[5]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[5]] - 312*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
     60*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[2], k[5]] - 76*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[2], k[5]] + 312*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
     60*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[2], k[5]] + 76*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[2], k[5]] - 312*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
     28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[2], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[2], k[5]] + 312*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
     28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[2], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[2], k[5]] - 144*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     6*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 10*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 144*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     44*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 6*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     44*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 44*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 10*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     44*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 44*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 110*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     58*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 70*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 110*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     58*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 70*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 110*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     58*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 70*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 110*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     58*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 70*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 30*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     8*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 54*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 74*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     30*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 54*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     74*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 42*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 32*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     74*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 54*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 42*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     32*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 74*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 54*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     44*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 44*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     44*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 50*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 50*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     48*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 60*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 44*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     44*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 44*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 44*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     66*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 66*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 236*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 80*d[ep[1], k[3]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     6*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 26*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 236*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     80*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 6*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 26*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 216*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 54*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     196*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 12*d[ep[1], k[3]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 40*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     12*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     34*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 6*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 132*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 12*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*
      d[k[2], k[5]] - 12*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*
      d[k[2], k[5]] - 58*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
      d[k[2], k[5]] + 224*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     160*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 224*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     160*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 152*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 152*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     152*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 152*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 168*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     168*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 200*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 200*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     112*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 112*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 20*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     132*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 84*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 100*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     112*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 112*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 132*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     20*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 84*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 100*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 48*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 32*d[ep[1], ep[3]]*
      d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     112*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
      d[k[2], k[5]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 60*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     88*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 60*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 88*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 88*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     88*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 88*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 104*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 104*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 78*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     46*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 154*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 144*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 10*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     42*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 90*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 40*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     88*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 88*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 34*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     122*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     60*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 60*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 80*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     20*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     8*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 34*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 80*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     70*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[5]] + 
     4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[3]]*d[k[2], k[5]] - 52*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     60*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[3]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] - 
     52*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 60*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[3]]*d[k[2], k[5]] - 264*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] - 
     264*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 76*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[2], k[3]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     272*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 272*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[3]]*d[k[2], k[5]] - 312*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] - 
     312*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[3]]*
      d[k[2], k[5]] - 144*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[3]]*d[k[2], k[5]] + 224*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     112*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
     80*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
     112*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
     80*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
     76*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 - 
     76*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 + 
     76*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 - 
     76*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 - 
     84*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[5]]^2 + 
     84*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[2], k[5]]^2 - 
     100*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[5]]^2 + 
     100*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[5]]^2 - 
     56*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
     56*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
     30*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
     86*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
     38*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
     174*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
     56*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
     56*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
     46*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
     10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
     46*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
     74*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
     4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 - 
     4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 + 
     6*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 + 
     2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 + 
     12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 - 
     22*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 - 
     24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 + 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 - 
     2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 + 
     22*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 - 
     30*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 - 
     14*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 - 
     16*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[2], k[5]]^2 + 
     16*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]^2 + 
     42*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]^2 + 
     4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]]^2 + 
     70*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]^2 + 
     112*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]^2 + 
     4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^3 + 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[2], k[6]] - 92*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[2], k[6]] + 92*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[6]] - 92*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[6]] + 92*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[2], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[2], k[6]] + 188*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[2], k[6]] - 188*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
     108*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[6]] - 184*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[2], k[6]] - 108*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
     184*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
     92*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
     92*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
     92*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
     92*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[2], k[6]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
     188*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
     188*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[6]] + 108*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[6]] - 184*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
     108*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[6]] + 184*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[6]] - 324*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[6]] + 116*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[6]] + 324*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[6]] - 116*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[6]] - 324*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[2], k[6]] + 116*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[6]] + 324*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[2], k[6]] - 116*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[6]] + 320*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
     40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[2], k[6]] - 320*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[2], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
     380*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[2], k[6]] - 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[2], k[6]] - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
     380*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[2], k[6]] + 36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
     212*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[6]] - 28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[6]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
     212*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[6]] + 28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
     212*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[6]] - 28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[6]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
     212*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[6]] + 28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
     68*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[2], k[6]] - 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[2], k[6]] - 68*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
     68*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[2], k[6]] + 36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[2], k[6]] + 68*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
     68*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[2], k[6]] - 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
     68*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[2], k[6]] + 36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[2], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
     8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 138*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 138*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 28*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 28*d[ep[1], k[6]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     138*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 28*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 28*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     138*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 28*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 28*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     184*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 32*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 72*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     24*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 184*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     72*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 184*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     32*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 72*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 24*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     184*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 32*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 72*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     24*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 112*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 16*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     64*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 112*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     16*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 64*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 32*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     184*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 56*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 84*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     12*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 184*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 56*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     84*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 12*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     32*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 44*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 44*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     12*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 108*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 100*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     70*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 174*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     32*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 44*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 44*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     12*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 120*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 128*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     78*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 66*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     52*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 20*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     64*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 52*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     20*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 100*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 148*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     56*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 226*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 68*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     40*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 10*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 6*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     68*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 40*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 10*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     6*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 14*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 38*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     104*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 30*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]^2*d[k[2], k[6]] - 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
      d[k[1], k[2]]^2*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2*d[k[2], k[6]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     60*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 88*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     60*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 88*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     88*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 88*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 88*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 104*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     104*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     42*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 90*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     40*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     46*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 78*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 154*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     144*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 88*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 88*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     122*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 34*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 60*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 60*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     20*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 80*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 66*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     70*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[2], k[6]] - 
     160*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 104*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     160*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 104*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     152*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 152*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 152*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     152*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 88*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 88*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     136*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 136*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     48*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 100*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 52*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     44*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 68*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     48*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 52*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 100*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     44*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 68*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 104*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     104*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 52*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 52*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 80*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     52*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*
      d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[3]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[3]]*d[k[2], k[6]] - 
     4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[3]]*
      d[k[2], k[6]] + 108*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[3]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[3]]*d[k[2], k[6]] + 
     4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[3]]*d[k[2], k[6]] + 108*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[3]]*d[k[2], k[6]] - 
     324*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 324*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[2], k[3]]*d[k[2], k[6]] + 320*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] + 
     380*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[3]]*
      d[k[2], k[6]] + 212*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[3]]*d[k[2], k[6]] + 212*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] - 
     68*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 68*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[2], k[3]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] - 
     160*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 60*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     88*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 60*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 88*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 88*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     88*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 88*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 104*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 104*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 34*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 98*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 144*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 54*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     86*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 162*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 40*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     88*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 88*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 130*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     42*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 34*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     60*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 60*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     52*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 56*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 38*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     8*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 66*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 80*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     52*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 10*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2*d[k[2], k[6]] - 80*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 80*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 52*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 76*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[2], k[6]]^2 - 76*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[2], k[6]]^2 + 76*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[2], k[6]]^2 - 76*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[k[2], k[6]]^2 - 44*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[2], k[6]]^2 + 44*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[2], k[6]]^2 - 68*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[2], k[6]]^2 + 68*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[2], k[6]]^2 + 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[2], k[6]]^2 - 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[1]]*d[k[2], k[6]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[2], k[6]]^2 - 20*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[6]]^2 + 72*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[2], k[6]]^2 - 34*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[2], k[6]]^2 + 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[2], k[6]]^2 - 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[6]]^2 - 72*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[6]]^2 - 96*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[2], k[6]]^2 + 116*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[2], k[6]]^2 + 34*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[6]]^2 + 52*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[2], k[6]]^2 - 52*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[6]]^2 + 84*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[6]]^2 + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[6]]^2 - 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[2], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[2], k[6]]^2 - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[2], k[6]]^2 + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[6]]^2 + 34*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[6]]^2 + 38*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[6]]^2 - 34*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[2], k[6]]^2 - 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[2], k[6]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]*d[k[2], k[6]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]]^2 + 40*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]]^2 - 70*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[6]]^2 - 80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[3]]*d[k[2], k[6]]^2 - 18*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[2], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[6]]^3 + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[3], k[5]] - 28*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[3], k[5]] - 
     52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[3], k[5]] + 28*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[3], k[5]] + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[3], k[5]] - 
     28*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[3], k[5]] - 52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[3], k[5]] + 28*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[3], k[5]] - 
     48*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[3], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[3], k[5]] + 248*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[5]] + 
     48*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[3], k[5]] - 248*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[5]] + 
     48*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[3], k[5]] - 252*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[3], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[3], k[5]] + 
     252*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[3], k[5]] + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[3], k[5]] - 28*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[3], k[5]] - 
     52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[3], k[5]] + 28*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[3], k[5]] + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[3], k[5]] - 
     28*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[3], k[5]] - 52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[3], k[5]] + 28*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[3], k[5]] - 
     48*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[3], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[3], k[5]] + 248*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[5]] + 
     48*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[3], k[5]] - 248*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[5]] + 
     48*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[3], k[5]] - 252*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[3], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[3], k[5]] + 
     252*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[3], k[5]] + 56*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[3], k[5]] + 64*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
     8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[3], k[5]] - 56*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[3], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[5]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[3], k[5]] + 56*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[3], k[5]] + 64*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
     8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[3], k[5]] - 56*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[3], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[5]] - 
     8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[3], k[5]] + 20*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[3], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
     44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[3], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[3], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[3], k[5]] - 
     44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[3], k[5]] + 88*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[3], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[5]] - 
     16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[3], k[5]] - 88*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[3], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
     16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[3], k[5]] - 20*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[3], k[5]] - 312*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[5]] - 
     360*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[3], k[5]] + 312*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[5]] + 
     360*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[3], k[5]] - 20*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[3], k[5]] - 312*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[5]] - 
     360*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[3], k[5]] + 312*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[5]] + 
     360*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[3], k[5]] - 52*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[3], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[3], k[5]] + 
     28*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[3], k[5]] + 52*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[3], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[3], k[5]] - 
     28*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[3], k[5]] + 16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[3], k[5]] + 76*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[3], k[5]] + 
     88*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[3], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[3], k[5]] - 76*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[3], k[5]] - 
     88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[3], k[5]] + 64*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     56*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 20*d[ep[1], k[5]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     20*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 20*d[ep[1], k[3]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     40*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 56*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 20*d[ep[1], k[3]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     40*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 108*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 16*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     44*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 56*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 108*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     16*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 44*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 56*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     108*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 16*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 44*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     56*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 108*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     44*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 56*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     16*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 60*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 72*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 16*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 60*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     72*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 52*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 28*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     80*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 48*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 52*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     28*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 80*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 48*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 16*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     32*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     40*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 32*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 50*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     74*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 42*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 16*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     32*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     40*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 32*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 74*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     50*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     116*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 28*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 34*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     34*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 116*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 28*d[ep[1], ep[3]]*d[ep[2], k[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     34*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 34*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 28*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     84*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     112*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 20*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     16*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 112*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     20*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 62*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     82*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 26*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*d[k[3], k[5]] + 
     4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*d[k[3], k[5]] + 
     36*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[3], k[5]] - 
     48*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 88*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 40*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     48*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 88*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     84*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 84*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 84*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     84*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 68*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 68*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 88*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 48*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     30*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 122*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 36*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     38*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 130*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 148*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     148*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 42*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 106*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 96*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     96*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 108*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 204*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 38*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 12*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] + 12*d[ep[1], ep[3]]*
      d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     30*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 44*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
      d[k[3], k[5]] - 72*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 244*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     160*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 72*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 244*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     160*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 184*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 184*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     184*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 184*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 144*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     144*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 196*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 196*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 70*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     86*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 52*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 98*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 114*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     98*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 196*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 98*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     172*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 172*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 82*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     90*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 22*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     68*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 68*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 146*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     214*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 14*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     12*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 12*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 66*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] - 142*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[3], k[5]] - 
     48*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[3]]*
      d[k[3], k[5]] + 48*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[3]]*d[k[3], k[5]] - 48*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[2], k[3]]*d[k[3], k[5]] + 
     48*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[3]]*
      d[k[3], k[5]] + 56*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[3]]*d[k[3], k[5]] + 56*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[3]]*d[k[3], k[5]] + 
     20*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[3]]*
      d[k[3], k[5]] + 88*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[2], k[3]]*d[k[3], k[5]] - 20*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[3]]*d[k[3], k[5]] - 
     20*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[3]]*
      d[k[3], k[5]] - 52*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[2], k[3]]*d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[2], k[3]]*d[k[3], k[5]] + 
     72*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
      d[k[3], k[5]] - 48*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[3]]*d[k[3], k[5]] - 72*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[3]]*d[k[3], k[5]] - 
     48*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 88*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 40*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     48*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 88*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     84*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 84*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 84*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     84*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 68*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 68*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 36*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     38*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 130*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 48*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 88*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     30*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 122*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 148*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     148*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 106*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 42*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 96*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     96*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 204*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 108*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 38*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 12*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] + 12*d[ep[1], ep[3]]*
      d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     18*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 102*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 48*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[3]]*d[k[2], k[5]]*d[k[3], k[5]] + 44*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[5]] - 
     72*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 244*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 160*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     72*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 244*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 160*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     184*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 184*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 184*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     184*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 144*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 144*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     196*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 196*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 98*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 114*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     196*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 98*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 86*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 70*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     52*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 98*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 172*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     172*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 90*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 82*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     22*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 68*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     68*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 214*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 146*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     14*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 12*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 12*d[ep[1], ep[3]]*
      d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 102*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 72*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[3]]*d[k[2], k[6]]*d[k[3], k[5]] + 142*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2*d[k[3], k[5]] - 
     32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 + 
     92*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 + 
     148*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 + 
     32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 - 
     92*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 - 
     148*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 - 
     20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[3], k[5]]^2 + 
     20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[3], k[5]]^2 - 
     20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[3], k[5]]^2 + 
     20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[3], k[5]]^2 + 
     4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[3], k[5]]^2 - 
     4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[3], k[5]]^2 + 
     64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[3], k[5]]^2 - 
     64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[3], k[5]]^2 - 
     10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[3], k[5]]^2 - 
     10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[3], k[5]]^2 + 
     2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[5]]^2 + 
     32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[3], k[5]]^2 + 
     10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[3], k[5]]^2 + 
     10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[3], k[5]]^2 - 
     2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[5]]^2 - 
     32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[3], k[5]]^2 + 
     16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[3], k[5]]^2 - 
     16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[3], k[5]]^2 + 
     8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[5]]^2 - 
     8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[5]]^2 - 
     40*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[3], k[5]]^2 + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[3], k[5]]^2 - 
     20*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[5]]^2 + 
     20*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[5]]^2 + 
     4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[3], k[5]]^2 - 
     4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]]^2 - 
     16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]]^2 - 
     46*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]]^2 - 
     74*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]]^2 - 
     32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[3], k[5]]^2 + 
     46*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]]^2 + 
     74*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]]^2 + 
     4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[3], k[6]] - 76*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[3], k[6]] + 
     76*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[3], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[3], k[6]] - 76*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[3], k[6]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[3], k[6]] + 76*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[3], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[6]] + 
     184*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[3], k[6]] - 184*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[6]] + 
     96*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[3], k[6]] - 188*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[3], k[6]] - 96*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[3], k[6]] + 
     188*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[3], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[3], k[6]] - 76*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[3], k[6]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[3], k[6]] + 76*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[3], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[3], k[6]] - 
     76*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[3], k[6]] + 76*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[3], k[6]] - 
     8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[3], k[6]] + 184*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[6]] - 
     184*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[3], k[6]] + 96*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[3], k[6]] - 188*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[3], k[6]] - 
     96*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[3], k[6]] + 188*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[3], k[6]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
     320*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[3], k[6]] + 344*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[3], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[6]] - 
     320*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[3], k[6]] - 344*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[3], k[6]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
     320*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[3], k[6]] + 344*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[3], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[6]] - 
     320*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[3], k[6]] - 344*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
     36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[3], k[6]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
     76*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[3], k[6]] + 40*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[6]] - 
     76*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[3], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[6]] - 
     80*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[3], k[6]] - 104*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[3], k[6]] - 104*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
     80*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[3], k[6]] + 104*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[3], k[6]] + 104*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[6]] - 
     80*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[3], k[6]] - 104*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[3], k[6]] - 104*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
     80*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[3], k[6]] + 104*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[3], k[6]] + 104*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[6]] - 
     64*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[3], k[6]] + 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[3], k[6]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
     64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[3], k[6]] - 36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[3], k[6]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
     4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[3], k[6]] + 68*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[3], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[3], k[6]] - 
     4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[3], k[6]] - 68*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[3], k[6]] - 64*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
     64*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 156*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 180*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 4*d[ep[1], k[6]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     156*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 4*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 24*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     180*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     118*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 16*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 58*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     10*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 118*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 16*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     58*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 10*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 118*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     16*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 58*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 10*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     118*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 16*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 58*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     10*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 110*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 8*d[ep[1], k[3]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     70*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 30*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 110*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     8*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 70*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 30*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     94*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 52*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 90*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     6*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 94*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 52*d[ep[1], ep[4]]*d[ep[2], k[3]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     90*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 6*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     16*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 40*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     16*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 40*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 54*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     86*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 70*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 118*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 16*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 40*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 40*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     86*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 54*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 70*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     22*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 176*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 8*d[ep[1], k[3]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     24*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 72*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 176*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     8*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 24*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 72*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     112*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 108*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     38*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 44*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 40*d[ep[1], k[3]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     14*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 6*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 44*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     40*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 14*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[3], k[6]] + 6*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     26*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 54*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 28*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*
      d[k[3], k[6]] + 28*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*
      d[k[3], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
      d[k[3], k[6]] - 64*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 136*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     148*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 136*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     148*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 96*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 96*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 232*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     232*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 176*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 176*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 50*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     42*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 112*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 46*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     54*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 120*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 182*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     152*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 152*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 84*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     236*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 52*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     52*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 26*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 78*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     18*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 34*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 28*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 28*d[ep[1], ep[3]]*
      d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     118*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 68*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
      d[k[3], k[6]] - 24*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 84*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 84*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 60*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 60*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     60*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 60*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 84*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     84*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 36*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 36*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     68*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 68*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 134*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     18*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     50*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 18*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 272*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     272*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 36*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 308*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     18*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 56*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 48*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     18*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 104*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 18*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[3], k[6]] + 
     96*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[3]]*
      d[k[3], k[6]] + 96*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[3]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[3]]*d[k[3], k[6]] - 
     4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[3]]*
      d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[2], k[3]]*d[k[3], k[6]] + 76*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[2], k[3]]*d[k[3], k[6]] - 
     80*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[3]]*
      d[k[3], k[6]] - 80*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[3]]*d[k[3], k[6]] - 64*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[2], k[3]]*d[k[3], k[6]] + 
     4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[3]]*
      d[k[3], k[6]] + 56*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[3]]*d[k[3], k[6]] - 64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[3]]*d[k[3], k[6]] - 24*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]]*d[k[3], k[6]] - 
     64*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 136*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 148*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 136*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 148*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 96*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 96*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     96*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 232*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 232*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     176*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 176*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 54*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 46*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     120*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 182*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 42*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 50*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     112*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 152*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     152*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 236*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 84*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     20*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 52*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 52*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     78*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 26*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 18*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     34*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 28*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 28*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] + 54*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     116*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 68*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2*d[k[3], k[6]] - 24*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     84*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     84*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
      d[k[3], k[6]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 60*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     60*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 60*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 60*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     84*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 84*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 36*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     36*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[6]]*
      d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     50*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]]*
      d[k[3], k[6]] - 18*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 68*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     68*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 134*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 18*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     272*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[6]]*
      d[k[3], k[6]] - 272*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 308*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     36*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 18*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[2], k[6]]*
      d[k[3], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 48*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     56*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 18*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] - 116*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]]*
      d[k[3], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 18*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[6]]^2*d[k[3], k[6]] + 72*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[3], k[5]]*d[k[3], k[6]] + 
     152*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[5]]*
      d[k[3], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[3], k[5]]*d[k[3], k[6]] - 152*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     48*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[3], k[5]]*
      d[k[3], k[6]] + 48*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[3], k[5]]*d[k[3], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[3], k[5]]*d[k[3], k[6]] + 
     48*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[3], k[5]]*
      d[k[3], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[3], k[5]]*d[k[3], k[6]] + 48*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] + 
     72*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[3], k[5]]*
      d[k[3], k[6]] - 72*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[k[3], k[5]]*d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[3], k[5]]*
      d[k[3], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
      d[k[3], k[5]]*d[k[3], k[6]] - 36*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     24*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[5]]*
      d[k[3], k[6]] + 36*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[3], k[5]]*d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[3], k[5]]*
      d[k[3], k[6]] + 36*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[3], k[5]]*d[k[3], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[2]]*d[k[3], k[5]]*d[k[3], k[6]] + 
     24*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[5]]*
      d[k[3], k[6]] - 36*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[3], k[5]]*d[k[3], k[6]] + 68*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     68*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[3], k[5]]*
      d[k[3], k[6]] + 34*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[3], k[5]]*d[k[3], k[6]] - 34*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     44*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[3], k[5]]*
      d[k[3], k[6]] + 44*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
      d[k[3], k[5]]*d[k[3], k[6]] - 22*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[3], k[5]]*d[k[3], k[6]] + 
     22*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[5]]*
      d[k[3], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*
      d[k[3], k[5]]*d[k[3], k[6]] + 24*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[5]]*d[k[3], k[6]] - 36*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] - 
     76*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]]*
      d[k[3], k[6]] + 36*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[5]]*d[k[3], k[6]] + 76*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[6]]*d[k[3], k[5]]*d[k[3], k[6]] + 
     32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[6]]^2 + 
     44*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[6]]^2 + 
     68*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[6]]^2 - 
     32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[3], k[6]]^2 - 
     44*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[3], k[6]]^2 - 
     68*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[3], k[6]]^2 - 
     28*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[3], k[6]]^2 + 
     28*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[3], k[6]]^2 - 
     28*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[3], k[6]]^2 + 
     28*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[3], k[6]]^2 - 
     52*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[3], k[6]]^2 + 
     52*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[3], k[6]]^2 + 
     8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[3], k[6]]^2 - 
     8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[3], k[6]]^2 + 
     24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[3], k[6]]^2 - 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[3], k[6]]^2 - 
     2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[3], k[6]]^2 - 
     26*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[3], k[6]]^2 - 
     26*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[6]]^2 + 
     4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[3], k[6]]^2 + 
     24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[3], k[6]]^2 - 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[3], k[6]]^2 + 
     26*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[3], k[6]]^2 + 
     2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[3], k[6]]^2 + 
     26*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[6]]^2 - 
     4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[3], k[6]]^2 + 
     52*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[3], k[6]]^2 - 
     52*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[3], k[6]]^2 + 
     26*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[6]]^2 - 
     26*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[6]]^2 - 
     4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[3], k[6]]^2 + 
     4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[3], k[6]]^2 - 
     2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[6]]^2 + 
     2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[6]]^2 - 
     28*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[3], k[6]]^2 + 
     28*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]]^2 + 
     16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]]^2 - 
     22*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]]^2 - 
     34*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]]^2 + 
     32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[3], k[6]]^2 + 
     22*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]]^2 + 
     34*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]]^2 + 
     Df*(-36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[2]] - 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
       36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 36*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]] - 36*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
       36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]] + 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]] - 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
       36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[2]] + 36*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]] - 36*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 46*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 4*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       2*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 46*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 4*d[ep[1], k[3]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       2*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       46*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 4*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 2*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 46*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       4*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 2*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       52*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 8*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 52*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 8*d[ep[1], k[3]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       4*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 30*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 26*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       18*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 30*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 6*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       2*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 26*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 6*d[ep[1], k[3]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 18*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 2*d[ep[1], k[3]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       4*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 10*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 4*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       10*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 4*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 2*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 2*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       10*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       4*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 10*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 4*d[ep[1], k[3]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       2*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 2*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       30*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 22*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 78*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       30*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 6*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 2*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       22*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 6*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 78*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       2*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 8*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       6*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       6*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       42*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       6*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
       2*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
       2*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
       6*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       2*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
       42*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       2*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       6*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 + 
       2*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 + 
       2*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
       6*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
       2*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
       2*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 + 
       6*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 + 
       2*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 + 
       2*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
       6*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
       2*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
       2*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 + 
       20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
       20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       36*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       36*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       16*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       36*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
       12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^3 - 
       4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^3 - 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^3 - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
       36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
       36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
       36*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]] + 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
       36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[1], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 36*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 36*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       36*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]] + 16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[5]] - 20*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[5]] - 12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       6*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 22*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       6*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 2*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 2*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       22*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 2*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 2*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 2*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 2*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       14*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 2*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       2*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 14*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[3]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 2*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       2*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 14*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       2*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 14*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[4]]*
        d[ep[2], k[3]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       2*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       8*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       2*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 12*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 2*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       2*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 2*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 12*d[ep[1], ep[4]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 2*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       2*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       4*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 22*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       4*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 10*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 2*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 14*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], k[3]]*
        d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 36*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 12*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       22*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 2*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       2*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 22*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 2*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       2*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 20*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 36*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       8*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*d[k[1], k[5]] + 
       8*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] - 
       8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 + 
       20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[5]]^2 - 
       20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]^2 + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]^2 - 
       24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
       4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
       2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
       6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
       4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
       10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
       6*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
       30*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
       4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
       10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
       14*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
       6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
       4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[1], k[5]]^2 - 
       4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^3 + 
       44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[6]] - 44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[6]] + 44*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
       44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]] - 52*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]] + 52*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
       44*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[6]] + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[6]] + 44*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
       52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[6]] + 44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[6]] - 44*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[1], k[6]] - 52*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       52*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 44*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[6]] + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       44*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[6]] + 40*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
       12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 12*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
       40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]] - 40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
       40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 24*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[6]] - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[6]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[6]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 2*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 34*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 2*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       2*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 2*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       2*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 2*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 34*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       2*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 2*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 10*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 6*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 10*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       4*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 6*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 10*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 6*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 10*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       4*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 6*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 10*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 6*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 10*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       4*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 6*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 12*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       8*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[3]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], ep[3]]*d[ep[2], k[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       20*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 12*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       4*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 18*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       8*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 2*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 2*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 18*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       8*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 2*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 2*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 36*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       52*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 48*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 12*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 48*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*
        d[k[1], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*
        d[k[1], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
        d[k[1], k[6]] - 12*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 12*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       14*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 26*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 26*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 14*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 10*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 22*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 38*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       14*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 10*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 14*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] - 12*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
        d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 4*d[ep[1], ep[3]]*
        d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
        d[k[1], k[6]] + 12*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]^2 - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]^2 - 12*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]^2 + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]^2 + 20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[6]]^2 - 20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[6]]^2 + 20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[6]]^2 - 20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[6]]^2 - 20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[6]]^2 + 20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[6]]^2 - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[6]]^2 + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[6]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[6]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[6]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[6]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[6]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[6]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]]^2 - 36*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]]^2 - 28*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[6]]^2 + 36*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[6]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]]^2 - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[6]]^2 + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[6]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[6]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[6]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[6]]^2 + 24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]]^2 + 36*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[3]] + 36*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[3]] - 40*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[3]] - 
       40*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[3]] - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[3]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[3]] - 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[3]] + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[3]] - 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[3]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[3]] - 36*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[3]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[3]] - 36*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[3]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[2], k[3]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[3]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[3]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[2], k[3]] + 40*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[2], k[3]] + 40*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[3]] + 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[3]] - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[2], k[3]] - 
       44*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[3]] - 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[3]] + 40*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] + 40*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 
       40*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[2], k[3]] - 24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[3]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[2], k[3]] - 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[3]] - 12*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] + 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[3]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[2], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       36*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[5]] + 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 36*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 36*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       36*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[2], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 20*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       6*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 22*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       6*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 2*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 2*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       22*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 2*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 2*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 2*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 2*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       14*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 2*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       2*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 14*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[3]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 2*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       2*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 14*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       2*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 14*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[4]]*
        d[ep[2], k[3]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       2*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       2*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 12*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 2*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       2*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 2*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 12*d[ep[1], ep[4]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 2*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       2*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       4*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 22*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       4*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 10*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 2*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 14*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[3]]*
        d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 36*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 40*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 12*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       22*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 2*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       2*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 22*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 2*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       2*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 28*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*
        d[k[2], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*
        d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
        d[k[2], k[5]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 40*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] + 48*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       48*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 24*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       20*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
        d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[3]]*
        d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
        d[k[2], k[5]] - 12*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 12*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       14*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 26*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 26*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 38*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 10*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 22*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 14*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       14*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 10*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 6*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 12*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*
        d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[3]]*d[k[2], k[5]] - 36*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[3]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] - 
       36*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[3]]*
        d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[3]]*d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[3]]*
        d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[3]]*d[k[2], k[5]] + 40*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] + 40*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
        d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[3]]*d[k[2], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] - 8*d[ep[1], k[3]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 + 
       20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[5]]^2 - 
       20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[2], k[5]]^2 + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[5]]^2 - 
       24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
       4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
       6*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
       10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
       30*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
       4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
       2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
       2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
       6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 - 
       4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 + 
       14*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 + 
       10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 - 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 - 
       6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[2], k[5]]^2 - 
       4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^3 + 
       44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[2], k[6]] - 44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[2], k[6]] + 44*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
       44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[6]] - 52*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[6]] + 52*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
       44*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[6]] + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[6]] + 44*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
       52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[6]] + 44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[6]] - 44*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
       44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[2], k[6]] - 44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[2], k[6]] - 52*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
       52*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[2], k[6]] - 44*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[6]] + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
       44*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[6]] - 52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[6]] + 40*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
       12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[6]] - 12*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
       40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[6]] + 12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[6]] - 40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
       40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[6]] - 24*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[6]] - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[2], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[6]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[2], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[6]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[6]] + 2*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 34*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 2*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       2*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 2*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       2*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 2*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 34*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       2*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 2*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 10*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 6*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 10*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       4*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 6*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 10*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 6*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 10*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       4*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 6*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 10*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 6*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 10*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       4*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 6*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 12*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       8*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[3]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[3]]*d[ep[2], k[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 12*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       4*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 20*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 18*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       8*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 2*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 2*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 18*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       8*d[ep[1], ep[3]]*d[ep[2], k[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 2*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 2*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 12*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 12*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*
        d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*
        d[k[2], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
        d[k[2], k[6]] - 12*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 12*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       22*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 10*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 14*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 26*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 14*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       26*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 38*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 14*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 10*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 6*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 24*d[ep[1], k[3]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 40*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 40*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 40*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[6]]*d[k[2], k[6]] + 32*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 28*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       20*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[3]]*d[k[2], k[6]] - 44*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[3]]*d[k[2], k[6]] + 
       40*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[3]]*
        d[k[2], k[6]] + 40*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[3]]*d[k[2], k[6]] - 40*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] - 24*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[3]]*
        d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[3]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
        d[k[2], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[3]]*d[k[2], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] - 12*d[ep[1], k[3]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 12*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       22*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 10*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 38*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 26*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 14*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       26*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 14*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 14*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 10*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 14*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
        d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[3]]*
        d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 12*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[2], k[6]] + 
       12*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 
       4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 
       12*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 
       20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 - 
       20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 + 
       20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 - 
       20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 - 
       20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[6]]^2 + 
       20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[2], k[6]]^2 - 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[6]]^2 + 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[6]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
       28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
       36*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 - 
       36*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 + 
       4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[6]]^2 - 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]^2 + 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]]^2 - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[3], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[3], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[3], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[3], k[5]] - 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[5]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[3], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[3], k[5]] + 36*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[3], k[5]] - 
       36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[3], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[3], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[5]] - 
       36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[3], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[3], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[5]] + 
       36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[3], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[3], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[3], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[3], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[3], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[3], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[3], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[3], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[3], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[5]] - 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[3], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[3], k[5]] + 44*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[3], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[5]] - 
       44*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[3], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[3], k[5]] + 44*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[5]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[3], k[5]] - 44*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[3], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[5]] + 
       4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[3], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[3], k[5]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[3], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[3], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[3], k[5]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[3], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[3], k[5]] - 12*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 30*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       4*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 2*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       30*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 2*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       12*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 12*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 14*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 2*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 14*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       4*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 2*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 6*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] + 6*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 14*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 6*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       4*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 38*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       2*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 2*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 38*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       2*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 2*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 20*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 20*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*
        d[k[3], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*
        d[k[3], k[5]] - 6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
        d[k[3], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[3], k[5]] + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] - 12*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       12*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 28*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 28*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] + 28*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       28*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 20*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 14*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] + 20*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       20*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 20*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 14*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] - 14*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       30*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[4]]*
        d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]^2*d[k[3], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] - 20*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       20*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 20*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       20*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] + 24*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 
       14*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] + 2*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] - 18*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*
        d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[3]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[3]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[3]]*d[k[3], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[3]]*
        d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[3]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[3]]*d[k[3], k[5]] - 12*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*d[k[3], k[5]] + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*
        d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[3]]*d[k[3], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] + 12*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       12*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 28*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 28*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       28*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 28*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] - 20*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       20*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 14*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] + 20*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       20*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 14*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] - 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       30*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 14*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 6*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2*
        d[k[3], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] + 
       40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] - 20*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]]*
        d[k[3], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] + 
       20*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[6]]*
        d[k[3], k[5]] - 20*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 24*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 14*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] + 14*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]*
        d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 20*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]^2*d[k[3], k[5]] - 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 - 
       12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 + 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 + 
       12*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[3], k[5]]^2 + 
       8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[3], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[3], k[5]]^2 + 
       8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[3], k[5]]^2 - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[3], k[5]]^2 + 
       4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[3], k[5]]^2 + 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[3], k[5]]^2 - 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[3], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[3], k[5]]^2 - 
       2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[3], k[5]]^2 + 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[3], k[5]]^2 - 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[3], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[3], k[5]]^2 + 
       2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[3], k[5]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[3], k[5]]^2 - 
       4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[3], k[5]]^2 + 
       2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[5]]^2 - 
       2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]]^2 + 
       6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]]^2 - 
       6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]]^2 + 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[3], k[6]] - 52*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[3], k[6]] + 52*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[6]] - 
       8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[3], k[6]] + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[3], k[6]] - 
       52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[3], k[6]] + 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[3], k[6]] - 52*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[6]] + 
       52*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[3], k[6]] - 8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[3], k[6]] + 52*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[3], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[3], k[6]] - 52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[3], k[6]] - 40*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[3], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[3], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[6]] - 
       40*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[3], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[3], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[3], k[6]] - 
       4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[3], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
       8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[3], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[3], k[6]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
       8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[3], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[3], k[6]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
       4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[3], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[3], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[3], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[3], k[6]] + 20*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 18*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 20*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       18*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 2*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 2*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 28*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 28*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] + 28*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 28*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] - 34*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       4*d[ep[1], k[3]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 6*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 34*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       4*d[ep[1], ep[4]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 6*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] + 10*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       18*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       18*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       38*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 6*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       2*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 38*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 4*d[ep[1], ep[3]]*d[ep[2], k[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 6*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       2*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 20*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 2*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] + 10*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[3], k[6]] - 
       20*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       20*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       28*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 28*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 28*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 28*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 40*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] - 40*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 10*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[6]] - 18*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       20*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       18*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 46*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] + 32*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] + 4*d[ep[1], ep[4]]*
        d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]^2*d[k[3], k[6]] - 12*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[3], k[6]] + 22*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 6*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] + 2*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       30*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       14*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
        d[k[3], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]^2*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[3]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[3]]*d[k[3], k[6]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[3]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[3]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[3]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[3]]*d[k[3], k[6]] + 
       20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
        d[k[3], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[3]]*d[k[3], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[3]]*d[k[3], k[6]] - 20*d[ep[1], k[3]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 20*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 28*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] + 28*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       28*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 28*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] - 40*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 40*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 18*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] + 46*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 18*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] + 10*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       20*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] + 24*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 16*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
        d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] - 4*d[ep[1], ep[3]]*
        d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       18*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[5]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[6]] - 
       12*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] + 
       12*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[6]] + 6*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       30*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]]*
        d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 
       2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 22*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 12*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[6]]*d[k[3], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]^2*d[k[3], k[6]] - 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[3], k[5]]*d[k[3], k[6]] - 
       12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[5]]*
        d[k[3], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[3], k[5]]*d[k[3], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[3], k[5]]*d[k[3], k[6]] + 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[3], k[5]]*
        d[k[3], k[6]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[3], k[5]]*d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[3], k[5]]*d[k[3], k[6]] + 4*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[3], k[5]]*d[k[3], k[6]] + 
       2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[5]]*
        d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[3], k[5]]*d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[3], k[5]]*d[k[3], k[6]] + 2*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[3], k[5]]*d[k[3], k[6]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[3], k[5]]*
        d[k[3], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[3], k[5]]*d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] + 2*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] + 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[3], k[5]]*
        d[k[3], k[6]] - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[3], k[5]]*d[k[3], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[3], k[5]]*d[k[3], k[6]] - 2*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[5]]*d[k[3], k[6]] + 
       6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]]*
        d[k[3], k[6]] + 6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[5]]*d[k[3], k[6]] - 6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] - 6*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]]*d[k[3], k[6]] + 
       20*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[6]]^2 + 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[6]]^2 - 
       20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[3], k[6]]^2 - 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[3], k[6]]^2 + 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[3], k[6]]^2 - 
       8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[3], k[6]]^2 + 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[3], k[6]]^2 - 
       8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[3], k[6]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[3], k[6]]^2 - 
       4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[3], k[6]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[3], k[6]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[3], k[6]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[3], k[6]]^2 + 
       2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[6]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[3], k[6]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[3], k[6]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[3], k[6]]^2 - 
       2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[6]]^2 - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[3], k[6]]^2 + 
       4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[3], k[6]]^2 - 
       2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[6]]^2 + 
       2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[6]]^2 - 
       10*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]]^2 + 
       10*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]]^2) + 
     Ds*(-32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 8*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 8*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 52*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 16*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 16*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 16*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 8*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 16*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 8*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 64*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 80*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 64*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 80*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 64*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 80*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 64*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 80*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 48*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 64*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 + 
       24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 + 
       24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
       12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
       12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^3 - 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[5]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[5]] + 20*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
       20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]] - 28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]] - 28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[5]] - 28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 24*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[6]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 12*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       48*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 48*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 52*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       4*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 48*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       48*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 40*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 12*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] - 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
       24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
       2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
       10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 + 
       6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
       10*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
       10*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
       18*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
       14*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
       6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^3 + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
       64*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
       64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       56*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 56*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 56*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 56*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 40*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 48*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 24*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 28*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 24*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 24*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 56*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 56*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       40*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 48*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]^2*d[k[1], k[6]] + 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 14*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 22*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 18*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       22*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 14*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 26*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] - 18*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[6]]^2 + 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[6]]^2 - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[6]]^2 + 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[6]]^2 + 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[6]]^2 - 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[6]]^2 + 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[6]]^2 - 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]]^2 + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]]^2 + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]]^2 - 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[6]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]]^2 - 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[3]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[3]] + 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[3]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[3]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[3]] - 
       32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[3]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
        d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[3]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[3]] - 
       32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[2], k[3]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[3]] + 32*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[3]] + 
       16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[2], k[3]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
        d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 
       64*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[2], k[3]] - 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[2], k[3]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[3]] + 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[3]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[2], k[3]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]]*d[k[2], k[3]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 32*d[ep[1], k[6]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
       36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
       36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
       20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 20*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[2], k[5]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       28*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       4*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 48*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       20*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 28*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 20*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[5]] - 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 32*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 32*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[2], k[5]] + 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 24*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       14*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 22*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 10*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 2*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 6*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 2*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[5]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[3]]*
        d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[3]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] - 
       32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[3]]*
        d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[2], k[3]]*d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] - 
       32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*
        d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[3]]*d[k[2], k[5]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[2], k[5]]^2 + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[2], k[5]]^2 - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[5]]^2 + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[k[2], k[5]]^2 + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[2], k[5]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[k[2], k[5]]^2 + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[2], k[5]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[k[2], k[5]]^2 + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[5]]^2 - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[1]]*d[k[2], k[5]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[5]]^2 + 24*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]]^2 + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[2], k[5]]^2 - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[2], k[5]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]]^2 + 10*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[5]]^2 - 6*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[5]]^2 + 10*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[2], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[2], k[5]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]]^2 - 18*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]]^2 - 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]]^2 + 14*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[5]]^2 + 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[5]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^3 + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[6]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[6]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[2], k[6]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[2], k[6]] - 64*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[6]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[6]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 56*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 56*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 56*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       56*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 40*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 48*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       48*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 20*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 28*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 20*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 24*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], k[3]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 22*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 14*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 6*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 10*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] + 2*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
        d[k[2], k[6]] - 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 64*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 64*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 64*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] + 64*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[3]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] - 
       64*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[3]]*
        d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[3]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[3]]*
        d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[3]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] + 16*d[ep[1], k[3]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 22*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 14*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 18*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       14*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 22*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 26*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 18*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[5]]*d[k[2], k[6]] - 32*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 + 
       32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 - 
       32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 + 
       32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 + 
       32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[6]]^2 - 
       32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[2], k[6]]^2 + 
       32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[6]]^2 - 
       32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[6]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
       12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 - 
       12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 + 
       12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[6]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]^2 - 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[3], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[3], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[3], k[5]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[3], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[3], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[5]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[3], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[3], k[5]] - 20*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[5]] - 
       20*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[3], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[3], k[5]] - 12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[3], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[3], k[5]] - 20*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[5]] + 
       36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[3], k[5]] + 60*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[3], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[5]] - 
       60*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[3], k[5]] + 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[3], k[5]] + 60*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[5]] - 
       36*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[3], k[5]] - 60*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[3], k[5]] - 
       12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[3], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[3], k[5]] - 
       36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[3], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[3], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[3], k[5]] + 
       44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[3], k[5]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 20*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       8*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 24*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[6]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 32*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] - 16*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[3], k[5]] - 
       24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[5]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[3], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[3], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[3], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[3], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[3], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 16*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       40*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 10*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] + 30*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 10*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       22*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[3], k[5]] - 14*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] + 18*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
        d[k[3], k[5]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 40*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] + 40*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] - 
       40*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 32*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] + 12*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       28*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] - 16*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 28*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 14*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 26*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] - 34*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 22*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 36*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 24*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[3], k[5]] - 
       16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
        d[k[3], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[3]]*d[k[3], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] - 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 12*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[3], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] + 40*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       30*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 10*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]]*d[k[3], k[5]] - 6*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 10*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 14*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 22*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 18*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[2], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[5]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] + 
       40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]*
        d[k[3], k[5]] - 40*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 40*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] + 32*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] + 28*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       28*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]]*
        d[k[3], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] + 16*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]*
        d[k[3], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 10*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 14*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       10*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] + 
       34*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 26*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 6*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] - 22*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[6]]*d[k[3], k[5]] - 24*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2*d[k[3], k[5]] - 
       24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 - 
       40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 + 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 + 
       40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[3], k[5]]^2 + 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]]^2 + 
       20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]]^2 - 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]]^2 - 
       20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]]^2 - 
       32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[3], k[6]] - 48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[3], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[3], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[3], k[6]] - 48*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[3], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[3], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[3], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[3], k[6]] - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[3], k[6]] + 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
       48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[3], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[3], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
       48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[3], k[6]] + 48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[3], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[6]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[3], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[3], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[3], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[3], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[3], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
        d[k[3], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[3], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[3], k[6]] - 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 40*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 48*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] + 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 32*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 16*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[3], k[6]] + 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] + 24*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]^2*d[k[3], k[6]] + 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[6]]*d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 24*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[6]]*
        d[k[3], k[6]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 48*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       48*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 24*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[6]] + 32*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*
        d[k[3], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[3]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[3]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]]*d[k[3], k[6]] + 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[6]] + 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[6]]*
        d[k[3], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[k[2], k[6]]*d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]]*
        d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[6]]*d[k[3], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[6]] + 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       48*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 48*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 48*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[6]]*d[k[3], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[2], k[6]]*
        d[k[3], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]*
        d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2*
        d[k[3], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[3], k[5]]*d[k[3], k[6]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[3], k[5]]*d[k[3], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[3], k[5]]*
        d[k[3], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[3], k[5]]*d[k[3], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[5]]*d[k[3], k[6]] + 20*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]]*d[k[3], k[6]] - 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]]*
        d[k[3], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[5]]*d[k[3], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[3], k[6]]^2 - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[3], k[6]]^2 + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[3], k[6]]^2 + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[3], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[6]]^2 + 
       Df*(4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
          d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[2]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[2]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[2]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
          d[k[1], k[2]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[1], k[2]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[1], k[2]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[1], k[2]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[1], k[2]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
          d[k[1], k[2]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[5]]*d[k[1], k[2]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
          d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
          d[ep[4], k[5]]*d[k[1], k[2]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
          d[k[1], k[2]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[6]]*d[k[1], k[2]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
          d[k[1], k[2]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[ep[4], k[6]]*d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
          d[k[1], k[2]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[6]]*d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 + 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 + 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 + 
         2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
         2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
         4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
         2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
         2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
         12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
         12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
         4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
         8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
         2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
         2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^3 - 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
          d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[1], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
          d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
          d[ep[4], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
          d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[1], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
          d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*
          d[ep[4], k[6]]*d[k[1], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
          d[k[1], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
         12*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
          d[k[1], k[5]] + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[k[1], k[2]]*d[k[1], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 12*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
         8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
          d[k[1], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[1], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
         4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[1], k[5]] + 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[3]]*
          d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
         8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
          d[k[1], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
          d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 2*d[ep[1], ep[2]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
         12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
          d[k[1], k[5]] - 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
          d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
         2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
          d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
          d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
          d[k[1], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
          d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^2*d[k[1], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[1]]*d[k[1], k[5]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[k[1], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[2]]*d[k[1], k[5]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[k[1], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[5]]*d[k[1], k[5]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[k[1], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[6]]*d[k[1], k[5]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[k[1], k[5]]^2 - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[1]]*d[k[1], k[5]]^2 + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[5]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[5]]^2 + 6*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[1], k[5]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[5]]^2 - 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[5]]^2 - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[2]]*d[k[1], k[5]]^2 + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[5]]^2 - 6*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[5]]^2 - 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[2]]*d[k[1], k[5]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[1], k[5]]^2 + 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[1], k[5]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[1], k[5]]^2 - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
          d[k[1], k[6]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[6]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
          d[k[1], k[6]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
          d[k[1], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
          d[k[1], k[6]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[1], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
          d[k[1], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[5]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
          d[k[1], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
          d[k[1], k[6]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[1], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[1], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
          d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
          d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
         4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
          d[k[1], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
          d[k[1], k[2]]*d[k[1], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], k[3]]*
          d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
         8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*
          d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
          d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] + 
         8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]*
          d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[1], k[5]]*d[k[1], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
         8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
          d[k[1], k[6]] - 6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[1], k[5]]*d[k[1], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
          d[k[1], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[5]]*d[k[1], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 6*d[ep[1], ep[2]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
         2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
         2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
         2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
         2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
         2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]^2 - 
         4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[2], k[3]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
          d[k[1], k[2]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[3]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
          d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
          d[k[1], k[2]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^2*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[3]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
          d[k[2], k[3]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[1], k[5]]*d[k[2], k[3]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[3]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[6]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[3]] - 
         8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
          d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
          d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[1], k[6]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[3]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*
          d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
          d[k[1], k[6]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 4*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[3]] + 
         4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
          d[k[2], k[3]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[1]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[2], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[2], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[2], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[2], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
          d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[2], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[2], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[ep[4], k[6]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[6]]*
          d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
          d[ep[4], k[6]]*d[k[2], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
         8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 12*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
         12*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
          d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
          d[k[1], k[2]]*d[k[2], k[5]] - 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*
          d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*
          d[k[2], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
          d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^2*d[k[2], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
         8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
         16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*
          d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
          d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] + 
         16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]*
          d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
         12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
          d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
         8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
          d[k[2], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[5]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
         8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
          d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[1], k[5]]*d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
          d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
         8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*
          d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
          d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] + 
         8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[6]]*
          d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
         8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*
          d[k[2], k[5]] - 6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[1], k[6]]*d[k[2], k[5]] - 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
          d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[6]]*d[k[2], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 2*d[ep[1], ep[2]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
         4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
          d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[2], k[3]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[3]]*
          d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
          d[k[2], k[3]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] + 
         8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*
          d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
          d[k[2], k[3]]*d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[1]]*d[k[2], k[5]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[k[2], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[2]]*d[k[2], k[5]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[k[2], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[5]]*d[k[2], k[5]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[k[2], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[6]]*d[k[2], k[5]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[k[2], k[5]]^2 - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[1]]*d[k[2], k[5]]^2 + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[1]]*d[k[2], k[5]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[1]]*d[k[2], k[5]]^2 + 6*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[2], k[5]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[2], k[5]]^2 - 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[2], k[5]]^2 - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[2]]*d[k[2], k[5]]^2 + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[2]]*d[k[2], k[5]]^2 - 6*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[2], k[5]]^2 - 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[2]]*d[k[2], k[5]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[2], k[5]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[2], k[5]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[5]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[2], k[3]]*d[k[2], k[5]]^2 - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
          d[k[2], k[6]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[2], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[2], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[2], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[2], k[6]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
          d[k[2], k[6]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
          d[k[2], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
          d[k[2], k[6]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[2], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[2], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
          d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[5]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
          d[k[2], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
          d[k[2], k[6]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
          d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
          d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
          d[k[2], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
          d[k[1], k[2]]*d[k[2], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[6]] + 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
         8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
          d[k[2], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 
         8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[5]]*
          d[k[2], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[3]]*
          d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
          d[k[2], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[1], k[5]]*d[k[2], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
          d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 6*d[ep[1], ep[2]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
         6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
          d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[2], k[3]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[2], k[3]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[3]]*
          d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[5]]*
          d[k[2], k[3]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[6]] + 
         4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*
          d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[2], k[5]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
         8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*
          d[k[2], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[k[2], k[5]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
         8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[5]]*
          d[k[2], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]*
          d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
          d[k[2], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 2*d[ep[1], ep[2]]*
          d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
         6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]*
          d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
          d[k[2], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*d[k[2], k[5]]*
          d[k[2], k[6]] + 6*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[2], k[5]]*d[k[2], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
         4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]*
          d[k[2], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[1]]*
          d[k[2], k[6]]^2 - 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[2], k[6]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[2], k[6]]^2 - 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[2], k[6]]^2 - 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[2]]*
          d[k[2], k[6]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[2], k[6]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[6]]^2 + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[5]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[3], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[3], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[3], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[3], k[5]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
          d[k[3], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[6]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[3], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
          d[k[3], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[3], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
          d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
          d[ep[4], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
          d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
          d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*
          d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[3], k[5]] + 
         4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], ep[3]]*
          d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] + 
         4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
          d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[2]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[3], k[5]] - 8*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 
         8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
          d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] - 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
          d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
          d[k[1], k[2]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[6]]*d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] - 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*
          d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
          d[k[1], k[5]]*d[k[3], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] - 8*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] + 
         8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[5]]*
          d[k[3], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
          d[k[1], k[5]]*d[k[3], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] + 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
          d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[5]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[3], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
          d[k[3], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[5]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] + 
         6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
          d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
          d[k[1], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*
          d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
          d[k[1], k[5]]*d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[6]]*d[k[1], k[5]]*d[k[3], k[5]] + 4*d[ep[1], k[5]]*
          d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
          d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
          d[k[3], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[k[1], k[6]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] - 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[6]]*
          d[k[3], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[k[1], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
          d[k[3], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
          d[k[1], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[3], k[5]] - 
         2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*
          d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
          d[k[1], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] + 
         2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]*
          d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
          d[k[1], k[6]]*d[k[3], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*
          d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
          d[k[1], k[6]]*d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[6]]*d[k[1], k[6]]*d[k[3], k[5]] + 2*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] - 
         2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
          d[k[3], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*
          d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[2], k[5]]*d[k[3], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]*
          d[k[3], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
          d[k[2], k[5]]*d[k[3], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 8*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
         8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[5]]*
          d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[3], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]]*
          d[k[3], k[5]] - 6*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[2], k[5]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[3]]*
          d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*
          d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[2], k[5]]*d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] + 8*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 
         8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*
          d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[2], k[5]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] - 
         2*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]*
          d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
          d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
          d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[2], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]*
          d[k[3], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[k[2], k[6]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[6]]*
          d[k[3], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[k[2], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]*
          d[k[3], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
          d[k[2], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]]*d[k[3], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[6]]*
          d[k[3], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
          d[k[2], k[6]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] + 
         2*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]]*
          d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
          d[k[2], k[6]]*d[k[3], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]]*
          d[k[3], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
          d[k[2], k[6]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] - 2*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 
         2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]*
          d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
          d[k[2], k[6]]*d[k[3], k[5]] + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[2], k[6]]^2*d[k[3], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[3], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[3], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[3], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[3], k[6]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[3], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[3], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
          d[k[3], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[3], k[6]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[3], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[3], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[3], k[6]] + 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[3], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[2]]*d[k[3], k[6]] - 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] + 12*d[ep[1], ep[3]]*
          d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[3], k[6]] - 
         6*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
          d[k[3], k[6]] + 6*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[1], k[2]]*d[k[3], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[3], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[3], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[5]]*
          d[k[3], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[k[1], k[5]]*d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] + 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[5]]*d[k[3], k[6]] - 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
          d[k[3], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[5]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] - 
         8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
          d[k[3], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[1], k[5]]*d[k[3], k[6]] - 6*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[1], k[5]]*d[k[3], k[6]] - 2*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 
         2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[3], k[6]] - 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*
          d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[6]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
          d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 8*d[ep[1], ep[3]]*
          d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
         2*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*
          d[k[3], k[6]] - 6*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[1], k[6]]*d[k[3], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 4*d[ep[1], k[5]]*
          d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
          d[k[3], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[2], k[5]]*d[k[3], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[2], k[5]]*
          d[k[3], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[k[2], k[5]]*d[k[3], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] + 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 
         2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]]*
          d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[2], k[5]]*d[k[3], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] - 
         8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*
          d[k[3], k[6]] + 6*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[2], k[5]]*d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] + 2*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] + 
         2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]*
          d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2*
          d[k[3], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[2], k[6]]*d[k[3], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 
         8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]]*
          d[k[3], k[6]] + 6*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[2], k[6]]*d[k[3], k[6]] - 2*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 2*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 
         2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]*
          d[k[3], k[6]]))))/(16*d[k[1], k[2]]*(d[k[1], k[2]] - 
     d[k[1], k[5]] - d[k[1], k[6]] - d[k[2], k[5]] - d[k[2], k[6]])*
    (d[k[1], k[5]] + d[k[2], k[5]] + d[k[3], k[5]])*
    (d[k[1], k[2]] + d[k[3], k[5]] + d[k[3], k[6]]))|>
