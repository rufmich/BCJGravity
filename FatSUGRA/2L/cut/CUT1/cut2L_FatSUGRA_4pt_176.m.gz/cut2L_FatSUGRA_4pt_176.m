(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
<|"Graph" -> {{-1}, {-2}, {-3}, {-4}, {2, -5, 65}, {-65, 66, -6}, 
   {-66, -7, 1}, {-70, 6, 7}, {-71, 3, 4}, {71, 5, 70}}, 
 "momCons" -> {k[4] -> -k[1] - k[2] - k[3], 
   k[7] -> k[1] + k[2] - k[5] - k[6], k[65] -> -k[2] + k[5], 
   k[66] -> -k[2] + k[5] + k[6], k[70] -> k[1] + k[2] - k[5], 
   k[71] -> -k[1] - k[2]}, "cutLines" -> k[5, 6, 7], 
 "extraOS" -> <|d[k[1], k[1]] :> 0, d[ep[1], k[1]] :> 0, 
   d[epT[1], k[1]] :> 0, d[k[2], k[2]] :> 0, d[ep[2], k[2]] :> 0, 
   d[epT[2], k[2]] :> 0, d[k[3], k[3]] :> 0, d[ep[3], k[3]] :> 0, 
   d[epT[3], k[3]] :> 0, d[k[4], k[4]] :> 0, d[ep[4], k[4]] :> 0, 
   d[epT[4], k[4]] :> 0, d[k[1], k[3]] :> -d[k[1], k[2]] - d[k[2], k[3]], 
   d[ep[4], k[3]] :> -d[ep[4], k[1]] - d[ep[4], k[2]], 
   d[epT[4], k[3]] :> -d[epT[4], k[1]] - d[epT[4], k[2]], d[l[5], l[5]] :> 0, 
   d[l[5], l[6]] :> -d[k[1], k[2]] + d[k[1], k[5]] + d[k[1], k[6]] + 
     d[k[2], k[5]] + d[k[2], k[6]], d[l[6], l[6]] :> 0|>, 
 "cutExpression" -> ((256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     192*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[2]] - 256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 64*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[2]] + 256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     384*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]] - 128*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[2]] - 320*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]] + 
     192*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]] + 64*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 320*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]] - 320*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]] - 128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]] - 256*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]] + 192*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[2]] + 256*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]] - 
     64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]] + 64*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[2]] - 256*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]] + 384*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[2]] - 320*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]] + 192*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]] + 128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[2]] + 64*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]] - 128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     320*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[2]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]] - 320*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[2]] - 128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]] - 128*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[2]] - 128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
     320*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 192*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 128*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]] - 192*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]] - 
     64*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[2]] + 128*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]] - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]] + 320*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]] - 
     192*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]] - 64*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]] - 320*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 320*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 320*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 320*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]] + 128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[2]] + 64*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 + 256*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 64*DsT*d[epT[1], k[2]]*
      d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 
     192*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2 + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]^2 - 128*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]^2 + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 192*d[epT[1], k[3]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 64*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 + 128*d[epT[1], k[3]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 128*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 256*d[epT[1], k[2]]*
      d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]^2 + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[2]]^2 + 192*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[2]]^2 - 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]^2 + 128*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]^2 - 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]^2 + 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[2]]^2 + 
     192*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[k[1], k[2]]^2 - 
     128*d[epT[1], epT[4]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[k[1], k[2]]^2 - 
     256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]^2 + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[2]]^2 + 192*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[2]]^2 - 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]^2 + 128*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]^2 - 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]^2 + 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]^2 + 
     192*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[k[1], k[2]]^2 - 
     128*d[epT[1], epT[4]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[k[1], k[2]]^2 + 
     256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[2]]^2 - 192*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[2]]^2 + 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]^2 - 128*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]^2 + 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 - 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 - 
     192*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 + 
     128*d[epT[1], epT[3]]*d[epT[2], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 - 
     192*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 + 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 + 
     256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[2]]^2 - 192*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[2]]^2 + 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]^2 - 128*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]^2 + 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 - 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 - 
     192*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 + 
     128*d[epT[1], epT[3]]*d[epT[2], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 + 
     192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 + 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]^2 + 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]^2 + 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]^2 - 
     256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[5]] - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 256*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 320*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     448*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 192*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     448*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 320*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 64*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[5]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]] - 256*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 320*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[5]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     448*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 192*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     448*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 320*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 64*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
     320*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 448*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     192*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]] - 320*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
     256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 448*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[5]] - 192*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]] + 448*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 320*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 448*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 320*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[5]] + 256*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 512*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 320*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     256*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 192*d[epT[1], k[3]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 64*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     64*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 256*d[epT[1], k[3]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 512*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 192*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 256*d[epT[1], epT[4]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     512*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 192*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 256*d[epT[1], epT[4]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 192*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 256*d[epT[1], epT[3]]*d[epT[2], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     320*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 256*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 192*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 256*d[epT[1], epT[3]]*d[epT[2], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     320*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 256*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*
      d[k[1], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]^2 - 192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]^2 + 256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]^2 - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]^2 - 128*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]^2 + 64*DsT*d[epT[1], k[5]]*
      d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]^2 + 192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]^2 - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]^2 + 128*d[epT[1], k[3]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]^2 - 256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[5]]^2 + 64*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]^2 + 128*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]^2 - 64*DsT*d[epT[1], k[5]]*
      d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]^2 + 
     64*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]^2 - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[5]]^2 + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[1], k[5]]^2 - 128*d[epT[1], epT[4]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[k[1], k[5]]^2 - 256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[5]]^2 + 64*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]^2 + 128*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]^2 - 64*DsT*d[epT[1], k[5]]*
      d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]^2 + 
     64*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]^2 - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[5]]^2 + 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[k[1], k[5]]^2 - 128*d[epT[1], epT[4]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[k[1], k[5]]^2 + 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[5]]^2 - 64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]^2 - 128*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]^2 + 64*DsT*d[epT[1], k[5]]*
      d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[5]]^2 - 192*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[5]]^2 + 128*d[epT[1], epT[3]]*d[epT[2], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[5]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]]^2 + 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[5]]^2 - 64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]^2 - 128*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]^2 + 64*DsT*d[epT[1], k[5]]*
      d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 - 
     64*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[5]]^2 - 192*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]]^2 + 128*d[epT[1], epT[3]]*d[epT[2], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[5]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[5]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[5]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[5]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[5]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]^3 - 256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[6]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[6]] + 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[6]] + 448*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[6]] - 256*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[6]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[6]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[6]] - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[1], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[6]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[6]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[6]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[6]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[6]] + 192*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[1], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[6]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[6]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[6]] - 
     64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[6]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[6]] - 448*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[6]] + 256*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
     64*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[6]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[6]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[6]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[6]] + 192*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[6]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[6]] + 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[6]] - 
     64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[6]] - 256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[6]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]] + 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[6]] + 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]] - 192*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[1], k[6]] - 256*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]] + 
     64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[6]] + 64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]] - 192*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[6]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[6]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[6]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[1], k[6]] + 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[6]] + 192*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[6]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[1], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]] + 
     64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[1], k[6]] + 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 448*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 320*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 192*d[epT[1], k[3]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 128*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     448*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 192*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 448*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 192*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 448*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 192*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 448*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 192*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     448*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     320*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 64*d[epT[1], k[3]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 128*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     448*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 64*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 448*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 64*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 448*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 192*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     448*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 64*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
      d[k[1], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 + 192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]^2 - 128*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]^2 + 64*DsT*d[epT[1], k[5]]*
      d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[6]]^2 - 
     128*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[6]]^2 + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], k[3]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]^2 - 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[6]]^2 + 64*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[6]]^2 + 128*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[6]]^2 - 64*DsT*d[epT[1], k[5]]*
      d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[6]]^2 + 
     128*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[6]]^2 - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[k[1], k[6]]^2 - 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[6]]^2 + 64*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[6]]^2 + 128*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[6]]^2 - 64*DsT*d[epT[1], k[5]]*
      d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[6]]^2 + 
     128*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[6]]^2 - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[k[1], k[6]]^2 + 192*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[6]]^2 - 64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[6]]^2 - 128*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[6]]^2 + 64*DsT*d[epT[1], k[5]]*
      d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[6]]^2 - 
     128*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[6]]^2 + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[6]]^2 + 192*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[6]]^2 - 64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[6]]^2 - 128*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[6]]^2 + 64*DsT*d[epT[1], k[5]]*
      d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[6]]^2 - 
     128*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[6]]^2 + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[6]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[6]]^2 + 256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[3]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     192*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[3]] + 64*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[3]] + 256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[3]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     384*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[3]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[3]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[2], k[3]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[3]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[3]] - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[3]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[3]] + 256*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[3]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[3]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[2], k[3]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
      d[k[2], k[3]] - 256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[3]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[3]] + 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[3]] + 448*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[3]] - 256*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[3]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[3]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[3]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[3]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[3]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[3]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[3]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[3]] + 
     256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
      d[k[2], k[3]] - 192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]]*d[k[2], k[3]] - 256*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[5]] + 448*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
     64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[5]] - 384*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[5]] + 448*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 448*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
     384*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[5]] + 256*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
     128*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 448*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[5]] + 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     384*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 448*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 448*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[2], k[5]] + 384*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
     256*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] - 
     128*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[2], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
     192*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]] + 448*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]] - 384*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     256*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 256*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     128*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 448*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     384*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]] - 256*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
     128*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[5]] - 256*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     320*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 512*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     384*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     256*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 128*d[epT[1], k[3]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 320*d[epT[1], k[3]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 64*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     512*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     384*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 320*d[epT[1], epT[4]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     512*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     384*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 320*d[epT[1], epT[4]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     384*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 128*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 320*d[epT[1], epT[3]]*d[epT[2], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     320*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 320*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     384*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 128*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 320*d[epT[1], epT[3]]*d[epT[2], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     320*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 320*d[epT[1], epT[2]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 320*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     320*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*
      d[k[2], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 320*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 512*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     128*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 320*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     256*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 64*d[epT[1], k[3]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     64*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 64*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     320*d[epT[1], k[3]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 64*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     512*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     320*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 64*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 320*d[epT[1], epT[4]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     512*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     320*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 64*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 320*d[epT[1], epT[4]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     320*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 320*d[epT[1], epT[3]]*d[epT[2], k[6]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     320*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 320*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 512*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     320*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 64*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 320*d[epT[1], epT[3]]*d[epT[2], k[6]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     320*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 320*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 320*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     320*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]^2*d[k[2], k[5]] - 64*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 64*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     512*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     384*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     320*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 128*d[epT[1], k[3]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     512*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     384*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     320*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 128*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 512*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 384*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     320*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 128*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 512*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 384*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     320*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 128*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 384*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     384*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     320*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 128*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 384*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 448*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[3]]*d[k[2], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[5]] - 
     64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[3]]*
      d[k[2], k[5]] - 128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[2], k[3]]*d[k[2], k[5]] - 384*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 448*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[2], k[3]]*d[k[2], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[3]]*
      d[k[2], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
      d[k[2], k[5]] - 320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[3]]*d[k[2], k[5]] - 384*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] - 64*d[epT[1], k[2]]*
      d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 - 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 + 
     192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 - 128*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]^2 - 64*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]^2 + 64*DsT*d[epT[1], k[6]]*
      d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 + 
     64*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 + 128*d[epT[1], k[3]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 + 64*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2 - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]^2 + 128*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]^2 - 64*DsT*d[epT[1], k[6]]*
      d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 - 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[2], k[5]]^2 + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[2], k[5]]^2 + 128*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[2], k[5]]^2 - 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[2], k[5]]^2 + 64*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[2], k[5]]^2 - 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[2], k[5]]^2 + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[2], k[5]]^2 - 
     128*d[epT[1], epT[4]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[k[2], k[5]]^2 - 
     192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[2], k[5]]^2 + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[2], k[5]]^2 + 128*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[2], k[5]]^2 - 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[2], k[5]]^2 + 64*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[2], k[5]]^2 - 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[2], k[5]]^2 + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[2], k[5]]^2 - 
     128*d[epT[1], epT[4]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[k[2], k[5]]^2 + 
     192*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[2], k[5]]^2 - 128*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[2], k[5]]^2 + 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[2], k[5]]^2 - 64*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[2], k[5]]^2 + 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 + 
     128*d[epT[1], epT[3]]*d[epT[2], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 + 
     192*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[2], k[5]]^2 - 128*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[2], k[5]]^2 + 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[2], k[5]]^2 - 64*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[2], k[5]]^2 + 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 + 
     128*d[epT[1], epT[3]]*d[epT[2], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 + 
     64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 - 
     128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 + 
     128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]]^2 + 
     128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]]^2 + 
     192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]]^2 - 
     192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[5]]^2 - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]^3 - 
     256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[6]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[6]] - 
     256*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[6]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[6]] - 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[1]]*
      d[k[2], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[1]]*d[k[2], k[6]] - 256*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[6]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
      d[k[2], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[1]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[6]] + 
     256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[6]] - 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[6]] - 256*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[6]] + 
     256*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[6]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[6]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[2]]*
      d[k[2], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
      d[epT[4], k[2]]*d[k[2], k[6]] - 256*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[6]] - 
     64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
      d[k[2], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
      d[epT[4], k[2]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[6]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[6]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[5]]*d[k[2], k[6]] - 256*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[6]] + 
     256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
      d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[6]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
      d[epT[4], k[6]]*d[k[2], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[6]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
      d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[6]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
      d[epT[4], k[6]]*d[k[2], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[6]] + 
     64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
      d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 128*d[epT[1], k[3]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 320*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     320*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 256*d[epT[1], k[3]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 192*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     320*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 256*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 256*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 320*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 256*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 320*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 256*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 256*d[epT[1], k[3]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     320*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 256*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 320*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     128*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 256*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 256*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 256*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 256*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     320*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 320*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     320*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     320*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     320*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[3]]*
      d[k[2], k[6]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[3]]*d[k[2], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[6]] - 
     256*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[2], k[3]]*d[k[2], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[6]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[3]]*d[k[2], k[6]] - 64*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     128*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 320*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     128*d[epT[1], k[3]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     320*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 128*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 320*d[epT[1], k[2]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 320*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     64*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 128*d[epT[1], epT[4]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     256*d[epT[1], k[6]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     64*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*d[epT[1], epT[3]]*d[epT[2], k[5]]*d[epT[4], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
      d[epT[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
      d[epT[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[2], k[3]]*d[k[2], k[5]]*d[k[2], k[6]] - 64*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]^2*d[k[2], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2 - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[2], k[6]]^2 - 128*d[epT[1], k[5]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*
      d[k[2], k[6]]^2 + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[2], k[6]]^2 - 128*d[epT[1], k[6]]*d[epT[2], k[3]]*
      d[epT[3], epT[4]]*d[k[2], k[6]]^2 + 64*DsT*d[epT[1], k[6]]*
      d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2 - 
     128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[2], k[6]]^2 + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[2], k[6]]^2 + 128*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*
      d[k[2], k[6]]^2 - 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[2], k[6]]^2 + 128*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[1]]*d[k[2], k[6]]^2 - 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[2], k[6]]^2 - 
     128*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[2], k[6]]^2 + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[2], k[6]]^2 + 128*d[epT[1], k[5]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*
      d[k[2], k[6]]^2 - 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[2], k[6]]^2 + 128*d[epT[1], k[6]]*d[epT[2], epT[4]]*
      d[epT[3], k[2]]*d[k[2], k[6]]^2 - 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[2], k[6]]^2 + 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[2], k[6]]^2 - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[2], k[6]]^2 - 128*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
      d[k[2], k[6]]^2 + 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[2], k[6]]^2 - 128*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[1]]*d[k[2], k[6]]^2 + 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[2], k[6]]^2 + 
     128*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[6]]^2 - 
     64*DsT*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[2], k[6]]^2 - 128*d[epT[1], k[5]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
      d[k[2], k[6]]^2 + 64*DsT*d[epT[1], k[5]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[2], k[6]]^2 - 128*d[epT[1], k[6]]*d[epT[2], epT[3]]*
      d[epT[4], k[2]]*d[k[2], k[6]]^2 + 64*DsT*d[epT[1], k[6]]*
      d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[6]]^2 - 
     320*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 192*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     64*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[3], k[5]] + 
     320*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     448*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     192*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
      d[k[3], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     64*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     192*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     192*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
      d[k[3], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]^2*
      d[k[3], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[5]] - 
     256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[2], k[6]]*d[k[3], k[5]] + 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 128*d[epT[1], epT[2]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     320*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     320*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[3], k[6]] - 
     448*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     320*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
     128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     128*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
      d[k[3], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     64*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
      d[k[3], k[6]] - 64*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[1], k[6]]*d[k[3], k[6]] - 448*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 384*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[5]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     256*d[epT[1], k[5]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     256*d[epT[1], k[6]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[6]]*
      d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
      d[k[2], k[5]]^2*d[k[3], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     64*DsT*d[epT[1], k[2]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
      d[k[2], k[6]]*d[k[3], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
      d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
      d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[6]])*
    (248*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[2]] - 200*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 96*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
     24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[2]] - 76*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 388*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
     104*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[2]] - 216*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 100*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
     86*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]] + 38*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]] + 14*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
     30*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]] - 22*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 190*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
     90*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]] + 166*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 84*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
     196*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]] - 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
     20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]] - 224*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 104*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
     136*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]] - 132*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]] - 128*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
     248*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]] + 200*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[2]] + 96*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
     24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]] + 76*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[2]] + 388*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
     104*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]] + 216*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[2]] + 100*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
     98*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]] + 50*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]] - 6*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
     48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]] - 40*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]] - 112*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
     38*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]] + 218*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[2]] - 52*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
     132*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]] + 28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
     108*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]] - 352*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]] - 104*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
     72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]] - 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]] - 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
     86*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 38*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 14*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     30*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 22*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 190*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     90*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 166*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 84*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
     98*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 50*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 6*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]] + 40*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 112*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     38*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 218*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 52*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
     32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 10*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     10*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
     32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]] - 196*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 20*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     224*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 104*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 136*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     132*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 132*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
     28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 108*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     352*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 104*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]] - 32*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]] - 10*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 10*d[ep[1], k[5]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
     32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]] + 156*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 + 16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 - 60*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 + 36*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 + 92*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 + 28*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 - 100*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 - 212*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 - 32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 - 220*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 + 102*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 + 16*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 - 150*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 - 66*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]^2 + 22*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]^2 - 106*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]^2 - 38*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[1], k[2]]^2 + 160*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[k[1], k[2]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[k[1], k[2]]^2 - 58*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]^2 - 26*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]^2 - 10*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]^2 - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[1], k[2]]^2 + 168*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[k[1], k[2]]^2 + 24*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[k[1], k[2]]^2 - 26*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]^2 - 18*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]^2 + 42*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]^2 + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[k[1], k[2]]^2 + 54*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[k[1], k[2]]^2 - 20*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[k[1], k[2]]^2 - 44*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]^2 - 44*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]^2 + 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]^2 + 128*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[k[1], k[2]]^2 - 22*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]^2 + 106*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]^2 + 38*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]^2 + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[2]]^2 - 160*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]^2 + 16*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]]^2 - 196*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[2]]^2 + 70*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]^2 - 156*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]]^2 + 58*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]^2 + 26*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]^2 + 10*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]^2 + 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]]^2 - 168*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]^2 - 24*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]]^2 + 196*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[2]]^2 + 114*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]^2 - 68*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]]^2 + 26*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]^2 + 18*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]^2 - 42*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]^2 - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]]^2 - 54*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]]^2 + 20*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]]^2 - 70*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]]^2 - 114*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]]^2 - 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]]^2 + 44*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]^2 + 44*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]^2 - 32*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]^2 - 128*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]]^2 + 156*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]]^2 + 68*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]]^2 + 44*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
      d[k[1], k[2]]^2 + 24*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^3 - 
     24*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^3 - 
     120*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^3 - 
     236*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 188*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 148*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
     24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 76*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 388*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
     44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 68*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
     80*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]] - 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
     32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 84*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
     324*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 100*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
     260*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 100*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
     188*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 40*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
     72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[5]] + 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
     236*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]] - 188*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[5]] - 148*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
     24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]] - 76*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[5]] - 388*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
     44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]] - 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[5]] - 68*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
     80*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]] - 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
     32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]] + 84*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
     324*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]] + 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]] + 100*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
     260*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[5]] + 100*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
     188*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[5]] + 56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[5]] + 40*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
     72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[5]] + 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
     80*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[5]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
     32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[5]] - 84*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
     324*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]] - 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[5]] - 100*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
     80*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[5]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
     32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[5]] - 84*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
     324*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[5]] - 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[5]] - 100*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
     260*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[5]] - 100*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
     188*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
     72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[5]] - 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
     260*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]] - 100*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
     188*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
     72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]] - 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
     232*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 24*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 80*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     68*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 112*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 72*d[ep[1], k[5]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     32*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 168*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 296*d[ep[1], k[3]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     10*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 124*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 30*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     32*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 138*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 42*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     98*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 54*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     244*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 32*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 122*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     18*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 38*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     252*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 38*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     6*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 10*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     54*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 20*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 108*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     20*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 128*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     42*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 98*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 54*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 244*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 32*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     308*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 62*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 244*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     122*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 18*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 38*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 252*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     308*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 106*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 156*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     38*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 6*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 10*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 54*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 20*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     62*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 106*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     108*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] + 20*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
     128*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 244*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[5]] - 156*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
     44*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[5]] - 40*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*
      d[k[1], k[5]] + 40*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*
      d[k[1], k[5]] + 222*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
      d[k[1], k[5]] + 70*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 - 14*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 - 22*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 + 52*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 + 4*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 + 28*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 - 58*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 - 84*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 + 12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 + 42*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 - 154*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 + 16*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 + 34*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 + 50*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2 - 52*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[5]]^2 - 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[5]]^2 - 28*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[5]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[1], k[5]]^2 + 84*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[k[1], k[5]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[k[1], k[5]]^2 - 52*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[5]]^2 - 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[5]]^2 - 28*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[5]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[1], k[5]]^2 + 84*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[k[1], k[5]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[k[1], k[5]]^2 + 52*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[5]]^2 + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[5]]^2 + 28*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[5]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[5]]^2 - 84*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]]^2 + 16*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[5]]^2 - 112*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]]^2 - 88*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[5]]^2 + 52*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[5]]^2 + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[5]]^2 + 28*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[5]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]]^2 - 84*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]]^2 + 16*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[5]]^2 + 112*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]]^2 - 88*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[5]]^2 + 88*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[5]]^2 + 88*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]]^2 + 16*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*
      d[k[1], k[5]]^2 - 16*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]]^2 - 98*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^3 - 
     232*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[6]] + 184*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[6]] + 292*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
     244*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[6]] - 128*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[6]] + 128*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
     128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[6]] + 72*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
     24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[6]] + 24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[6]] + 48*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
     96*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
     96*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
     48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
     232*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[6]] - 184*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[6]] - 292*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
     244*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[6]] + 128*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[6]] - 128*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
     128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[6]] + 72*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
     24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[6]] + 24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[6]] + 48*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
     96*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
     96*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
     48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
     72*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[6]] + 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
     24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[6]] - 48*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[6]] + 96*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
     32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
     24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
     48*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[6]] + 96*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
     64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[6]] + 96*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
     64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
     32*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[6]] + 96*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
     64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
     32*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[6]] - 136*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     64*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 30*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 204*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     20*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 124*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 296*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     172*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 308*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 68*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 8*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 2*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     146*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 46*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 108*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 148*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     206*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 18*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 108*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 172*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     10*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 10*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 10*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     16*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 32*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     146*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 46*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 108*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 148*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     320*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 76*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 60*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     206*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 18*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 108*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 172*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     320*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 92*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     10*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 10*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 10*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 76*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     92*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
     16*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     60*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[1], k[6]] - 28*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[1], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
     16*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*d[k[1], k[6]] + 
     16*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] + 
     98*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] + 
     38*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 40*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 2*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     14*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 224*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 80*d[ep[1], k[5]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     92*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 30*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 104*d[ep[1], k[3]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     40*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 44*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 88*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     8*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 50*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     224*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 80*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 92*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     40*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 104*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     224*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 80*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 92*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     40*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 104*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     224*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 80*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 92*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 104*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     256*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 44*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 28*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     224*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 80*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 92*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     40*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 104*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     256*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 44*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 28*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     44*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
      d[k[1], k[6]] - 44*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[1], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] + 
     28*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[1], k[6]] + 24*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*
      d[k[1], k[5]]*d[k[1], k[6]] - 24*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 52*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
     22*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[1], k[6]] + 
     96*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
     32*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
     64*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
     8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
     64*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
     8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
     16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
     96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
     32*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
     64*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
     64*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 - 
     96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 + 
     32*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 + 
     64*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 + 
     64*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 + 
     96*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
     32*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
     64*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
     64*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
     64*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
     96*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
     32*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
     64*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
     64*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
     64*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
     2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]^2 - 
     14*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]^2 + 
     260*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 212*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[3]] - 108*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]] + 
     12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 64*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[3]] - 440*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]] + 
     188*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[3]] - 300*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[3]] - 132*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]] - 
     240*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[3]] - 
     236*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[3]] + 188*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 148*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]] - 
     24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[3]] + 76*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 388*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[3]] + 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[3]] + 68*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]] + 
     352*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[2], k[3]] - 112*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
      d[k[2], k[3]] - 232*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[3]] + 184*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]] + 
     292*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[3]] - 244*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[3]] - 128*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]] + 
     128*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[3]] + 128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[3]] + 352*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[3]] - 256*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 
     64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[3]] - 
     264*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 264*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[5]] + 296*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
     52*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[5]] + 316*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
     120*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 136*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[5]] + 68*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
     52*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[2], k[5]] + 316*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
     16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 72*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[2], k[5]] - 88*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
     76*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 44*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[2], k[5]] - 120*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
     136*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 68*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[2], k[5]] - 88*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
     76*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 44*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[2], k[5]] - 144*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
     136*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[5]] + 128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[2], k[5]] + 264*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
     264*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]] - 296*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[5]] + 52*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
     56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]] - 316*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[5]] + 120*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
     136*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]] - 68*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[5]] - 52*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
     56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[5]] + 316*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
     72*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[5]] - 88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[2], k[5]] + 76*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
     44*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[5]] - 120*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[5]] + 136*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
     68*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[5]] - 88*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[5]] + 76*d[ep[1], k[5]]*d[ep[2], k[5]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
     44*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[5]] - 144*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[5]] + 136*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
     128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[5]] + 52*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
     316*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[5]] - 72*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
     88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[5]] - 76*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
     52*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[2], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[5]] - 316*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
     16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[2], k[5]] - 72*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[5]] + 88*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
     76*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[2], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[2], k[5]] + 120*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
     136*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[5]] - 68*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[5]] + 88*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
     76*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[5]] + 144*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
     136*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[5]] - 128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[5]] + 120*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
     136*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[5]] - 68*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[5]] + 88*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
     76*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[5]] + 144*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
     136*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[5]] - 128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[5]] - 178*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     160*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 194*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 202*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     160*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 80*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 88*d[ep[1], k[6]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     64*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 116*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 88*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     50*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 28*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 172*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     108*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     156*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 128*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 32*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     200*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 124*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 164*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     148*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 120*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 36*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 28*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 44*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 6*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     20*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 36*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     4*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 108*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     16*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 40*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 156*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     128*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 32*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 296*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     66*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 120*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 200*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     124*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 164*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 148*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     120*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 36*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 296*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     90*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 72*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     28*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 44*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 20*d[ep[1], ep[3]]*d[ep[2], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     6*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 66*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 90*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] + 20*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
     36*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] + 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     4*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 120*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[5]] - 72*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
     4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*
      d[k[2], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*
      d[k[2], k[5]] + 202*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
      d[k[2], k[5]] + 52*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 136*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     58*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 28*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 212*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     140*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 188*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 74*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     100*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 78*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     160*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 92*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 72*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     72*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 212*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 140*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     188*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 136*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 100*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     92*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 212*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 140*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     188*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 136*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 100*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     92*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 212*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 140*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     188*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 136*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 100*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     92*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 272*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 72*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     128*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 212*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 140*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     188*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 136*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 100*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     92*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 272*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 72*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     128*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] - 72*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[2], k[5]] - 72*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] + 
     128*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 128*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[5]] + 20*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 20*d[ep[1], ep[3]]*
      d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
     222*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
      d[k[2], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 72*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     28*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 14*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 144*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     56*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 96*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 2*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     108*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 50*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 46*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     120*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 84*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 96*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     144*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 56*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 96*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     72*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 108*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 144*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     56*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 96*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 72*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     108*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 144*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     96*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 72*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 108*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     232*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 112*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 64*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     144*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 96*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     72*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 108*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 232*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     112*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 64*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 112*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
     112*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*
      d[k[2], k[5]] + 64*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[1], k[6]]*d[k[2], k[5]] + 64*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 
     120*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
      d[k[2], k[5]] - 98*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[1], k[6]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]^2*d[k[2], k[5]] - 264*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     264*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 296*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[3]]*d[k[2], k[5]] - 52*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 316*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[2], k[3]]*d[k[2], k[5]] - 120*d[ep[1], k[2]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
     136*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
      d[k[2], k[5]] + 68*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[3]]*d[k[2], k[5]] + 312*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] - 272*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] - 
     232*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]]*
      d[k[2], k[5]] - 18*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 - 128*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 - 36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 + 78*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 + 144*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 - 128*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 - 160*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 - 14*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 - 12*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 + 36*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 + 16*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 + 38*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 + 22*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]^2 - 144*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[2], k[5]]^2 + 128*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[2], k[5]]^2 + 160*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[2], k[5]]^2 + 128*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[2], k[5]]^2 + 12*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[k[2], k[5]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[k[2], k[5]]^2 - 144*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[2], k[5]]^2 + 128*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[2], k[5]]^2 + 160*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[2], k[5]]^2 + 128*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[2], k[5]]^2 + 12*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[k[2], k[5]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[k[2], k[5]]^2 + 144*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[2], k[5]]^2 - 128*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[2], k[5]]^2 - 160*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[2], k[5]]^2 - 128*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[2], k[5]]^2 - 12*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
      d[k[2], k[5]]^2 + 16*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[5]]^2 - 128*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[5]]^2 - 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[2], k[5]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[5]]^2 + 144*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[2], k[5]]^2 - 128*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[2], k[5]]^2 - 160*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[2], k[5]]^2 - 128*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]]^2 - 12*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[5]]^2 + 16*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[5]]^2 + 128*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]]^2 - 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[2], k[5]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[5]]^2 + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[5]]^2 + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[2], k[5]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[5]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[5]]^2 - 108*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]]^2 + 30*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[5]]^2 - 48*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[5]]^2 - 128*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
      d[k[2], k[5]]^2 - 6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^3 - 
     256*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[6]] + 256*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[6]] + 256*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
     256*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[6]] - 128*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[6]] + 128*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
     128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[2], k[6]] + 256*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[2], k[6]] - 256*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
     128*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[6]] + 128*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[2], k[6]] + 128*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
     256*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[6]] - 256*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[6]] - 256*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
     256*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[6]] + 128*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[2], k[6]] - 128*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
     128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[6]] + 256*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[2], k[6]] - 256*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
     128*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[6]] + 128*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[6]] + 128*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
     256*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[2], k[6]] + 256*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[5]]*d[k[2], k[6]] - 256*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
     256*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[2], k[6]] + 128*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[6]] - 128*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
     128*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
      d[k[2], k[6]] + 128*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[ep[4], k[6]]*d[k[2], k[6]] - 128*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
     128*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[2], k[6]] - 148*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 24*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     168*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 66*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 212*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     116*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 196*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 326*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     268*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 314*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 68*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     6*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 2*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     128*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 164*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 268*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     192*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 96*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 164*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 268*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 20*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 64*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     128*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 164*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 268*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     240*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 268*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     192*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 96*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 164*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 268*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     240*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 268*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
      d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
     20*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 20*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     268*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 268*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
      d[k[1], k[2]]*d[k[2], k[6]] - 64*d[ep[1], k[2]]*d[ep[2], ep[3]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
      d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
     8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*
      d[k[2], k[6]] - 40*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*
      d[k[2], k[6]] + 40*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*
      d[k[2], k[6]] + 42*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
      d[k[2], k[6]] + 96*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 24*d[ep[1], k[3]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     116*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 34*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 172*d[ep[1], k[2]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     76*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 132*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     268*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 28*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 20*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     38*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 4*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 34*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 172*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 76*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     132*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 268*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     4*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 172*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 76*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     132*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 268*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     4*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 172*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 76*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     132*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 268*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     4*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 240*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 268*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 172*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 76*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     132*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 268*d[ep[1], ep[3]]*d[ep[2], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     4*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 240*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 268*d[ep[1], ep[2]]*d[ep[3], k[5]]*
      d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
     8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 268*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[5]]*d[k[2], k[6]] - 268*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
      d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
      d[k[1], k[5]]*d[k[2], k[6]] + 40*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
      d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 40*d[ep[1], ep[3]]*
      d[ep[2], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
     132*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[2], k[6]] + 90*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
      d[k[2], k[6]] + 224*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 160*d[ep[1], k[5]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     192*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 64*d[ep[1], k[3]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 224*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     160*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 192*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 64*d[ep[1], ep[4]]*d[ep[2], k[5]]*
      d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     224*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 160*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 192*d[ep[1], k[6]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     64*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 224*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 160*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     192*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 64*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 64*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     64*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 224*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 160*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     192*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 64*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
      d[k[1], k[6]]*d[k[2], k[6]] + 64*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
     64*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] - 64*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 64*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] - 
     6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
      d[k[2], k[6]] + 22*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[1], k[6]]*d[k[2], k[6]] - 256*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]] + 
     256*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
      d[k[2], k[6]] + 256*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[2], k[3]]*d[k[2], k[6]] - 256*d[ep[1], k[5]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]] - 
     128*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
      d[k[2], k[6]] + 128*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[3]]*d[k[2], k[6]] + 128*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]] + 
     240*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
      d[k[2], k[6]] - 240*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[3]]*d[k[2], k[6]] - 64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] + 
     68*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 152*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 104*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     34*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 152*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 88*d[ep[1], k[5]]*d[ep[2], k[3]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     136*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 44*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 38*d[ep[1], k[5]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     22*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 70*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 152*d[ep[1], k[2]]*d[ep[2], ep[4]]*
      d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     88*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 136*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 152*d[ep[1], ep[4]]*d[ep[2], k[1]]*
      d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     4*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 152*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 88*d[ep[1], k[5]]*d[ep[2], ep[4]]*
      d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     136*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 152*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[4]]*d[ep[2], k[6]]*
      d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     152*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 88*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 136*d[ep[1], k[6]]*d[ep[2], ep[3]]*
      d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     152*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 152*d[ep[1], ep[2]]*d[ep[3], k[2]]*
      d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 152*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 88*d[ep[1], k[5]]*d[ep[2], ep[3]]*
      d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     136*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 152*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*
      d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     152*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
      d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
     4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]*
      d[k[2], k[6]] - 16*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*
      d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 168*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     70*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]]*
      d[k[2], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[2], k[5]]*d[k[2], k[6]] - 152*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[3]]*d[k[2], k[5]]*d[k[2], k[6]] + 
     8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[2], k[6]] + 
     128*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 
     128*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 
     128*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 
     128*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 + 
     128*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 + 
     128*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 - 
     128*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 + 
     128*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 + 
     128*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 + 
     128*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 - 
     128*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 - 
     128*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
     128*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
     128*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
     128*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
     4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]^2 + 
     4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]^2 + 
     2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]^2 - 
     92*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 44*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[5]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     64*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 140*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[5]] + 208*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[5]] - 68*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
     92*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[3], k[5]] + 
     80*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[3], k[5]] - 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 84*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     324*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[3], k[5]] + 68*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[3], k[5]] + 100*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
     84*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
      d[k[3], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
      d[k[3], k[5]] + 72*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 48*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     96*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[3], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
     92*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
      d[k[3], k[5]] + 44*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[1], k[6]]*d[k[3], k[5]] - 52*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] + 316*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[3], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     72*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 76*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
     44*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[5]] - 88*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[2], k[5]]*d[k[3], k[5]] + 72*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 112*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] - 
     12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[5]] + 
     256*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
      d[k[3], k[5]] - 256*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[6]]*d[k[3], k[5]] - 268*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] + 268*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
     64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]]*
      d[k[3], k[5]] + 196*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 36*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 128*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 372*d[ep[1], k[5]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     136*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] + 136*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[3], k[6]] - 132*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
     128*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[3], k[6]] - 156*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
      d[k[3], k[6]] - 260*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 100*d[ep[1], k[5]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 188*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 56*d[ep[1], k[5]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     40*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]*d[k[3], k[6]] + 68*d[ep[1], k[5]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
     64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[3], k[6]] + 244*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
      d[k[1], k[5]]*d[k[3], k[6]] - 88*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[5]]^2*d[k[3], k[6]] - 96*d[ep[1], k[2]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
     16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
      d[k[3], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[3], k[6]] + 60*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] - 28*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 
     120*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 136*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 68*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     88*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 76*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 44*d[ep[1], k[6]]*d[ep[2], k[5]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
     144*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
      d[k[3], k[6]] + 136*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[3], k[6]] + 128*d[ep[1], k[6]]*d[ep[2], k[6]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
     84*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
      d[k[3], k[6]] - 128*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[5]]*d[k[3], k[6]] - 64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*
      d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[6]] - 
     128*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 128*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 128*d[ep[1], k[6]]*d[ep[2], k[1]]*
      d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] - 
     8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]*
      d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
      d[k[2], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
      d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] + 
     Df*(-56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]] - 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 24*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
       20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 24*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[2]] - 24*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[2]] - 14*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 30*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
       66*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[2]] - 20*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 16*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[2]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[2]] - 32*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[2]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 56*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]] - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
       16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]] - 24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       24*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]] + 24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]] + 8*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
       2*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[2]] - 20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       60*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[2]] - 12*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]] + 20*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
       20*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]] - 32*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]] - 16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]] - 8*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       14*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 30*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 66*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       20*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 2*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 60*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       12*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 2*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 2*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 4*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 8*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 32*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       20*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 20*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 32*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] + 16*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       2*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 2*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] + 8*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 10*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 44*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 48*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 24*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 26*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 28*d[ep[1], k[3]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 14*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[3]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 10*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 16*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 40*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]^2 + 48*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]^2 + 20*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[2]]^2 - 36*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[k[1], k[2]]^2 - 28*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]^2 + 32*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]^2 + 16*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]^2 + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[k[1], k[2]]^2 - 28*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[k[1], k[2]]^2 + 4*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[k[1], k[2]]^2 - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]^2 + 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]^2 + 2*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]^2 + 2*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[k[1], k[2]]^2 + 2*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[k[1], k[2]]^2 - 12*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]^2 + 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]^2 - 48*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]^2 - 20*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[2]]^2 + 36*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]]^2 + 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[2]]^2 - 18*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]]^2 + 28*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]^2 - 32*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]^2 - 16*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]^2 - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]^2 + 28*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]^2 - 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]]^2 - 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]]^2 + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]^2 - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]^2 - 2*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]^2 - 2*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]^2 - 2*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]]^2 + 18*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]]^2 - 2*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]]^2 + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]]^2 + 10*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]^3 + 56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[5]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
       12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 60*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 56*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 20*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]] + 60*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 56*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 20*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 56*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 20*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 56*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 20*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 18*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 20*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       56*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       48*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 22*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       10*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 12*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       44*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 20*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       56*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 12*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 40*d[ep[1], k[5]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       24*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 48*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 6*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 2*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       2*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 44*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 56*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 32*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       20*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 56*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 12*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       26*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 40*d[ep[1], k[5]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 48*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 24*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 6*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 2*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       2*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 26*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 2*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 12*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
        d[k[1], k[2]]^2*d[k[1], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
        d[k[1], k[2]]^2*d[k[1], k[5]] - 22*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]^2*d[k[1], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 12*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 8*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 12*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 10*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 20*d[ep[1], k[3]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 10*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 4*d[ep[1], k[3]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 8*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 12*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]^2 + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]^2 + 12*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]^2 + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[k[1], k[5]]^2 - 20*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[k[1], k[5]]^2 + 4*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[k[1], k[5]]^2 - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[5]]^2 + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[5]]^2 + 12*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[5]]^2 + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[k[1], k[5]]^2 - 20*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[k[1], k[5]]^2 + 4*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[k[1], k[5]]^2 + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]^2 - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]^2 - 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]^2 - 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[5]]^2 + 20*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]]^2 - 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]]^2 + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[5]]^2 - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[5]]^2 - 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[5]]^2 - 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]]^2 + 20*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]^2 - 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[5]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]]^2 - 4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*
        d[k[1], k[2]]*d[k[1], k[5]]^2 + 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]^3 + 56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[6]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
       64*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]] + 56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
       12*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
       8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[6]] - 56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[6]] + 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       64*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       12*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[6]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]] - 8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 10*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 60*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       56*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 34*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       28*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 34*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 20*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       56*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 56*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 28*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       36*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 48*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 28*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 32*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 6*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       2*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 4*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 2*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 6*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       12*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       56*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 56*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 28*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       36*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 18*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       48*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 48*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 28*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       32*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 14*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       6*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 2*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 2*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       6*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 18*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 14*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 10*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 12*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 12*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 24*d[ep[1], k[3]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       10*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 14*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 12*d[ep[1], k[5]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       24*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       12*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 24*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 24*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 12*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 24*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 12*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       24*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 12*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 24*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 12*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       24*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[1], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
       8*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
       16*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
       2*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
       16*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
       2*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
       4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
       16*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 - 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 + 
       16*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 + 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 + 
       24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
       8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
       16*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
       16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
       24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
       8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
       16*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
       16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]^2 - 
       56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[3]] + 48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[3]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[3]] - 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[3]] + 28*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[3]] + 20*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[3]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]] + 
       20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[3]] + 
       56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[3]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[3]] - 12*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[3]] + 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[3]] - 24*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]] - 
       60*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[3]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[3]] + 16*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]] - 
       28*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[2], k[3]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
        d[k[2], k[3]] + 56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[3]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]] - 
       64*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[3]] + 56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[3]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[3]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[3]] - 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[3]] + 4*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 
       16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[3]] + 
       56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 56*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 12*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
       20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       24*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[5]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 12*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 6*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 52*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       40*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 14*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       12*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 28*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 26*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       48*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 40*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       20*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 28*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 24*d[ep[1], k[5]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       20*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 12*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 28*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 2*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 48*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       40*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 20*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       28*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 28*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 34*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 44*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       36*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 20*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 12*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       28*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 44*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 2*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       34*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 44*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 44*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[5]] - 
       6*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       6*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 12*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 18*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       6*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 20*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       20*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       12*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 12*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       20*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 12*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 20*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       20*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 12*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 20*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 38*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 20*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[2], k[5]] - 
       6*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 12*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 28*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 14*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 28*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       20*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 28*d[ep[1], k[5]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       28*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 28*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 12*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 28*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 12*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       36*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]^2*d[k[2], k[5]] + 56*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]] - 
       56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
       16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
       12*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[5]] - 24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] + 20*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] + 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]]*
        d[k[2], k[5]] + 2*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 + 12*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 - 6*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 - 8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 - 12*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 + 12*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[2], k[5]]^2 - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[2], k[5]]^2 - 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[k[2], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[2], k[5]]^2 - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[2], k[5]]^2 - 12*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[2], k[5]]^2 + 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[2], k[5]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]]^2 + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[2], k[5]]^2 + 12*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
        d[k[2], k[5]]^2 - 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]]^2 + 22*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]]^2 - 20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]]^2 + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]]^2 + 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[5]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^3 + 
       56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[6]] - 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[6]] - 56*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
       56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[6]] - 56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[6]] + 56*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
       56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[6]] + 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[6]] + 56*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
       56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[6]] - 56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[6]] + 56*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
       56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[6]] - 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[6]] + 56*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
       56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 10*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       10*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 60*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       44*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 48*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 34*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       36*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 34*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 20*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       56*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 40*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 40*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       36*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 52*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 36*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 40*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 36*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 16*d[ep[1], k[5]]*
        d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       16*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 56*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 40*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 40*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 36*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 28*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 36*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       52*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 36*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 40*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       36*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 36*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 36*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       36*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*d[k[2], k[6]] - 
       4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[6]] - 
       18*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[6]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 44*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 28*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 10*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 36*d[ep[1], k[3]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       10*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 44*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 28*d[ep[1], k[5]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       32*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 36*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 44*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       28*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 36*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       44*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 28*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       36*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 36*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 44*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       28*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 36*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 36*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 36*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 36*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       4*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 38*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 20*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[2], k[6]] + 
       56*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 40*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 48*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       2*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 16*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 2*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 56*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 40*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 48*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 56*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 40*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 48*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 56*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 40*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 48*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 56*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       40*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 48*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[6]] - 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[6]] - 56*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]] + 
       56*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[6]] - 28*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[3]]*d[k[2], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] - 
       14*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 36*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 14*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 40*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 12*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 40*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 32*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       36*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 40*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 40*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 32*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       36*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 40*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 32*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       36*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 36*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 40*d[ep[1], k[5]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 36*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 36*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 58*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       22*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 36*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 32*d[ep[1], k[5]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 32*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[2], k[6]]^2 + 32*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[2], k[6]]^2 + 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[2], k[6]]^2 - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[6]]^2 + 32*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[6]]^2 + 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[6]]^2 + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[6]]^2 - 32*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[6]]^2 - 32*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[6]]^2 + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[2], k[6]]^2 - 32*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[2], k[6]]^2 - 32*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[2], k[6]]^2 + 8*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 28*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[5]] - 64*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
        d[k[3], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]^2*d[k[3], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       12*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 16*d[ep[1], k[2]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[5]] - 
       56*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[5]] + 36*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 36*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
       16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]]*
        d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 12*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       40*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
        d[k[3], k[6]] - 12*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 56*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 20*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
       16*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]^2*d[k[3], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 24*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       44*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 32*d[ep[1], k[2]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[6]]) + 
     Ds*(-32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 64*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 48*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 48*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 44*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
       56*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 24*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 40*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 64*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 56*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[2]] + 64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]] - 32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]] - 64*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]] - 48*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]] - 48*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[2]] + 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]] + 44*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[2]] + 8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]] + 24*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]] + 64*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]] + 56*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[2]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[2]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 44*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       56*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 24*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 40*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 44*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[2]] - 8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[2]] - 24*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 8*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[5]]*
        d[k[1], k[2]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[5]]*d[k[1], k[2]] + 16*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 64*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 56*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 64*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 56*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 8*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[6]]*
        d[k[1], k[2]] - 16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[6]]*d[k[1], k[2]] - 16*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
       48*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       32*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       32*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       32*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
       36*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
       12*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
       24*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
       24*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 + 
       36*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
       12*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
       24*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
       24*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 + 
       12*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
       16*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
       36*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       12*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       24*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       24*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
       32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
       36*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       12*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       24*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       24*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
       24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
       12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
       24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
       32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^3 + 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]] - 48*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
       12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 64*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 48*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
       40*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
       48*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
       40*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
       48*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 72*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       24*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 48*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 18*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       48*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 6*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 60*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 20*d[ep[1], k[5]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       40*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 40*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 60*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 20*d[ep[1], k[5]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       40*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 40*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 24*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 60*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       20*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 40*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 40*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       12*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 48*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 60*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 20*d[ep[1], k[5]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       40*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 40*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 40*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 12*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[5]] + 48*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 
       24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       24*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       14*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       6*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       20*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
       24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 + 
       24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 - 
       24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
       24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^3 + 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]] - 64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[1], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[6]] - 12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]] - 24*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[6]] + 64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[6]] - 24*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[6]] + 24*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[6]] + 24*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
       24*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       96*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 32*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 40*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       36*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 84*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 28*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 56*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       24*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 84*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 28*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 56*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       24*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 12*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
       8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 84*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       28*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 56*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 24*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 56*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 84*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 28*d[ep[1], k[5]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       56*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 24*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 56*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 16*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[1], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 
       16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       72*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 24*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 48*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       14*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 16*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 22*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 72*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 48*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 72*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 24*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 48*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 24*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 48*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
       16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 48*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       72*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 24*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 48*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       48*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[1], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[1], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] + 12*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[1], k[6]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
       16*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
       32*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
       32*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
       4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
       8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
       48*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 - 
       16*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 - 
       32*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 - 
       32*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
       48*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 - 
       16*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 - 
       32*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 - 
       32*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 - 
       48*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
       16*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
       32*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
       32*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
       32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
       48*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
       16*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
       32*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
       32*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
       32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]^2 - 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[3]] + 32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[3]] + 64*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]] - 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[3]] + 64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[3]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]] + 
       32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[3]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[3]] - 32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[3]] - 64*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[3]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[3]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]] - 
       48*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[2], k[3]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
        d[k[2], k[3]] + 64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[3]] - 64*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]] - 
       64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[3]] - 64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[6]]*d[k[2], k[3]] + 48*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] + 32*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[3]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 40*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 40*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[5]] + 64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[5]] - 64*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
       64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       64*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
       64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
       40*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
       40*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[5]] + 64*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
       64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
       32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[2], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
       32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 64*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[5]] + 64*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
       64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[5]] + 36*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       36*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 88*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       72*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 80*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 6*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       24*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 6*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       80*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 64*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 72*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], ep[4]]*
        d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       24*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 80*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 64*d[ep[1], k[5]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       72*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 24*d[ep[1], ep[4]]*d[ep[2], k[5]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[4]]*
        d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       16*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 80*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 64*d[ep[1], k[5]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       72*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 24*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 24*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 80*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 72*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 24*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 24*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
       24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[5]] + 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]^2*d[k[2], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 12*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 72*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       56*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 18*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       24*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 6*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 36*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 36*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       36*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 72*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 64*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 24*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 72*d[ep[1], k[2]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       56*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 24*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 72*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 56*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 64*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 24*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 32*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 72*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 56*d[ep[1], k[5]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       64*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 24*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[3]]*
        d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[5]] + 24*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[2], k[5]] - 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[5]]*d[k[2], k[5]] - 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
       12*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       56*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 48*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       18*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 16*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 26*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 56*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 40*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       48*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 56*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 40*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 48*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 56*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 40*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 48*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       16*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 56*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 48*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 32*d[ep[1], ep[2]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       56*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 40*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 48*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*
        d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[1], k[6]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
       24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
        d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*
        d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]] - 
       64*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[3]]*d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] + 
       16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
       48*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
       48*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
       48*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
       16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
       20*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
       12*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
       48*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 - 
       48*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 - 
       48*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 - 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 + 
       48*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 - 
       48*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 - 
       48*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 - 
       16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 - 
       48*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
       48*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
       48*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
       16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
       48*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
       48*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
       48*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
       16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
       16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 - 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 + 
       8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 + 
       12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]^2 + 
       16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]^2 + 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^3 + 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[2], k[6]] - 64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
        d[ep[4], k[1]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
       64*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
        d[k[2], k[6]] - 64*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[1]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[2], k[6]] + 64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
       64*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
        d[k[2], k[6]] - 64*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
        d[ep[4], k[2]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
       64*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 64*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
        d[ep[4], k[6]]*d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
       64*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
        d[k[2], k[6]] + 64*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
        d[ep[4], k[6]]*d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       112*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 80*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 96*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 32*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 40*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       36*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 64*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 80*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       32*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 64*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 80*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       32*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 96*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 80*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 96*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 64*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 80*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       32*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
        d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
        d[k[1], k[2]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
       16*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
       32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
        d[k[2], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
        d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 80*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       48*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       32*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       80*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 48*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 32*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       80*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 48*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 32*d[ep[1], ep[4]]*
        d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
       80*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 48*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 32*d[ep[1], ep[3]]*
        d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
        d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 80*d[ep[1], k[2]]*d[ep[2], ep[3]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 48*d[ep[1], k[5]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       64*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
        d[k[1], k[5]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*
        d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
       32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
        d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
        d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[2], k[6]] - 
       112*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 80*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 96*d[ep[1], k[6]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 32*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       8*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 112*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 80*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 96*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       32*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 112*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 80*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 96*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       32*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[6]]*
        d[k[2], k[6]] - 112*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 80*d[ep[1], k[5]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 96*d[ep[1], k[6]]*
        d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       32*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
        d[k[1], k[6]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*
        d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 112*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       80*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 96*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[5]]*
        d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*
        d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
       32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
        d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
        d[k[1], k[6]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
        d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] + 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
        d[k[2], k[6]] - 64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[3]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]] - 
       32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
        d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[3]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 64*d[ep[1], k[2]]*d[ep[2], k[3]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       64*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 20*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       20*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[2], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*
        d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 64*d[ep[1], k[5]]*
        d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       64*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
        d[k[2], k[5]]*d[k[2], k[6]] - 64*d[ep[1], k[5]]*d[ep[2], ep[4]]*
        d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*
        d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       64*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], ep[3]]*
        d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 64*d[ep[1], k[2]]*
        d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
       64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*
        d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
        d[k[2], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 
       4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[2], k[6]] - 
       64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 
       64*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 
       64*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 
       64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 - 
       64*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 - 
       64*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 + 
       64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 - 
       64*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 - 
       64*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 - 
       64*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
       64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
       64*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 - 
       64*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 + 
       64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 + 
       64*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
       20*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 20*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 48*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
       48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
       12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[5]] - 12*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[5]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[5]] - 48*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
        d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
        d[k[3], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 12*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[1], k[6]]*d[k[3], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
       32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 40*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
       8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
        d[k[3], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]]*d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[5]] + 
       32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]*
        d[k[3], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[6]]*d[k[3], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[6]]*d[k[3], k[5]] - 48*d[ep[1], k[2]]*
        d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       80*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 72*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] - 64*d[ep[1], k[2]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
       64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[3], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[3], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]^2*d[k[3], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       24*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]*d[k[3], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
       32*d[ep[1], k[6]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[3], k[6]] - 48*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
        d[k[1], k[5]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[5]]^2*d[k[3], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] - 
       8*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
        d[k[3], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[3], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] + 16*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
       32*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       40*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 40*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 24*d[ep[1], k[6]]*d[ep[2], k[5]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
       64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
        d[k[3], k[6]] - 64*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
        d[k[2], k[5]]*d[k[3], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[6]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
       24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
        d[k[3], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
        d[k[2], k[5]]*d[k[3], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
        d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
        d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[6]] + 
       64*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
        d[k[3], k[6]] - 64*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
        d[k[2], k[6]]*d[k[3], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
        d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] + 
       Df*(4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[2]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[1], k[2]] - 4*d[ep[1], k[6]]*d[ep[2], k[5]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[2]] + 4*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[2]] - 4*d[ep[1], k[5]]*d[ep[2], k[5]]*
          d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[2]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[2]] + 4*d[ep[1], k[6]]*d[ep[2], k[5]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
         4*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[2]] + 4*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[1], k[2]] - 4*d[ep[1], k[5]]*d[ep[2], k[5]]*
          d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[1], k[2]] - 4*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
          d[ep[4], k[5]]*d[k[1], k[2]] + 4*d[ep[1], k[5]]*d[ep[2], k[5]]*
          d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
         4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
          d[k[1], k[2]] + 2*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^2 + 4*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^2 - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^2 - 8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^2 - 2*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^2 - 2*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^2 - 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[2]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
          d[k[1], k[2]]^2 - 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
          d[k[1], k[2]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
          d[k[1], k[2]]^2 + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
          d[k[1], k[2]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[2]]^2 + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
          d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[2]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[2]]^2 - 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^3 - 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[1], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[1], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
          d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
         4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
          d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
          d[k[1], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
          d[ep[4], k[6]]*d[k[1], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[1], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
         16*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[1], k[5]] + 2*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[1], k[5]] + 2*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
         2*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[1], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*
          d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], ep[4]]*
          d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
          d[k[1], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
          d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], ep[4]]*d[ep[2], k[5]]*
          d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
         4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[1], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
         4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
          d[k[1], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] + 
         2*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
         4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
         8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
         2*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 + 
         8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 - 
         4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 + 
         8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 + 
         4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
         8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
         4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
         8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
         4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
         2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]^2 - 
         4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[6]] - 2*d[ep[1], k[2]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[1], k[6]] + 6*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[3]]*d[ep[2], k[5]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
          d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], k[5]]*
          d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
         8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
          d[k[1], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
         4*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
          d[k[1], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 2*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] + 
         2*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[1], k[6]] - 2*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
         8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[1], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
          d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 4*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
         8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[5]]*
          d[k[1], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
          d[k[1], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[5]]*d[k[1], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 2*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[3]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[3]] - 4*d[ep[1], k[6]]*d[ep[2], k[5]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[3]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
          d[k[2], k[3]] - 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[2], k[3]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[2], k[3]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[2], k[3]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[3]] - 4*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[2], k[3]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
          d[k[2], k[3]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[6]]*d[k[2], k[3]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
          d[k[2], k[3]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[1], k[6]]*d[k[2], k[3]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 4*d[ep[1], k[2]]*
          d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[2], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
          d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[1]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[2], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
          d[ep[4], k[2]]*d[k[2], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
          d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[6]]*d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
         2*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[3]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[5]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
         2*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[3]]*d[ep[2], k[6]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
         2*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], ep[4]]*
          d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], k[6]]*
          d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*
          d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
          d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], k[6]]*
          d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[2]]*
          d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         4*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
          d[k[2], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
          d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[4]]*
          d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         4*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*
          d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
          d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[6]]*
          d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*
          d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], ep[3]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], k[6]]*
          d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[3]]*d[ep[2], k[6]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
          d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
          d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
          d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[2], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[2], k[5]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
         2*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[2], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[3]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
         8*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[5]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
         2*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[2], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
          d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
          d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], k[6]]*
          d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*
          d[k[2], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
          d[k[1], k[5]]*d[k[2], k[5]] - 12*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], k[5]]*
          d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
         8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
          d[k[2], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
          d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 12*d[ep[1], k[2]]*
          d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
         8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
          d[k[2], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
          d[k[1], k[5]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], ep[3]]*
          d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
         8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
          d[k[2], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
          d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
          d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 8*d[ep[1], k[6]]*
          d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
          d[k[2], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[5]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
         2*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
          d[k[2], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[3]]*
          d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
         2*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
          d[k[2], k[5]] - 4*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*
          d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[4]]*
          d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
         4*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[6]]*
          d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
          d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[4]]*
          d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
         4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
          d[k[2], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
          d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*
          d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
          d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], ep[3]]*
          d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
         4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
          d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 
         4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
          d[k[2], k[5]] - 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
          d[k[2], k[5]] + 4*d[ep[1], k[6]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[2], k[3]]*d[k[2], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]] + 
         8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
          d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[2], k[3]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] + 2*d[ep[1], k[2]]*
          d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
         4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
         2*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
         8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
         8*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
         8*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
         8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 + 
         8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 + 
         8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 + 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 - 
         8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 + 
         8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 + 
         8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 + 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 + 
         8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
         8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
         8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
         4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
         8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
         8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
         8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
         4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
         2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]^2 - 
         2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]^2 - 
         4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]^2 - 
         4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[2], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[ep[4], k[1]]*d[k[2], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[2], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[2], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[2], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
          d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
         4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[2], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
          d[ep[4], k[2]]*d[k[2], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
         4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
          d[k[2], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[1]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[2], k[6]] - 2*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[6]] + 2*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[6]] + 4*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[5]]*
          d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
         4*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
          d[k[2], k[6]] - 4*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
          d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 
         4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
          d[k[2], k[6]] + 4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
         4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
          d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
          d[k[1], k[2]]*d[k[2], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]^2*d[k[2], k[6]] + 2*d[ep[1], k[2]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
         2*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[2], k[6]] - 4*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[5]]*
          d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[4]]*
          d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
         4*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*
          d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
          d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
          d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[3]]*
          d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
         4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
          d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
          d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
          d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 
         4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
          d[k[2], k[6]] + 2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
          d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[2], k[3]]*d[k[2], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
          d[k[2], k[6]] - 4*d[ep[1], k[5]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
          d[k[2], k[3]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] + 
         2*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
          d[k[2], k[6]] - 4*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[2], k[5]]*d[k[2], k[6]] - 2*d[ep[1], k[5]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
         4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]*
          d[k[2], k[6]] + 4*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
          d[k[2], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[3]]*d[ep[2], k[1]]*
          d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
          d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
         4*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*
          d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
          d[k[2], k[5]]*d[k[2], k[6]] - 6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 2*d[ep[1], ep[2]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 
         4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]*
          d[k[2], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[3], k[5]] - 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
          d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
         4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
          d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
          d[k[2], k[5]]*d[k[3], k[5]] + 4*d[ep[1], k[2]]*d[ep[2], k[1]]*
          d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] - 
         4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
          d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
          d[k[2], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 4*d[ep[1], k[5]]*
          d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
         4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
          d[k[3], k[6]] + 4*d[ep[1], k[2]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
          d[k[2], k[5]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
          d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[6]]))))/
   (16*d[k[1], k[2]]*(d[k[1], k[2]] - d[k[1], k[5]] - d[k[1], k[6]])*
    (d[k[1], k[2]] - d[k[1], k[5]] - d[k[2], k[5]])*d[k[2], k[5]])|>
