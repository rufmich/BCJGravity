(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
<|"Graph" -> {{-1}, {-2}, {-3}, {-4}, {-65, -6, -5}, {-66, 2, 1}, 
   {66, -7, 65}, {-70, 6, 7}, {-71, 3, 4}, {71, 5, 70}}, 
 "momCons" -> {k[4] -> -k[1] - k[2] - k[3], 
   k[7] -> k[1] + k[2] - k[5] - k[6], k[65] -> -k[5] - k[6], 
   k[66] -> k[1] + k[2], k[70] -> k[1] + k[2] - k[5], k[71] -> -k[1] - k[2]}, 
 "cutLines" -> k[5, 6, 7], "extraOS" -> <|d[k[1], k[1]] :> 0, 
   d[ep[1], k[1]] :> 0, d[epT[1], k[1]] :> 0, d[k[2], k[2]] :> 0, 
   d[ep[2], k[2]] :> 0, d[epT[2], k[2]] :> 0, d[k[3], k[3]] :> 0, 
   d[ep[3], k[3]] :> 0, d[epT[3], k[3]] :> 0, d[k[4], k[4]] :> 0, 
   d[ep[4], k[4]] :> 0, d[epT[4], k[4]] :> 0, 
   d[k[1], k[3]] :> -d[k[1], k[2]] - d[k[2], k[3]], 
   d[ep[4], k[3]] :> -d[ep[4], k[1]] - d[ep[4], k[2]], 
   d[epT[4], k[3]] :> -d[epT[4], k[1]] - d[epT[4], k[2]], d[l[5], l[5]] :> 0, 
   d[l[5], l[6]] :> -d[k[1], k[2]] + d[k[1], k[5]] + d[k[1], k[6]] + 
     d[k[2], k[5]] + d[k[2], k[6]], d[l[6], l[6]] :> 0|>, 
 "cutExpression" -> 
  -((128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[1], k[2]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]] + 
      64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[1], k[2]] - 512*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]] + 
      128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[2]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[2]] + 128*DsT*d[epT[1], k[6]]*
       d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]] + 
      512*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[2]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[2]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]] + 
      128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[1], k[2]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[2]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
      64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[1], k[2]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[2]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[2]] - 512*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
      128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[2]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[2]] + 128*DsT*d[epT[1], k[6]]*
       d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
      512*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[2]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[2]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]] - 
      128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[1], k[2]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[2]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]] - 
      64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[1], k[2]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[1], k[2]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[2]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
       d[k[1], k[2]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[2]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
       d[k[1], k[2]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[2]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]] + 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
       d[k[1], k[2]] + 512*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[2]] - 128*DsT*d[epT[1], k[5]]*
       d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[2]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
      512*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[2]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[2]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
      512*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[2]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[2]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
      512*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[2]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[2]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]] - 
      256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2 + 
      128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]^2 + 192*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 64*DsT*d[epT[1], k[6]]*
       d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2 + 
      256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2 + 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]^2 - 192*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]^2 + 64*DsT*d[epT[1], k[2]]*
       d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2 - 
      256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]^2 + 
      256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[2]]^2 - 
      256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[2]]^2 + 
      256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]^2 + 
      256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 - 
      256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 - 
      256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 - 
      128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 + 
      320*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]]^2 - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[2]]^2 + 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*
       d[epT[4], k[2]]*d[k[1], k[2]]^2 - 256*d[epT[1], epT[3]]*
       d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 + 
      256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 - 
      128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 + 
      320*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]]^2 - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[2]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[2]]^2 + 128*d[epT[1], epT[2]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]^2 - 
      320*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]^2 + 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[2]]^2 - 320*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[2]]^2 + 128*DsT*d[epT[1], epT[2]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]^2 - 
      128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^3 + 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^3 + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]] + 
      256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]] + 
      256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]] - 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]] - 
      256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
      256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] - 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]] + 
      512*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      512*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      512*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 512*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[k[1], k[2]]*d[k[1], k[5]] + 512*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      512*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
       d[k[1], k[2]]*d[k[1], k[5]] + 512*d[epT[1], epT[3]]*d[epT[2], k[1]]*
       d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      512*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[2]]*d[k[1], k[5]] + 128*DsT*d[epT[1], epT[2]]*
       d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 512*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 512*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*
       d[k[1], k[5]] - 256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]^2 + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]^2 - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]^2 + 128*d[epT[1], k[6]]*
       d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 - 
      64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]^2 + 256*d[epT[1], k[2]]*d[epT[2], k[3]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]^2 - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]^2 + 64*DsT*d[epT[1], k[2]]*
       d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 - 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2 + 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]^2 - 256*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[1]]*d[k[1], k[5]]^2 + 256*d[epT[1], epT[4]]*
       d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[1], k[5]]^2 - 
      256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[1], k[5]]^2 + 
      256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]^2 + 
      256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 - 
      256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 - 
      256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 + 
      64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]]^2 - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[5]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[5]]^2 + 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*
       d[epT[4], k[2]]*d[k[1], k[5]]^2 - 256*d[epT[1], epT[3]]*
       d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 + 
      256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 + 
      64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]]^2 - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[1], k[5]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[5]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[1], k[5]]^2 + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[5]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[5]]^2 + 64*DsT*d[epT[1], epT[2]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]]^2 + 
      64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]]^2 + 
      64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]]^2 + 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[1], k[5]]^2 - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[6]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[1], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[6]] - 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[6]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[6]] + 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[1], k[6]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[6]] - 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[6]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[6]] + 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[1], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
       d[k[1], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]] - 
      128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[6]] + 
      64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[6]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[6]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]] + 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]] - 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[1], k[6]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 320*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[k[1], k[2]]*d[k[1], k[6]] + 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
       d[k[1], k[2]]*d[k[1], k[6]] + 192*d[epT[1], epT[3]]*d[epT[2], k[1]]*
       d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      192*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      192*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 192*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 192*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*
       d[k[1], k[6]] - 256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[1], k[6]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
      128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[1], k[6]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[1], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[1], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[1], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[1], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
       d[k[1], k[6]] + 256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[k[1], k[5]]*d[k[1], k[6]] - 256*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
      256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]*
       d[k[1], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
       d[k[1], k[5]]*d[k[1], k[6]] - 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*
       d[epT[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
      256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]]*
       d[k[1], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[5]]*d[k[1], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
      256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
       d[k[1], k[6]] - 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
       d[k[1], k[5]]*d[k[1], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
      64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]]*
       d[k[1], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[1], k[5]]*d[k[1], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 
      64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]]*
       d[k[1], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[1], k[5]]*d[k[1], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[5]]*d[k[1], k[6]] + 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
       d[k[1], k[6]] - 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
       d[k[1], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[6]]^2 - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]^2 + 128*d[epT[1], k[6]]*
       d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]^2 - 
      64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[6]]^2 - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]^2 + 64*DsT*d[epT[1], k[2]]*
       d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[6]]^2 - 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]^2 + 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
       d[k[1], k[6]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[6]]^2 + 64*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]]^2 - 
      64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]]^2 - 
      256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[2], k[3]] + 
      512*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
       d[k[2], k[3]] - 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]^2*d[k[2], k[3]] + 192*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[3]] - 
      256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
       d[k[2], k[3]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*
       d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
      256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
      256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]] - 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]] - 
      256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
      256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] - 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]] + 
      512*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      512*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      512*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 512*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 512*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      512*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 512*d[epT[1], epT[3]]*d[epT[2], k[1]]*
       d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      512*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      576*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 256*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 512*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
       d[k[1], k[2]]*d[k[2], k[5]] - 512*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      576*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 256*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      576*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 256*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      576*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 256*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[2], k[5]] - 
      192*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*
       d[k[2], k[5]] - 512*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[2], k[5]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
      512*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[2], k[5]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      512*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 512*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[k[1], k[5]]*d[k[2], k[5]] - 512*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
      512*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
       d[k[1], k[5]]*d[k[2], k[5]] - 512*d[epT[1], epT[3]]*d[epT[2], k[1]]*
       d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      512*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[5]]*d[k[2], k[5]] - 128*DsT*d[epT[1], epT[2]]*
       d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
      128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
      512*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
       d[k[2], k[5]] - 512*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
       d[k[1], k[5]]*d[k[2], k[5]] + 512*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
      128*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
      128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]]*
       d[k[2], k[5]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 256*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 64*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]^2*d[k[2], k[5]] - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
       d[k[2], k[5]] - 256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[6]]*d[k[2], k[5]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[6]]*d[k[2], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[1], k[6]]*d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[k[1], k[6]]*d[k[2], k[5]] - 256*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
       d[k[1], k[6]]*d[k[2], k[5]] - 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*
       d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[6]]*d[k[2], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
       d[k[1], k[6]]*d[k[2], k[5]] + 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      192*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 256*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 64*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]^2*
       d[k[2], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[6]]^2*d[k[2], k[5]] + 512*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] - 
      512*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[3]]*
       d[k[2], k[5]] - 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[3]]*d[k[2], k[5]] - 256*d[epT[1], k[3]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]^2 + 64*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]^2 - 64*DsT*d[epT[1], k[5]]*
       d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 + 
      128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 - 
      64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[2], k[5]]^2 + 256*d[epT[1], k[2]]*d[epT[2], k[3]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]^2 - 64*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]^2 + 64*DsT*d[epT[1], k[2]]*
       d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 - 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2 + 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*
       d[k[2], k[5]]^2 - 256*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[1]]*d[k[2], k[5]]^2 + 256*d[epT[1], epT[4]]*
       d[epT[2], k[1]]*d[epT[3], k[1]]*d[k[2], k[5]]^2 - 
      256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[2]]*d[k[2], k[5]]^2 + 
      256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[2], k[5]]^2 + 
      256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 - 
      256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 - 
      256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 + 
      64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[2], k[5]]^2 + 192*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[2], k[5]]^2 - 128*DsT*d[epT[1], epT[2]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]]^2 + 
      256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 - 
      256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 + 
      256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 + 
      64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[2], k[5]]^2 + 192*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[2], k[5]]^2 - 128*DsT*d[epT[1], epT[2]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]]^2 - 
      64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]]^2 + 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[2], k[5]]^2 - 64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
       d[k[2], k[5]]^2 + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[2], k[5]]^2 - 192*d[epT[1], epT[2]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]]^2 + 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[2], k[5]]^2 - 192*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[2], k[5]]^2 + 128*DsT*d[epT[1], epT[2]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]]^2 - 
      192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]]^2 + 
      192*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[2], k[5]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[2], k[5]]^2 - 128*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]]^2 + 
      128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]]^2 - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[5]]^2 - 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[2], k[3]]*d[k[2], k[5]]^2 + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[2], k[5]]^3 - 64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[2], k[5]]^3 - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[2], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[2], k[6]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[2], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[2], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[6]] - 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[2], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[6]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[2], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[6]] + 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[2], k[6]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[2], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[6]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[2], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[2], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[6]] - 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[2], k[6]] + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[6]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[2], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[6]] + 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[6]]*d[epT[4], k[2]]*
       d[k[2], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[6]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[2], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[2], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[6]] - 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[5]]*
       d[k[2], k[6]] - 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[2], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[6]] - 
      128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[2], k[6]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[2], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[6]] + 
      64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[2], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[6]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[2], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[2], k[6]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[6]] + 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[2], k[6]] - 128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[2], k[6]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[6]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[2], k[6]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[2], k[6]] + 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[6]] - 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], k[2]]*d[epT[4], k[6]]*
       d[k[2], k[6]] + 192*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 320*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
      192*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 320*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      192*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 192*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
      192*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 192*d[epT[1], epT[3]]*d[epT[2], k[1]]*
       d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      192*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 384*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      192*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 192*d[epT[1], epT[3]]*d[epT[2], k[1]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
      192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 384*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      192*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 256*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      384*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      384*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      448*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[2], k[6]] - 
      192*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*
       d[k[2], k[6]] - 256*d[epT[1], k[3]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[2], k[6]] + 192*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[2], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[k[1], k[5]]*d[k[2], k[6]] - 256*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
      256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
       d[k[1], k[5]]*d[k[2], k[6]] - 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*
       d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[1], k[5]]*d[k[2], k[6]] - 128*DsT*d[epT[1], epT[2]]*
       d[epT[3], k[5]]*d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
      192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[5]]*
       d[k[2], k[6]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
      256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[1], k[5]]*
       d[k[2], k[6]] - 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
       d[k[1], k[5]]*d[k[2], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
      192*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[1], k[5]]*
       d[k[2], k[6]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
      192*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[5]]*
       d[k[2], k[6]] - 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      192*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      192*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      192*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 256*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 64*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]^2*d[k[2], k[6]] - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
       d[k[2], k[6]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[6]]*d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
      128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[1], k[6]]*
       d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 
      128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[1], k[6]]*
       d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
      128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[1], k[6]]*
       d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[1], k[6]]*d[k[2], k[6]] - 
      128*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[1], k[6]]*
       d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[1], k[6]]*d[k[2], k[6]] - 
      512*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
       d[k[2], k[6]] + 256*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 128*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
       d[k[2], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[6]]^2*d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]^2*d[k[2], k[6]] + 
      192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
       d[k[2], k[6]] - 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[2], k[3]]*d[k[2], k[6]] - 256*d[epT[1], k[3]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      192*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[3]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 192*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[2], k[5]]*d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], epT[4]]*d[epT[3], k[1]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[1]]*
       d[k[2], k[5]]*d[k[2], k[6]] - 256*d[epT[1], k[2]]*d[epT[2], epT[4]]*
       d[epT[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      256*d[epT[1], epT[4]]*d[epT[2], k[1]]*d[epT[3], k[2]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[1]]*
       d[k[2], k[5]]*d[k[2], k[6]] - 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*
       d[epT[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      256*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[1]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[1]]*
       d[k[2], k[5]]*d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      320*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      256*d[epT[1], k[2]]*d[epT[2], epT[3]]*d[epT[4], k[2]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 256*d[epT[1], epT[3]]*d[epT[2], k[1]]*d[epT[4], k[2]]*
       d[k[2], k[5]]*d[k[2], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      64*d[epT[1], epT[2]]*d[epT[3], k[5]]*d[epT[4], k[2]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[5]]*
       d[epT[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      320*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      64*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[5]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      64*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[5]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      320*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*
       d[epT[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      320*d[epT[1], epT[2]]*d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 192*DsT*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      576*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 384*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 320*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      256*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 384*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[5]]*d[k[2], k[6]] - 256*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[3]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[2], k[5]]^2*d[k[2], k[6]] - 192*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]^2*d[k[2], k[6]] + 
      128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2 - 
      64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[2], k[6]]^2 + 128*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[6]]^2 - 64*DsT*d[epT[1], k[6]]*
       d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2 - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2 + 
      64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*
       d[k[2], k[6]]^2 - 128*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[2], k[6]]^2 + 64*DsT*d[epT[1], k[2]]*
       d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2 + 
      128*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*d[k[2], k[6]]^2 - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], k[6]]*d[epT[4], k[1]]*
       d[k[2], k[6]]^2 + 128*d[epT[1], epT[2]]*d[epT[3], k[6]]*
       d[epT[4], k[2]]*d[k[2], k[6]]^2 - 64*DsT*d[epT[1], epT[2]]*
       d[epT[3], k[6]]*d[epT[4], k[2]]*d[k[2], k[6]]^2 - 
      128*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*d[k[2], k[6]]^2 + 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], k[1]]*d[epT[4], k[6]]*
       d[k[2], k[6]]^2 - 128*d[epT[1], epT[2]]*d[epT[3], k[2]]*
       d[epT[4], k[6]]*d[k[2], k[6]]^2 + 64*DsT*d[epT[1], epT[2]]*
       d[epT[3], k[2]]*d[epT[4], k[6]]*d[k[2], k[6]]^2 - 
      384*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]]^2 + 
      192*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[2], k[6]]^2 + 192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[2], k[6]]^2 - 128*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]]^2 + 
      256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]]^2 - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[6]]^2 + 320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[2], k[5]]*d[k[2], k[6]]^2 - 192*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]]^2 + 
      128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[6]]^3 - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[6]]^3 + 
      128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[3], k[5]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
      128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[3], k[5]] + 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[3], k[5]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[3], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
      128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[3], k[5]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[3], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[3], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
      64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
       d[k[3], k[5]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[5]] + 64*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]^2*d[k[3], k[5]] - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]^2*
       d[k[3], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[6]]*d[k[3], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[3], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
      128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
       d[k[3], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] - 64*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
       d[k[3], k[5]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
       d[k[3], k[5]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
       d[k[3], k[5]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] + 128*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]]*d[k[3], k[5]] - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]]*
       d[k[3], k[5]] - 192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[5]]*d[k[3], k[5]] + 64*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2*d[k[3], k[5]] - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2*
       d[k[3], k[5]] - 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[2], k[6]]*d[k[3], k[5]] + 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[5]] + 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
       d[k[3], k[5]] - 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[5]] + 
      256*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]]*
       d[k[3], k[5]] + 192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[2], k[6]]*d[k[3], k[5]] - 128*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
      64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]]*
       d[k[3], k[5]] - 64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 512*d[epT[1], k[5]]*
       d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
      128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[3], k[6]] - 256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[3], k[6]] + 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
      512*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[3], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[2]]*
       d[k[3], k[6]] - 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
      320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*d[k[3], k[6]] - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]^2*
       d[k[3], k[6]] + 256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[1], k[5]]*d[k[3], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[3], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[3], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[5]]*
       d[k[3], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
      64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
       d[k[3], k[6]] + 128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]^2*d[k[3], k[6]] + 
      128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[3], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
      128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[6]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[3], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[6]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[3], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[3], k[6]] - 
      128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
       d[k[3], k[6]] + 64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] - 64*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
      256*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
       d[k[3], k[6]] - 128*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
      256*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
       d[k[3], k[6]] - 128*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
       d[k[3], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
      256*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[5]]*
       d[k[3], k[6]] + 128*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
      576*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
       d[k[3], k[6]] + 256*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[6]] + 128*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]]*d[k[3], k[6]] - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[5]]*
       d[k[3], k[6]] + 64*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[5]]*d[k[3], k[6]] - 64*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] + 
      192*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2*d[k[3], k[6]] - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]^2*
       d[k[3], k[6]] + 128*d[epT[1], k[5]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*
       d[k[2], k[6]]*d[k[3], k[6]] - 64*DsT*d[epT[1], k[5]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[6]] + 
      128*d[epT[1], k[6]]*d[epT[2], k[1]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
       d[k[3], k[6]] - 64*DsT*d[epT[1], k[6]]*d[epT[2], k[1]]*
       d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[6]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[5]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
       d[k[3], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[5]]*
       d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[6]] - 
      128*d[epT[1], k[2]]*d[epT[2], k[6]]*d[epT[3], epT[4]]*d[k[2], k[6]]*
       d[k[3], k[6]] + 64*DsT*d[epT[1], k[2]]*d[epT[2], k[6]]*
       d[epT[3], epT[4]]*d[k[2], k[6]]*d[k[3], k[6]] - 
      384*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[2]]*d[k[2], k[6]]*
       d[k[3], k[6]] + 192*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[6]] + 192*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 
      128*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[5]]*d[k[2], k[6]]*
       d[k[3], k[6]] + 128*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[1], k[6]]*
       d[k[2], k[6]]*d[k[3], k[6]] - 64*DsT*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[1], k[6]]*d[k[2], k[6]]*d[k[3], k[6]] + 
      320*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[5]]*d[k[2], k[6]]*
       d[k[3], k[6]] - 192*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*
       d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] + 128*d[epT[1], epT[2]]*
       d[epT[3], epT[4]]*d[k[2], k[6]]^2*d[k[3], k[6]] - 
      64*DsT*d[epT[1], epT[2]]*d[epT[3], epT[4]]*d[k[2], k[6]]^2*
       d[k[3], k[6]])*(-112*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
       d[ep[4], k[1]]*d[k[1], k[2]] - 356*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
      112*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
       d[k[1], k[2]] + 356*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
       d[ep[4], k[1]]*d[k[1], k[2]] + 340*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
      156*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
       d[k[1], k[2]] - 340*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
       d[ep[4], k[1]]*d[k[1], k[2]] - 156*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
      112*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
       d[k[1], k[2]] - 356*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
       d[ep[4], k[2]]*d[k[1], k[2]] + 112*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
      356*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
       d[k[1], k[2]] + 340*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
       d[ep[4], k[2]]*d[k[1], k[2]] + 156*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
      340*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
       d[k[1], k[2]] - 156*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
       d[ep[4], k[2]]*d[k[1], k[2]] + 112*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
      356*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
       d[k[1], k[2]] - 112*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
       d[ep[4], k[5]]*d[k[1], k[2]] - 356*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
      112*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
       d[k[1], k[2]] + 356*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
       d[ep[4], k[5]]*d[k[1], k[2]] - 112*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
      356*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
       d[k[1], k[2]] - 340*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[ep[4], k[6]]*d[k[1], k[2]] - 156*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
      340*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
       d[k[1], k[2]] + 156*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
       d[ep[4], k[6]]*d[k[1], k[2]] - 340*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
      156*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[1], k[2]] + 340*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
       d[ep[4], k[6]]*d[k[1], k[2]] + 156*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
      84*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
      32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
      32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
      84*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
      64*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
      64*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
      32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
      64*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
      32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 
      64*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 
      16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 + 
      44*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
      56*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
      16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 - 
      44*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 + 
      56*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[2]]^2 + 
      16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 + 
      44*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
      56*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
      16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 - 
      44*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 + 
      56*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]^2 + 
      44*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 + 
      40*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 - 
      16*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 - 
      44*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 - 
      40*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 + 
      16*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[k[1], k[2]]^2 + 
      100*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 + 
      56*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
      8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
      100*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
      56*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 + 
      8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[k[1], k[2]]^2 - 
      16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
      44*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
      56*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
      16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
      44*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
      56*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
      44*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
      32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 + 
      64*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]^2 - 
      16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
      44*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
      56*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
      16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 + 
      44*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
      56*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
      44*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
      32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
      64*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]^2 - 
      44*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
      40*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
      16*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
      44*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
      40*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
      16*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
      32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 + 
      32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]^2 - 
      100*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
      56*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
      8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
      100*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
      56*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
      8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
      64*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 + 
      64*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]^2 - 
      32*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^3 + 
      32*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^3 + 
      56*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^3 - 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
       d[k[1], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
       d[ep[4], k[1]]*d[k[1], k[5]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
       d[k[1], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
       d[ep[4], k[1]]*d[k[1], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
       d[k[1], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
       d[ep[4], k[2]]*d[k[1], k[5]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
       d[k[1], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
       d[ep[4], k[2]]*d[k[1], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
       d[k[1], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
       d[ep[4], k[5]]*d[k[1], k[5]] + 48*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
      48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
       d[k[1], k[5]] + 48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[ep[4], k[6]]*d[k[1], k[5]] + 48*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
      48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
       d[k[1], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
       d[ep[4], k[6]]*d[k[1], k[5]] + 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[1], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
       d[ep[4], k[6]]*d[k[1], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
      148*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 234*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      148*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 64*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[3]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 64*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[5]] + 234*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      64*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 64*d[ep[1], k[5]]*d[ep[2], ep[4]]*
       d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      64*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 96*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[k[1], k[2]]*d[k[1], k[5]] + 64*d[ep[1], ep[4]]*d[ep[2], k[5]]*
       d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 64*d[ep[1], ep[4]]*
       d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 64*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
       d[k[1], k[2]]*d[k[1], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], ep[4]]*
       d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 96*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      64*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 64*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 64*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      128*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 128*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
       d[k[1], k[2]]*d[k[1], k[5]] + 96*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 96*d[ep[1], ep[3]]*d[ep[2], k[1]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 64*d[ep[1], ep[3]]*
       d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      64*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 108*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 286*d[ep[1], ep[2]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      96*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], ep[3]]*
       d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 96*d[ep[1], ep[3]]*
       d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      64*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 64*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*
       d[k[1], k[2]]*d[k[1], k[5]] + 108*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 60*d[ep[1], ep[2]]*
       d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
      158*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 64*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 64*d[ep[1], ep[3]]*d[ep[2], k[1]]*
       d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
       d[k[1], k[5]] - 60*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
       d[k[1], k[2]]*d[k[1], k[5]] + 128*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 128*d[ep[1], ep[3]]*
       d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
      286*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
       d[k[1], k[5]] + 158*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[1], k[2]]*d[k[1], k[5]] - 80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]^2*d[k[1], k[5]] + 80*d[ep[1], k[3]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 80*d[ep[1], k[2]]*d[ep[2], k[3]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 80*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[1]]*d[k[1], k[5]]^2 - 80*d[ep[1], ep[4]]*d[ep[2], k[1]]*
       d[ep[3], k[1]]*d[k[1], k[5]]^2 + 80*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[2]]*d[k[1], k[5]]^2 - 80*d[ep[1], ep[4]]*d[ep[2], k[1]]*
       d[ep[3], k[2]]*d[k[1], k[5]]^2 - 80*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[1]]*d[k[1], k[5]]^2 + 80*d[ep[1], ep[3]]*d[ep[2], k[1]]*
       d[ep[4], k[1]]*d[k[1], k[5]]^2 + 80*d[ep[1], ep[2]]*d[ep[3], k[2]]*
       d[ep[4], k[1]]*d[k[1], k[5]]^2 + 24*d[ep[1], ep[2]]*d[ep[3], k[6]]*
       d[ep[4], k[1]]*d[k[1], k[5]]^2 - 80*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[2]]*d[k[1], k[5]]^2 + 80*d[ep[1], ep[3]]*d[ep[2], k[1]]*
       d[ep[4], k[2]]*d[k[1], k[5]]^2 - 80*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[2]]*d[k[1], k[5]]^2 + 24*d[ep[1], ep[2]]*d[ep[3], k[6]]*
       d[ep[4], k[2]]*d[k[1], k[5]]^2 - 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[6]]*d[k[1], k[5]]^2 - 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*
       d[ep[4], k[6]]*d[k[1], k[5]]^2 + 40*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[5]]^2 - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
      32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
       d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
       d[ep[4], k[1]]*d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
      32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
       d[k[1], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
       d[ep[4], k[1]]*d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] + 
      64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
       d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
       d[ep[4], k[2]]*d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
      16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
       d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
       d[ep[4], k[2]]*d[k[1], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
      64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
       d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
       d[ep[4], k[2]]*d[k[1], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
      16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
       d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[ep[4], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
      32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
       d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
       d[ep[4], k[5]]*d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
      16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
       d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
       d[ep[4], k[5]]*d[k[1], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
      64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
       d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
       d[ep[4], k[6]]*d[k[1], k[6]] - 64*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
      32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[1], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
       d[ep[4], k[6]]*d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
      64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[1], k[6]] - 96*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[6]] + 286*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      88*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 96*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[6]] + 84*d[ep[1], k[5]]*d[ep[2], k[3]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      12*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 286*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 84*d[ep[1], k[3]]*d[ep[2], k[5]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 12*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      84*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 12*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
       d[k[1], k[2]]*d[k[1], k[6]] + 72*d[ep[1], ep[4]]*d[ep[2], k[1]]*
       d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 84*d[ep[1], ep[4]]*
       d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      12*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 84*d[ep[1], k[5]]*d[ep[2], ep[4]]*
       d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      12*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 72*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
       d[k[1], k[2]]*d[k[1], k[6]] + 84*d[ep[1], ep[4]]*d[ep[2], k[5]]*
       d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 12*d[ep[1], ep[4]]*
       d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 20*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 32*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      72*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 84*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 72*d[ep[1], ep[3]]*
       d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      84*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 12*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 128*d[ep[1], ep[2]]*d[ep[3], k[2]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 234*d[ep[1], ep[2]]*
       d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      88*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 72*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
       d[k[1], k[2]]*d[k[1], k[6]] + 84*d[ep[1], k[5]]*d[ep[2], ep[3]]*
       d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      12*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 72*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 84*d[ep[1], ep[3]]*d[ep[2], k[5]]*
       d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 12*d[ep[1], ep[3]]*
       d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      128*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 214*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 56*d[ep[1], ep[2]]*d[ep[3], k[6]]*
       d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
      20*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
       d[k[1], k[6]] + 20*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
       d[k[1], k[2]]*d[k[1], k[6]] - 234*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 214*d[ep[1], ep[2]]*
       d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
       d[k[1], k[6]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
       d[k[1], k[2]]*d[k[1], k[6]] + 88*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 56*d[ep[1], ep[2]]*
       d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
      16*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*d[k[1], k[6]] - 
      16*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] - 
      76*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] + 
      80*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
       d[k[1], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[1], k[6]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
      80*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
       d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[1], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
      80*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
       d[k[1], k[6]] - 80*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[k[1], k[5]]*d[k[1], k[6]] + 80*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 80*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
      80*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
       d[k[1], k[6]] + 80*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
       d[k[1], k[5]]*d[k[1], k[6]] + 80*d[ep[1], ep[2]]*d[ep[3], k[2]]*
       d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 32*d[ep[1], ep[2]]*
       d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
      40*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
       d[k[1], k[6]] - 80*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
       d[k[1], k[5]]*d[k[1], k[6]] + 80*d[ep[1], ep[3]]*d[ep[2], k[1]]*
       d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 80*d[ep[1], ep[2]]*
       d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
      32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*
       d[k[1], k[6]] + 40*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
       d[k[1], k[5]]*d[k[1], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 32*d[ep[1], ep[2]]*
       d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 
      40*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
       d[k[1], k[6]] - 40*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 28*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[1], k[6]] + 
      64*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
      16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
      32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
      64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
      16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
      32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
      64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 - 
      64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
      64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 - 
      64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 - 
      64*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
      64*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
      64*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
      16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
      32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
      64*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
      64*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
      64*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
      16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
      32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
      16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 - 
      16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 - 
      32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 - 
      32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 - 
      12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]^2 + 
      28*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]^2 + 
      16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^3 + 
      112*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[3]] - 
      160*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
       d[k[2], k[3]] + 80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
       d[k[2], k[3]] - 152*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[1], k[6]]*d[k[2], k[3]] + 80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] + 64*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[3]] - 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
       d[k[2], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
       d[ep[4], k[1]]*d[k[2], k[5]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
       d[k[2], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
       d[ep[4], k[1]]*d[k[2], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
       d[k[2], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
       d[ep[4], k[2]]*d[k[2], k[5]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
       d[k[2], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
       d[ep[4], k[2]]*d[k[2], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
       d[k[2], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
       d[ep[4], k[5]]*d[k[2], k[5]] + 48*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
      48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
       d[k[2], k[5]] + 48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[ep[4], k[6]]*d[k[2], k[5]] + 48*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
      48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
       d[k[2], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
       d[ep[4], k[6]]*d[k[2], k[5]] + 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[2], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
       d[ep[4], k[6]]*d[k[2], k[5]] - 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
      148*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[2], k[5]] - 234*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      148*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 64*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[2], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], k[3]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 64*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 234*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      64*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
       d[k[1], k[2]]*d[k[2], k[5]] - 64*d[ep[1], k[5]]*d[ep[2], ep[4]]*
       d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      64*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 96*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 64*d[ep[1], ep[4]]*d[ep[2], k[5]]*
       d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 64*d[ep[1], ep[4]]*
       d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      96*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 64*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], ep[4]]*
       d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 96*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      64*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 64*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
       d[k[1], k[2]]*d[k[2], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 64*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      128*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 128*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 96*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
       d[k[1], k[2]]*d[k[2], k[5]] - 96*d[ep[1], ep[3]]*d[ep[2], k[1]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 64*d[ep[1], ep[3]]*
       d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      64*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 108*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
       d[k[1], k[2]]*d[k[2], k[5]] - 60*d[ep[1], ep[2]]*d[ep[3], k[5]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 158*d[ep[1], ep[2]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      96*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 64*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
       d[k[1], k[2]]*d[k[2], k[5]] - 64*d[ep[1], k[6]]*d[ep[2], ep[3]]*
       d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 96*d[ep[1], ep[3]]*
       d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      64*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 64*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 108*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[5]] + 286*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 64*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 64*d[ep[1], ep[3]]*
       d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
      60*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
       d[k[1], k[2]]*d[k[2], k[5]] + 128*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 128*d[ep[1], ep[3]]*
       d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
      158*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
       d[k[2], k[5]] - 286*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[1], k[2]]*d[k[2], k[5]] - 80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]^2*d[k[2], k[5]] + 160*d[ep[1], k[3]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
       d[k[2], k[5]] - 160*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[2], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] + 
      160*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
       d[k[2], k[5]] - 160*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[k[1], k[5]]*d[k[2], k[5]] + 160*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 160*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
      160*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
       d[k[2], k[5]] + 160*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
       d[k[1], k[5]]*d[k[2], k[5]] + 160*d[ep[1], ep[2]]*d[ep[3], k[2]]*
       d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 160*d[ep[1], k[2]]*
       d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
      160*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
       d[k[2], k[5]] - 160*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
       d[k[1], k[5]]*d[k[2], k[5]] + 80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 80*d[ep[1], k[3]]*
       d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[6]]*d[k[2], k[5]] - 80*d[ep[1], k[2]]*d[ep[2], k[3]]*
       d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
       d[k[1], k[6]]*d[k[2], k[5]] + 80*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 80*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      80*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 80*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
       d[k[1], k[6]]*d[k[2], k[5]] - 80*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 80*d[ep[1], ep[3]]*
       d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      80*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
       d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
       d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      80*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
       d[k[2], k[5]] + 80*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
       d[k[1], k[6]]*d[k[2], k[5]] - 80*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
       d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
       d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
       d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 
      8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]*
       d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[1], k[6]]*d[k[2], k[5]] + 312*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 24*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
      12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[5]] - 
      160*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
       d[k[2], k[5]] + 160*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
       d[k[2], k[3]]*d[k[2], k[5]] + 80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] + 80*d[ep[1], k[3]]*
       d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
      24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
      80*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
      24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
      80*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 - 
      80*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 + 
      80*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 - 
      80*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 - 
      80*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
      80*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
      80*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
      24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
      80*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
      80*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
      80*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
      24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
      24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 + 
      24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 + 
      40*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]^2 - 
      4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]^2 + 
      80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]^2 - 
      16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
       d[k[2], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
       d[ep[4], k[1]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
      32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
       d[k[2], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
       d[ep[4], k[1]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
      32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
       d[k[2], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
       d[ep[4], k[1]]*d[k[2], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
      32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
       d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
       d[ep[4], k[2]]*d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
      32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
       d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
       d[ep[4], k[2]]*d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
      64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
       d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[ep[4], k[5]]*d[k[2], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
      16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
       d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
       d[ep[4], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
      32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
       d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
       d[ep[4], k[5]]*d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
      32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
       d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[ep[4], k[6]]*d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
      64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
       d[k[2], k[6]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
       d[ep[4], k[6]]*d[k[2], k[6]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
      32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[2], k[6]] - 64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
       d[ep[4], k[6]]*d[k[2], k[6]] - 96*d[ep[1], k[3]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      286*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 88*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 96*d[ep[1], k[2]]*d[ep[2], k[3]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      84*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 286*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
      84*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 12*d[ep[1], k[3]]*d[ep[2], k[6]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
      72*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 84*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 12*d[ep[1], k[6]]*d[ep[2], ep[4]]*
       d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 72*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      84*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 12*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 72*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
      84*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 12*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 72*d[ep[1], ep[4]]*d[ep[2], k[1]]*
       d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 84*d[ep[1], ep[4]]*
       d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
      12*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 20*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 20*d[ep[1], ep[4]]*d[ep[2], k[1]]*
       d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
      32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 72*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      84*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 72*d[ep[1], ep[3]]*d[ep[2], k[1]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 84*d[ep[1], ep[3]]*
       d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      12*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 128*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 214*d[ep[1], ep[2]]*d[ep[3], k[5]]*
       d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 56*d[ep[1], ep[2]]*
       d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      72*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 84*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], ep[3]]*
       d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 72*d[ep[1], ep[3]]*
       d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
      84*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 12*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 128*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 234*d[ep[1], ep[2]]*
       d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      88*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
       d[k[2], k[6]] - 20*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*
       d[k[1], k[2]]*d[k[2], k[6]] + 20*d[ep[1], ep[3]]*d[ep[2], k[1]]*
       d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 214*d[ep[1], ep[2]]*
       d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
      234*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*
       d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
       d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 56*d[ep[1], ep[2]]*
       d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
      88*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*
       d[k[2], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], ep[3]]*d[k[1], k[2]]^2*
       d[k[2], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], ep[4]]*d[k[1], k[2]]^2*
       d[k[2], k[6]] - 76*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
       d[k[2], k[6]] + 80*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[2], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
       d[k[2], k[6]] - 80*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
      40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 80*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
       d[k[1], k[5]]*d[k[2], k[6]] - 80*d[ep[1], ep[4]]*d[ep[2], k[1]]*
       d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
      80*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
       d[k[2], k[6]] - 80*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
       d[k[1], k[5]]*d[k[2], k[6]] - 80*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 80*d[ep[1], ep[3]]*
       d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
      80*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
       d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
       d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
       d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      80*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 80*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
       d[k[1], k[5]]*d[k[2], k[6]] - 80*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*
       d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
      8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
       d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
       d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] + 
      8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
       d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[1], k[5]]*d[k[2], k[6]] - 232*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[2], k[6]] + 
      128*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
       d[k[2], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[6]]*d[k[2], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
      128*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
       d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
       d[k[1], k[6]]*d[k[2], k[6]] + 64*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
      128*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
       d[k[2], k[6]] - 128*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[k[1], k[6]]*d[k[2], k[6]] + 128*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 128*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
      128*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
       d[k[2], k[6]] + 128*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
       d[k[1], k[6]]*d[k[2], k[6]] + 128*d[ep[1], ep[2]]*d[ep[3], k[2]]*
       d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 128*d[ep[1], k[2]]*
       d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
      128*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
       d[k[2], k[6]] - 128*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
       d[k[1], k[6]]*d[k[2], k[6]] + 64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] + 
      16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[6]] - 
      152*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
       d[k[2], k[6]] + 80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
       d[k[2], k[3]]*d[k[2], k[6]] + 128*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] + 80*d[ep[1], k[3]]*
       d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[2], k[5]]*d[k[2], k[6]] - 80*d[ep[1], k[2]]*d[ep[2], k[3]]*
       d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
       d[k[2], k[5]]*d[k[2], k[6]] + 80*d[ep[1], k[2]]*d[ep[2], ep[4]]*
       d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 80*d[ep[1], ep[4]]*
       d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      80*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 80*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
       d[k[2], k[5]]*d[k[2], k[6]] - 80*d[ep[1], k[2]]*d[ep[2], ep[3]]*
       d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 80*d[ep[1], ep[3]]*
       d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      80*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
       d[k[2], k[5]]*d[k[2], k[6]] - 40*d[ep[1], ep[2]]*d[ep[3], k[6]]*
       d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      80*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 80*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
       d[k[2], k[5]]*d[k[2], k[6]] - 80*d[ep[1], ep[2]]*d[ep[3], k[1]]*
       d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*
       d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
      40*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
       d[k[2], k[5]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
       d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 40*d[ep[1], ep[2]]*
       d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      40*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]*
       d[k[2], k[6]] + 64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[5]]*d[k[2], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] + 
      80*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]*
       d[k[2], k[6]] - 28*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2*
       d[k[2], k[6]] + 64*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[2], k[6]]^2 - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[2], k[6]]^2 - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[2], k[6]]^2 - 64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
       d[k[2], k[6]]^2 + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
       d[k[2], k[6]]^2 + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
       d[k[2], k[6]]^2 + 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
       d[k[2], k[6]]^2 - 64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
       d[k[2], k[6]]^2 + 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
       d[k[2], k[6]]^2 - 64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
       d[k[2], k[6]]^2 - 64*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
       d[k[2], k[6]]^2 + 64*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
       d[k[2], k[6]]^2 + 64*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
       d[k[2], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
       d[k[2], k[6]]^2 - 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
       d[k[2], k[6]]^2 - 64*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
       d[k[2], k[6]]^2 + 64*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
       d[k[2], k[6]]^2 - 64*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
       d[k[2], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
       d[k[2], k[6]]^2 - 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
       d[k[2], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
       d[k[2], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
       d[k[2], k[6]]^2 + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
       d[k[2], k[6]]^2 + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
       d[k[2], k[6]]^2 + 76*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[6]]^2 - 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
       d[k[2], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
       d[k[2], k[6]]^2 + 64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
       d[k[2], k[6]]^2 - 28*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
       d[k[2], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]^3 - 
      56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[3], k[5]] - 404*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[3], k[5]] + 56*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
      404*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[3], k[5]] - 48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[3], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
      16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
       d[k[3], k[5]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[6]]*d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
      32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
       d[k[3], k[5]] + 248*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[1], k[6]]*d[k[3], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] + 16*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[3], k[5]] - 
      48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
       d[k[3], k[5]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
       d[k[2], k[5]]*d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] - 16*d[ep[1], k[5]]*
       d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] - 
      32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
       d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
       d[k[2], k[6]]*d[k[3], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
       d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] - 
      248*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]*
       d[k[3], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
       d[k[2], k[6]]*d[k[3], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 16*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[2], k[6]]^2*d[k[3], k[5]] + 
      488*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[3], k[6]] + 188*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[3], k[6]] - 488*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] - 
      188*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[3], k[6]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[3], k[6]] - 48*d[ep[1], k[6]]*d[ep[2], k[1]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
      48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
       d[k[3], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[3], k[6]] - 296*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 24*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[3], k[6]] - 
      32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
       d[k[3], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[1], k[6]]*d[k[3], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
      64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
       d[k[3], k[6]] - 88*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[1], k[6]]*d[k[3], k[6]] + 40*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 32*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[3], k[6]] - 
      48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
       d[k[3], k[6]] - 48*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[2], k[5]]*d[k[3], k[6]] + 48*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
      48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
       d[k[3], k[6]] + 296*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[5]]*d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 24*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[6]] - 
      32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
       d[k[3], k[6]] - 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
       d[k[2], k[6]]*d[k[3], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
       d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] + 
      64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
       d[k[3], k[6]] + 88*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
       d[k[2], k[6]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
       d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 40*d[ep[1], ep[2]]*
       d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 
      32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2*d[k[3], k[6]] + 
      Df*(-32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[2]] + 56*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[1], k[2]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
        56*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[2]] - 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]] + 40*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
        56*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[1], k[2]] - 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
        56*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
         d[k[1], k[2]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[2]] - 56*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
        56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[2]] + 40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[1], k[2]] + 56*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
        40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[2]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]] - 56*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
        32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
         d[k[1], k[2]] + 56*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]] + 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
        56*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[1], k[2]] - 32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
         d[ep[4], k[5]]*d[k[1], k[2]] + 56*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
        56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[2]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[2]] - 56*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
        40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[2]] + 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[2]] - 40*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
        56*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[2]] + 40*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[2]] - 24*d[ep[1], k[3]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 24*d[ep[1], k[2]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[2]]^2 + 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[k[1], k[2]]^2 - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[2]]^2 + 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[k[1], k[2]]^2 + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 - 40*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 + 40*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]^3 - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[1], k[5]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[1], k[5]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[5]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] + 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
         d[ep[4], k[5]]*d[k[1], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[5]] + 24*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
        32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
         d[k[1], k[2]]*d[k[1], k[5]] - 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 32*d[ep[1], k[2]]*
         d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
         d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 40*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
        16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[1], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 32*d[ep[1], ep[3]]*
         d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        40*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[1], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], ep[2]]*
         d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*
         d[k[1], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[2]]*d[k[1], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 16*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] - 
        16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
        8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
        8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
        8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
        8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
        8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
        8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
         d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
        8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
         d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
        8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] - 
        8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
        24*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
        24*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[5]]*
         d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
        32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[5]]*
         d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
        32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
         d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
        8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
         d[k[1], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[k[1], k[2]]*d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[5]]*
         d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[1], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 40*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 32*d[ep[1], ep[2]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 
        24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 32*d[ep[1], ep[3]]*
         d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 40*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[1], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 16*d[ep[1], ep[2]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 24*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] - 
        16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[1], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
         d[k[1], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
         d[k[1], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
        12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
         d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*
         d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
        8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*
         d[k[1], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] - 
        12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
         d[k[1], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[1], k[6]] + 
        16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
        4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
        8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
        4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
        8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 - 
        16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 - 
        16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
        16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
        4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
        16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
        4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
        4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 - 
        4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 - 
        8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 - 
        8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 - 
        4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]^2 + 
        4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^3 - 
        32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[3]] + 
        32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
         d[k[2], k[3]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
         d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[6]]*d[k[2], k[3]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] + 16*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[3]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[2], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
         d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
         d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[2], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
        24*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[5]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
        24*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
        32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
         d[k[2], k[5]] - 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 32*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
        32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 40*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
        32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 40*d[ep[1], ep[2]]*
         d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
        16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
        32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]^2*d[k[2], k[5]] - 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
        32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
         d[k[2], k[5]] + 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 32*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
        32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
         d[k[2], k[5]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
         d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 32*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
        32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
         d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[3]]*
         d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[2], k[5]] - 12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
        8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[2], k[5]] + 12*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*
         d[k[2], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[3]]*
         d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
        16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*
         d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
         d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
        8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]*
         d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]*d[k[2], k[5]] - 
        40*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*
         d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[1], k[6]]*d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]^2*d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[5]] - 
        16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]]*
         d[k[2], k[5]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]^2 - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]^2 + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]^2 - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
         d[k[2], k[5]]^2 + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[k[2], k[5]]^2 - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
         d[k[2], k[5]]^2 + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[k[2], k[5]]^2 + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
         d[k[2], k[5]]^2 - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
         d[k[2], k[5]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
         d[k[2], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[2], k[5]]^2 + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
         d[k[2], k[5]]^2 - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
         d[k[2], k[5]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
         d[k[2], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[2], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[2], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[2], k[5]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[5]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
         d[k[2], k[5]]^2 - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[2], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[2], k[6]] - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[2], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[2], k[6]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
        8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
         d[ep[4], k[5]]*d[k[2], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[2], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[2], k[6]] + 24*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
         d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[4]]*
         d[ep[2], k[5]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
         d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[4]]*
         d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
        8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
        32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[2], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], ep[3]]*
         d[ep[2], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        40*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
        8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 40*d[ep[1], ep[2]]*
         d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        32*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[3]]*
         d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
        24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
         d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[3]]*
         d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] - 
        16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
         d[k[2], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[2]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]^2*d[k[2], k[6]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[2], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
        8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[2], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[3]]*
         d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
         d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
        8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]]*
         d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]*d[k[2], k[6]] + 
        24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
         d[k[2], k[6]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
         d[k[1], k[6]]*d[k[2], k[6]] - 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 32*d[ep[1], k[2]]*
         d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
        32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*
         d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
         d[k[1], k[6]]*d[k[2], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] - 
        32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*
         d[k[2], k[6]] + 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[6]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
        4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*
         d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*
         d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[3]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[3]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] - 
        16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
         d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]*d[k[2], k[6]] - 12*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
         d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]*d[k[2], k[6]] + 12*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]*
         d[k[2], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
         d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
        12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
         d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*
         d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
        8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[5]]*
         d[k[2], k[6]] - 12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[2], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] + 
        12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]*
         d[k[2], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]]*d[k[2], k[6]] - 
        4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]*
         d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*
         d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]^2*d[k[2], k[6]] + 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[2], k[6]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[k[2], k[6]]^2 + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[2], k[6]]^2 - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[k[2], k[6]]^2 - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[2], k[6]]^2 + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[1]]*d[k[2], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[2], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[2], k[6]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[2], k[6]]^2 - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[2]]*d[k[2], k[6]]^2 + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[2]]*d[k[2], k[6]]^2 - 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[2]]*d[k[2], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[2], k[6]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[2], k[6]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[2], k[6]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[5]]*d[k[2], k[6]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[2], k[6]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[2], k[6]]^2 + 20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[6]]^2 + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[2], k[3]]*d[k[2], k[6]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]*d[k[2], k[6]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[2], k[6]]^3 - 32*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[3], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] + 
        32*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[3], k[5]] - 64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[3], k[5]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[5]]*d[k[3], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] + 
        8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[3], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[6]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[3], k[5]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
         d[k[3], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]*d[k[3], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] - 
        8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
         d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[2], k[6]]*d[k[3], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] - 
        8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]*
         d[k[3], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2*
         d[k[3], k[5]] - 56*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[3], k[6]] + 48*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
        56*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[3], k[6]] - 48*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[3], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] + 
        32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
         d[k[3], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
         d[k[3], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[3], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] + 
        8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[3], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[6]] + 12*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] + 
        8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[3], k[6]] - 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
         d[k[3], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]*d[k[3], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
         d[k[3], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[5]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] - 8*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[6]] - 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
         d[k[3], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[2], k[6]]*d[k[3], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
         d[k[3], k[6]] + 24*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[6]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 12*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] - 
        8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2*d[k[3], k[6]]) + 
      Ds*(48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[2]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[1], k[2]] - 48*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
        72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[2]] - 72*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]] - 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] + 
        72*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[1], k[2]] + 72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]] + 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
        72*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
         d[k[1], k[2]] - 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[2]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] - 
        72*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[2]] - 72*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[1], k[2]] + 72*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
        72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[2]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]] - 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
        48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
         d[k[1], k[2]] + 72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]] - 48*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
        72*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[1], k[2]] + 48*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
         d[ep[4], k[5]]*d[k[1], k[2]] + 72*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] + 
        72*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[2]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[2]] - 72*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
        72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[2]] + 72*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[2]] + 72*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] - 
        72*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[2]] - 72*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[2]] - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[5]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[6]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[3]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 4*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[3]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
         d[ep[3], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*
         d[ep[3], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
         d[ep[3], k[2]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*
         d[ep[3], k[2]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[5]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[5]]*d[k[1], k[2]]^2 - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[6]]*d[k[1], k[2]]^2 + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 - 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[1], k[2]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[5]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]]^2 - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[5]]*d[k[1], k[2]]^2 + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[6]]*d[k[1], k[2]]^2 - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[2]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[2]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]^3 + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[1], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]] + 
        24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[1], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]] - 
        24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[1], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]] + 
        24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[1], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]] - 
        24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[5]] - 
        24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[1], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
         d[ep[4], k[5]]*d[k[1], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
        24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]] - 
        24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]] + 
        24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[5]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
        36*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
        8*d[ep[1], k[6]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        36*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[5]] - 8*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[5]]*
         d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
         d[k[1], k[5]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*
         d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[4]]*
         d[ep[2], k[6]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
        24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
         d[k[1], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
         d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 24*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*
         d[k[1], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
         d[k[1], k[5]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[k[1], k[2]]*d[k[1], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], k[5]]*
         d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
        8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[1], k[5]] + 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[3]]*
         d[ep[2], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] + 
        24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[1], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 24*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        8*d[ep[1], k[5]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[1], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 8*d[ep[1], ep[3]]*
         d[ep[2], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        8*d[ep[1], ep[3]]*d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[1], k[5]] - 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[1], k[5]] - 24*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 28*d[ep[1], ep[2]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
         d[k[1], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
         d[k[1], k[2]]*d[k[1], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] + 24*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[5]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
         d[k[1], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[2]]*d[k[1], k[5]] - 44*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 28*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] + 
        16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] - 
        16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
        12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
        12*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
        12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
        16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
        12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
        12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 + 
        12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[5]]^2 - 
        16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]^2 + 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
         d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]] + 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]] - 
        32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]] + 
        8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
         d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
         d[ep[4], k[5]]*d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]] - 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
        32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[6]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
        44*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        44*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[6]] + 44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 24*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[k[1], k[2]]*d[k[1], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 24*d[ep[1], ep[3]]*
         d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 36*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 24*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[1], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[1], k[6]] - 44*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 28*d[ep[1], ep[2]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] - 
        8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
         d[k[1], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
         d[k[1], k[2]]*d[k[1], k[6]] + 36*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] + 44*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
         d[k[1], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[2]]*d[k[1], k[6]] - 44*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] - 28*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[6]] + 
        16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] - 
        16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[1], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[1], k[6]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
         d[k[1], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
         d[k[1], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], ep[2]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 
        20*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
         d[k[1], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*
         d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 
        16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*
         d[k[1], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 16*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[1], k[6]] + 
        20*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
         d[k[1], k[6]] + 20*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[5]]*d[k[1], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 14*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[1], k[6]] - 
        32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 + 
        32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
        8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2 - 
        32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 + 
        32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[6]]^2 - 
        32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 + 
        32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]^2 + 
        32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
        32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
        32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
        8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 - 
        16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]^2 + 
        32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
        32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
        32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
        8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 - 
        16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[6]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]^2 + 
        16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 + 
        16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[6]]^2 + 
        6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]]^2 - 
        14*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]^2 - 
        8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^3 - 
        16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[3]] + 
        32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
         d[k[2], k[3]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2*
         d[k[2], k[3]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[6]]*d[k[2], k[3]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 32*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[3]] + 
        24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[2], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
        24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]] + 
        24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
         d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[2], k[5]] + 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] + 
        24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]] - 
        24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
         d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[2], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[5]] + 
        24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[2], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[2], k[5]] - 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
        24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[2], k[5]] - 24*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] - 
        24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]] + 
        32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 36*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
        32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[6]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[5]] - 36*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] - 
        8*d[ep[1], k[3]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[6]]*
         d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 
        24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*
         d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[4]]*d[ep[2], k[6]]*
         d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 24*d[ep[1], k[2]]*
         d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
        8*d[ep[1], k[5]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
         d[k[2], k[5]] - 8*d[ep[1], k[6]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
         d[k[1], k[2]]*d[k[2], k[5]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[4]]*
         d[ep[2], k[5]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
        8*d[ep[1], ep[4]]*d[ep[2], k[6]]*d[ep[3], k[2]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[5]]*
         d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*
         d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 
        16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[k[1], k[2]]*
         d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[5]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], k[6]]*
         d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
        24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[3]]*d[ep[2], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 24*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
        24*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[2], k[5]] - 28*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[2], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[5]]*
         d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
        8*d[ep[1], k[6]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[3]]*
         d[ep[2], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 
        24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[2], k[5]] - 44*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] + 
        8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
         d[k[2], k[5]] - 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
         d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*d[k[1], k[2]]*
         d[k[2], k[5]] + 28*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[2]]*d[k[2], k[5]] + 44*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[5]] - 
        32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[2], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[5]] - 
        24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[2], k[5]] - 32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
         d[k[1], k[5]]*d[k[2], k[5]] + 32*d[ep[1], ep[4]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], k[2]]*
         d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
        32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*
         d[k[2], k[5]] + 32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
         d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 32*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
        32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
         d[k[2], k[5]] - 32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[5]]*d[k[2], k[5]] + 32*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 
        16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[2], k[5]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[5]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[5]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
         d[k[2], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
         d[k[2], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
         d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 
        4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[6]]*
         d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
         d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
         d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
        8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[6]]*
         d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] + 
        4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[6]]*
         d[k[2], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[6]]*d[k[2], k[5]] - 48*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 12*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[5]] - 
        6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[5]] + 
        32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
         d[k[2], k[5]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[2], k[3]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[5]] - 16*d[ep[1], k[3]]*
         d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
        12*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
        12*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 + 
        16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 + 
        16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 - 
        16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
        12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[5]]^2 + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
        16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 + 
        12*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]^2 - 
        12*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 - 
        12*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]^2 + 
        2*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]^2 - 
        16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]^2 + 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[2], k[6]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
         d[ep[4], k[1]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[2], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
         d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[2], k[6]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[2]]*
         d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]] + 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[2], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[ep[4], k[2]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]] - 
        32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]] + 
        8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[2], k[6]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*
         d[ep[4], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[2], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
        32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
         d[k[2], k[6]] - 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[2], k[6]] - 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[2], k[6]] + 32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[2]]*
         d[ep[4], k[6]]*d[k[2], k[6]] + 32*d[ep[1], k[3]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
        44*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[6]] - 44*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        44*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 44*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[6]] + 24*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 24*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        24*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*
         d[k[2], k[6]] - 24*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[6]]*d[k[1], k[2]]*
         d[k[2], k[6]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[6]]*
         d[k[1], k[2]]*d[k[2], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 24*d[ep[1], ep[3]]*
         d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        24*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 44*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[1], k[2]]*d[k[2], k[6]] - 28*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 24*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        24*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*
         d[k[2], k[6]] - 24*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[2]]*d[k[2], k[6]] + 36*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 44*d[ep[1], ep[2]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 
        8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[5]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[5]]*
         d[k[1], k[2]]*d[k[2], k[6]] - 44*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 36*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]]*d[k[2], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[6]]*d[k[1], k[2]]*
         d[k[2], k[6]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[6]]*
         d[k[1], k[2]]*d[k[2], k[6]] + 28*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 44*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[6]] + 
        16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[6]] - 
        16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[6]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[6]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
        16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]*
         d[k[2], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
         d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*
         d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 
        4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
         d[k[1], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
         d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*
         d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] + 
        8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[5]]*
         d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
         d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[5]]*d[k[2], k[6]] - 
        4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[1], k[5]]*
         d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
         d[k[1], k[5]]*d[k[2], k[6]] + 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 2*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[2], k[6]] - 
        64*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[2], k[6]] + 16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] + 
        64*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[6]] - 32*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]] - 
        64*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
         d[k[2], k[6]] + 64*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
         d[k[1], k[6]]*d[k[2], k[6]] - 64*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 64*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] + 
        64*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
         d[k[2], k[6]] - 64*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
         d[k[1], k[6]]*d[k[2], k[6]] - 64*d[ep[1], ep[2]]*d[ep[3], k[2]]*
         d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[6]] + 64*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 
        64*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
         d[k[2], k[6]] + 64*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
         d[k[1], k[6]]*d[k[2], k[6]] - 32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[6]] - 
        8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[2], k[6]] + 
        32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*
         d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[2], k[3]]*d[k[2], k[6]] - 64*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[3]]*d[k[2], k[6]] - 16*d[ep[1], k[3]]*
         d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
         d[k[2], k[6]] + 20*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
         d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
         d[k[2], k[6]] - 20*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
         d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[4]]*
         d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
         d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
         d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[3]]*
         d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
         d[k[2], k[5]]*d[k[2], k[6]] + 20*d[ep[1], ep[2]]*d[ep[3], k[6]]*
         d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], k[2]]*
         d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*
         d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
         d[k[2], k[5]]*d[k[2], k[6]] + 16*d[ep[1], ep[2]]*d[ep[3], k[5]]*
         d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 20*d[ep[1], ep[2]]*
         d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
        16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[5]]*
         d[k[2], k[6]] - 16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
         d[k[2], k[5]]*d[k[2], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], k[1]]*
         d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 20*d[ep[1], ep[2]]*
         d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 
        12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*
         d[k[2], k[6]] + 12*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[2], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[5]]*d[k[2], k[6]] - 16*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]*d[k[2], k[6]] + 
        14*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[2], k[6]] - 
        32*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 
        16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 + 
        32*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 
        8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2 - 
        32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 + 
        32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[2], k[6]]^2 - 
        32*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 + 
        32*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[6]]^2 + 
        32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 - 
        32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 - 
        32*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
        16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[2], k[6]]^2 + 
        32*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
        32*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 + 
        32*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 + 
        16*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[2], k[6]]^2 - 
        8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 - 
        8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[2], k[6]]^2 - 
        16*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*d[k[2], k[6]]^2 - 
        16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[2], k[6]]^2 - 
        38*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]^2 + 
        6*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[6]]^2 - 
        32*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[6]]^2 + 
        14*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]^2 + 
        8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]^3 + 
        40*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[3], k[5]] + 64*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[3], k[5]] - 40*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[5]] - 
        64*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[3], k[5]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[3], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[5]] - 
        16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
         d[k[3], k[5]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[3], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[5]] - 
        8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[3], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[3], k[5]] - 36*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] - 16*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[5]] - 
        8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[3], k[5]] + 
        24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
         d[k[3], k[5]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]*d[k[3], k[5]] + 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[5]] - 8*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[5]] + 
        8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
         d[k[3], k[5]] + 16*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[2], k[6]]*d[k[3], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[5]] - 
        16*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
         d[k[3], k[5]] + 36*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[6]]*d[k[3], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 16*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[5]] + 
        8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2*d[k[3], k[5]] - 
        88*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[3], k[6]] - 88*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[3], k[6]] + 88*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[3], k[6]] + 
        88*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[3], k[6]] + 24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[3], k[6]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[3], k[6]] - 
        24*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
         d[k[3], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[3], k[6]] + 44*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] - 12*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[5]]^2*d[k[3], k[6]] + 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[3], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[3], k[6]] - 
        32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
         d[k[3], k[6]] + 44*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[1], k[6]]*d[k[3], k[6]] - 20*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[1], k[6]]*d[k[3], k[6]] - 16*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[1], k[6]]^2*d[k[3], k[6]] + 
        24*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
         d[k[3], k[6]] + 24*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[2], k[5]]*d[k[3], k[6]] - 24*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[3], k[6]] - 
        24*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[5]]*
         d[k[3], k[6]] - 44*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[5]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[6]]*d[k[2], k[5]]*d[k[3], k[6]] + 12*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[2], k[5]]^2*d[k[3], k[6]] + 
        16*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
         d[k[3], k[6]] + 32*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
         d[k[2], k[6]]*d[k[3], k[6]] - 16*d[ep[1], k[2]]*d[ep[2], k[5]]*
         d[ep[3], ep[4]]*d[k[2], k[6]]*d[k[3], k[6]] - 
        32*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[2], k[6]]*
         d[k[3], k[6]] - 44*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
         d[k[2], k[6]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
         d[k[1], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] + 20*d[ep[1], ep[2]]*
         d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]]*d[k[3], k[6]] + 
        16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[2], k[6]]^2*d[k[3], k[6]] + 
        Df*(-8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*d[ep[4], k[1]]*
           d[k[1], k[2]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[5]]*
           d[ep[4], k[1]]*d[k[1], k[2]] + 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
           d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]] - 
          8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*d[ep[4], k[1]]*
           d[k[1], k[2]] - 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[5]]*
           d[ep[4], k[2]]*d[k[1], k[2]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
           d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]] + 
          8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[6]]*d[ep[4], k[2]]*
           d[k[1], k[2]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[6]]*
           d[ep[4], k[2]]*d[k[1], k[2]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*
           d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
          8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
           d[k[1], k[2]] + 8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
           d[ep[4], k[5]]*d[k[1], k[2]] - 8*d[ep[1], k[2]]*d[ep[2], k[6]]*
           d[ep[3], k[2]]*d[ep[4], k[5]]*d[k[1], k[2]] - 
          8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
           d[k[1], k[2]] + 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[1]]*
           d[ep[4], k[6]]*d[k[1], k[2]] - 8*d[ep[1], k[5]]*d[ep[2], k[1]]*
           d[ep[3], k[2]]*d[ep[4], k[6]]*d[k[1], k[2]] + 
          8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], k[2]]*d[ep[4], k[6]]*
           d[k[1], k[2]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]^2 - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
           d[k[1], k[2]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
           d[k[1], k[2]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*
           d[k[1], k[2]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
           d[k[1], k[2]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
           d[k[1], k[2]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
           d[k[1], k[2]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*
           d[k[1], k[2]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
           d[k[1], k[2]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
           d[k[1], k[2]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
           d[k[1], k[2]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]^3 - 16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[1], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 16*d[ep[1], k[2]]*
           d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]] + 
          4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
           d[k[1], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
           d[k[1], k[2]]*d[k[1], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
           d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], k[2]]*
           d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 
          16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
           d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
           d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], ep[2]]*
           d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[5]] - 
          4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
           d[k[1], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
           d[k[1], k[2]]*d[k[1], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] + 16*d[ep[1], ep[2]]*
           d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[5]] - 
          4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
           d[k[1], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
           d[k[1], k[2]]*d[k[1], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
           d[ep[4], k[6]]*d[k[1], k[2]]*d[k[1], k[5]] - 8*d[ep[1], ep[2]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[5]] + 
          8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 - 
          8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]^2 + 
          8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 - 
          8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]^2 + 
          8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 - 
          8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]^2 - 
          8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
          8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 + 
          8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]^2 - 
          8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
          8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 - 
          8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]^2 + 
          4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]^2 - 
          8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
           d[k[1], k[6]] + 4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[6]] - 
          4*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
           d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
           d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
           d[ep[3], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], k[2]]*
           d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
          8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
           d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
           d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*
           d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[1], k[6]] + 
          4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*
           d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
           d[k[1], k[2]]*d[k[1], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 8*d[ep[1], ep[2]]*
           d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[1], k[6]] + 
          4*d[ep[1], ep[2]]*d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*
           d[k[1], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*
           d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
           d[ep[4], k[5]]*d[k[1], k[2]]*d[k[1], k[6]] - 4*d[ep[1], ep[2]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[1], k[6]] + 
          8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
           d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
           d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
           d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[4]]*
           d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
          8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
           d[k[1], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
           d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
           d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[3]]*
           d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[1], k[6]] + 
          8*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
           d[k[1], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
           d[k[1], k[5]]*d[k[1], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] - 8*d[ep[1], ep[2]]*
           d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[1], k[6]] + 
          4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
           d[k[1], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]^2*
           d[k[2], k[3]] - 16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
           d[k[1], k[5]]*d[k[2], k[3]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
           d[k[1], k[5]]^2*d[k[2], k[3]] - 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[3]] + 8*d[ep[1], ep[2]]*
           d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[1], k[6]]*d[k[2], k[3]] - 
          16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
           d[k[2], k[5]] - 4*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], k[3]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]] + 
          4*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
           d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
           d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*
           d[ep[3], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*
           d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
          16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*
           d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
           d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*
           d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[5]] + 
          4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[1]]*d[k[1], k[2]]*
           d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
           d[k[1], k[2]]*d[k[2], k[5]] - 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 16*d[ep[1], ep[2]]*
           d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[5]] + 
          4*d[ep[1], ep[2]]*d[ep[3], k[6]]*d[ep[4], k[2]]*d[k[1], k[2]]*
           d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[6]]*
           d[k[1], k[2]]*d[k[2], k[5]] - 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*
           d[ep[4], k[6]]*d[k[1], k[2]]*d[k[2], k[5]] - 8*d[ep[1], ep[2]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]^2*d[k[2], k[5]] + 
          16*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
           d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
           d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], k[2]]*d[ep[2], ep[4]]*
           d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], ep[4]]*
           d[ep[2], k[1]]*d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
          16*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*
           d[k[2], k[5]] - 16*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*
           d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*
           d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], ep[3]]*
           d[ep[2], k[1]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[5]] + 
          16*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*
           d[k[2], k[5]] - 16*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*
           d[k[1], k[5]]*d[k[2], k[5]] + 16*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*
           d[ep[3], k[1]]*d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[5]] + 
          8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[1], k[5]]*
           d[k[2], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
           d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
           d[ep[3], ep[4]]*d[k[1], k[6]]*d[k[2], k[5]] + 
          8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[6]]*
           d[k[2], k[5]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
           d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
           d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], ep[4]]*
           d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 
          8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[6]]*
           d[k[2], k[5]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
           d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
           d[ep[4], k[1]]*d[k[1], k[6]]*d[k[2], k[5]] - 8*d[ep[1], k[2]]*
           d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] + 
          8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[1], k[6]]*
           d[k[2], k[5]] - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
           d[k[1], k[6]]*d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[1], k[6]]*d[k[2], k[5]] - 16*d[ep[1], ep[2]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[5]] + 
          16*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*
           d[k[2], k[5]] + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[6]]*
           d[k[2], k[3]]*d[k[2], k[5]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
           d[ep[3], ep[4]]*d[k[2], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
           d[ep[3], ep[4]]*d[k[2], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
           d[ep[3], k[1]]*d[k[2], k[5]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
           d[ep[3], k[1]]*d[k[2], k[5]]^2 + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
           d[ep[3], k[2]]*d[k[2], k[5]]^2 - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
           d[ep[3], k[2]]*d[k[2], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
           d[ep[4], k[1]]*d[k[2], k[5]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[1]]*d[k[2], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
           d[ep[4], k[1]]*d[k[2], k[5]]^2 - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*
           d[ep[4], k[2]]*d[k[2], k[5]]^2 + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[2]]*d[k[2], k[5]]^2 - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
           d[ep[4], k[2]]*d[k[2], k[5]]^2 + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[2], k[5]]^2 + 8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
           d[k[2], k[3]]*d[k[2], k[5]]^2 - 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] + 
          4*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
           d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], k[2]]*d[ep[2], k[5]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]] - 
          8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[1], k[2]]*
           d[k[2], k[6]] + 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
           d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
           d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], ep[4]]*
           d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
          8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[1], k[2]]*
           d[k[2], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
           d[k[1], k[2]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
           d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
           d[ep[3], k[5]]*d[ep[4], k[1]]*d[k[1], k[2]]*d[k[2], k[6]] + 
          8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[2]]*
           d[k[2], k[6]] - 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
           d[k[1], k[2]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
           d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*
           d[ep[3], k[5]]*d[ep[4], k[2]]*d[k[1], k[2]]*d[k[2], k[6]] + 
          4*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[5]]*d[k[1], k[2]]*
           d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], k[2]]*d[ep[4], k[5]]*
           d[k[1], k[2]]*d[k[2], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]^2*d[k[2], k[6]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*
           d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[6]] - 
          8*d[ep[1], k[2]]*d[ep[2], k[3]]*d[ep[3], ep[4]]*d[k[1], k[5]]*
           d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*
           d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*
           d[ep[3], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*
           d[ep[2], ep[4]]*d[ep[3], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 
          8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[1], k[5]]*
           d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*
           d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*
           d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*
           d[ep[3], k[2]]*d[ep[4], k[1]]*d[k[1], k[5]]*d[k[2], k[6]] - 
          8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[1], k[5]]*
           d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*
           d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*
           d[ep[4], k[2]]*d[k[1], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[2]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[3]]*d[k[2], k[6]] + 
          8*d[ep[1], ep[2]]*d[ep[3], ep[4]]*d[k[1], k[5]]*d[k[2], k[3]]*
           d[k[2], k[6]] + 8*d[ep[1], k[3]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*
           d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[3]]*
           d[ep[3], ep[4]]*d[k[2], k[5]]*d[k[2], k[6]] + 
          8*d[ep[1], k[2]]*d[ep[2], ep[4]]*d[ep[3], k[1]]*d[k[2], k[5]]*
           d[k[2], k[6]] - 8*d[ep[1], ep[4]]*d[ep[2], k[1]]*d[ep[3], k[1]]*
           d[k[2], k[5]]*d[k[2], k[6]] + 8*d[ep[1], k[2]]*d[ep[2], ep[4]]*
           d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], ep[4]]*
           d[ep[2], k[1]]*d[ep[3], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] - 
          8*d[ep[1], k[2]]*d[ep[2], ep[3]]*d[ep[4], k[1]]*d[k[2], k[5]]*
           d[k[2], k[6]] + 8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[1]]*
           d[k[2], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*d[ep[3], k[2]]*
           d[ep[4], k[1]]*d[k[2], k[5]]*d[k[2], k[6]] - 8*d[ep[1], k[2]]*
           d[ep[2], ep[3]]*d[ep[4], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 
          8*d[ep[1], ep[3]]*d[ep[2], k[1]]*d[ep[4], k[2]]*d[k[2], k[5]]*
           d[k[2], k[6]] - 8*d[ep[1], ep[2]]*d[ep[3], k[1]]*d[ep[4], k[2]]*
           d[k[2], k[5]]*d[k[2], k[6]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[2], k[5]]*d[k[2], k[6]] + 8*d[ep[1], ep[2]]*
           d[ep[3], ep[4]]*d[k[2], k[3]]*d[k[2], k[5]]*d[k[2], k[6]] - 
          8*d[ep[1], k[6]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
           d[k[3], k[5]] + 8*d[ep[1], k[2]]*d[ep[2], k[6]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[3], k[5]] + 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[1], k[6]]*d[k[3], k[5]] - 4*d[ep[1], ep[2]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[6]]*d[k[3], k[5]] + 
          8*d[ep[1], k[5]]*d[ep[2], k[1]]*d[ep[3], ep[4]]*d[k[1], k[2]]*
           d[k[3], k[6]] - 8*d[ep[1], k[2]]*d[ep[2], k[5]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[3], k[6]] - 4*d[ep[1], ep[2]]*d[ep[3], ep[4]]*
           d[k[1], k[2]]*d[k[1], k[5]]*d[k[3], k[6]] + 4*d[ep[1], ep[2]]*
           d[ep[3], ep[4]]*d[k[1], k[2]]*d[k[2], k[5]]*d[k[3], k[6]]))))/
   (16*d[k[1], k[2]]^2*(d[k[1], k[2]] - d[k[1], k[5]] - d[k[2], k[5]])*
    (-d[k[1], k[2]] + d[k[1], k[5]] + d[k[1], k[6]] + d[k[2], k[5]] + 
     d[k[2], k[6]]))|>
