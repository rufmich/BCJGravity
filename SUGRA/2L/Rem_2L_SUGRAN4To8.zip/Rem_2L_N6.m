(* Created with the Wolfram Language : www.wolfram.com *)
(fac1^2*(-4*s^2 - 11*s*t + t^2)*Log[s]^4)/3 - 
 (fac1^2*t^3*(s + 3*t)*Log[-t]^4)/(6*s^2) + 
 (2*fac1^2*t*(s + t)*(2*s - (3*I)*Pi*s + 2*t - (2*I)*Pi*t)*Log[-u]^3)/(3*s) - 
 (fac1^2*(4*s^4 + 12*s^3*t + 12*s^2*t^2 + 9*s*t^3 + 3*t^4)*Log[-u]^4)/
  (6*s^2) + Log[s]^3*((4*fac1^2*(2*t*(s + t) + I*Pi*(3*s^2 + 5*s*t - t^2)))/
    3 + (4*fac1^2*(5*s^3 + 8*s^2*t - 2*s*t^2 - t^3)*Log[-t])/(3*s) + 
   (4*fac1^2*(-s^3 + 3*s^2*t + s*t^2 + t^3)*Log[-u])/(3*s)) + 
 Log[-t]^3*((((2*I)/3)*fac1^2*t*(s + t)*(-(Pi*s) + (2*I)*t + 2*Pi*t))/s + 
   (2*fac1^2*t*(3*s^3 + 4*s^2*t + 4*s*t^2 + 3*t^3)*Log[-u])/(3*s^2)) + 
 (2*fac1^2*Pi^2*(6*s^3 + 11*s^2*t - 3*s*t^2 - 2*t^3)*PolyLog[2, -(t/s)])/
  (3*s) + Log[-t]^2*((fac1^2*Pi^2*t*(6*s^3 + s^2*t - 2*s*t^2 - 3*t^3))/
    (3*s^2) + (4*fac1^2*(s + t)*(t*(s + t) - I*Pi*(s^2 + t^2))*Log[-u])/s - 
   (fac1^2*(6*s^4 + 13*s^3*t + 5*s^2*t^2 + 5*s*t^3 + 3*t^4)*Log[-u]^2)/s^2 + 
   4*fac1^2*s*t*PolyLog[2, -(t/s)]) + 
 Log[-u]^2*(-1/3*(fac1^2*Pi^2*(10*s^4 + 15*s^3*t + 8*s^2*t^2 + 8*s*t^3 + 
       3*t^4))/s^2 + 4*fac1^2*s*(s + t)*PolyLog[2, -(t/s)]) + 
 Log[s]^2*((fac1^2*Pi^2*(6*s^3 + 17*s^2*t + s*t^2 - 2*t^3))/(3*s) + 
   (fac1^2*(-6*s^3 - 7*s^2*t + 3*s*t^2 + 2*t^3)*Log[-t]^2)/s - 
   (2*I)*fac1^2*((-4*I)*t*(s + t) + Pi*(2*s^2 + 5*s*t - t^2))*Log[-u] + 
   (fac1^2*(6*s^3 + 3*s^2*t - 3*s*t^2 - 2*t^3)*Log[-u]^2)/s + 
   Log[-t]*((-2*I)*fac1^2*Pi*(4*s^2 + 5*s*t - t^2) + 
     2*fac1^2*(-4*s^2 - 9*s*t + t^2)*Log[-u]) - 
   4*fac1^2*s*(s + 2*t)*PolyLog[2, -(t/s)]) + 
 (4*I)*fac1^2*(s + t)*((2*I)*t + Pi*(2*s + t))*PolyLog[3, -(t/s)] + 
 (4*I)*fac1^2*t*(-((-2*I + Pi)*s) + (2*I + Pi)*t)*PolyLog[3, -(u/s)] + 
 Log[s]*(((4*I)/3)*fac1^2*Pi^2*((2*I)*t*(s + t) + Pi*(2*s^2 + s*t + 2*t^2)) - 
   (2*fac1^2*t*(3*s^2 + 4*s*t + 3*t^2)*Log[-t]^3)/(3*s) + 
   2*fac1^2*t*((2 + (3*I)*Pi)*s + (2 + I*Pi)*t)*Log[-u]^2 + 
   (2*fac1^2*(-4*s^3 - 2*s^2*t + 5*s*t^2 + 3*t^3)*Log[-u]^3)/(3*s) + 
   Log[-t]^2*((2*I)*fac1^2*(s + t)*((2*I)*t + Pi*(2*s + t)) + 
     (2*fac1^2*(6*s^3 + 10*s^2*t + s*t^2 + t^3)*Log[-u])/s) + 
   (8*I)*fac1^2*Pi*s*(s + 2*t)*PolyLog[2, -(t/s)] + 
   Log[-u]*((4*fac1^2*Pi^2*(s^3 + s^2*t + 2*s*t^2 + 2*t^3))/(3*s) + 
     8*fac1^2*s*t*PolyLog[2, -(t/s)]) + 
   Log[-t]*((-2*fac1^2*Pi^2*(8*s^3 + 19*s^2*t + 5*s*t^2 + 2*t^3))/(3*s) + 
     8*fac1^2*(t*(s + t) + I*Pi*(s^2 + s*t - t^2))*Log[-u] - 
     (2*fac1^2*(2*s^3 + s^2*t + 2*s*t^2 + t^3)*Log[-u]^2)/s + 
     8*fac1^2*s*(s + t)*PolyLog[2, -(t/s)]) - 4*fac1^2*(2*s^2 + 3*s*t + t^2)*
    PolyLog[3, -(t/s)] + 4*fac1^2*(s - t)*t*PolyLog[3, -(u/s)]) - 
 4*fac1^2*(s + t)*(2*s + 3*t)*PolyLog[4, -(t/s)] - 
 (4*fac1^2*(2*s^3 + 3*s^2*t - 3*s*t^2 - 2*t^3)*PolyLog[4, -(t/u)])/s - 
 4*fac1^2*t*(s + 3*t)*PolyLog[4, -(u/s)] + 
 (fac1^2*t*((-240*I)*Pi^3*(s + t) - 
    (Pi^4*(55*s^3 + 9*s^2*t + 73*s*t^2 + 45*t^3))/s^2 + 720*(s + t)*Zeta[3]))/
  90 + Log[-u]*((-8*I)*fac1^2*((-I + Pi)*s - I*t)*t*PolyLog[2, -(t/s)] + 
   (4*fac1^2*(2*s^3 + 3*s^2*t - 2*s*t^2 - t^3)*PolyLog[3, -(t/s)])/s + 
   (4*fac1^2*(2*s - t)*(s + t)^2*PolyLog[3, -(u/s)])/s + 
   (2*fac1^2*(2*Pi^2*t*(2*s^2 + 3*s*t + t^2) - 
      I*Pi^3*(4*s^3 + 5*s^2*t + 5*s*t^2 + 2*t^3) - 12*s^2*(s + 2*t)*Zeta[3]))/
    (3*s)) + Log[-t]*((-4*fac1^2*t*(2*s + t)*(s + t - I*Pi*t)*Log[-u]^2)/s + 
   (2*fac1^2*(8*s^4 + 14*s^3*t + 7*s^2*t^2 + 6*s*t^3 + 3*t^4)*Log[-u]^3)/
    (3*s^2) + 8*fac1^2*(s + t)*((-I)*Pi*s + t)*PolyLog[2, -(t/s)] + 
   Log[-u]*((2*fac1^2*Pi^2*(8*s^4 + 13*s^3*t + 4*s^2*t^2 + 4*s*t^3 + 3*t^4))/
      (3*s^2) - 8*fac1^2*s*(s + 2*t)*PolyLog[2, -(t/s)]) + 
   (4*fac1^2*t^2*(3*s + t)*PolyLog[3, -(t/s)])/s - 
   (4*fac1^2*(2*s^3 + 4*s^2*t - s*t^2 - t^3)*PolyLog[3, -(u/s)])/s + 
   (2*fac1^2*(-2*Pi^2*t^2*(s + t) + I*Pi^3*t*(3*s^2 + s*t + 2*t^2) + 
      12*s^2*(s + 2*t)*Zeta[3]))/(3*s))
