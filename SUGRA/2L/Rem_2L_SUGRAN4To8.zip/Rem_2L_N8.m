(* Created with the Wolfram Language : www.wolfram.com *)
-1/45*(fac1^2*Pi^4*t*(53*s + 16*t)) - 
 (2*fac1^2*(2*s^2 + 9*s*t + 3*t^2)*Log[s]^4)/3 - (fac1^2*t^2*Log[-t]^4)/3 - 
 ((4*I)/3)*fac1^2*Pi*t*(s + t)*Log[-u]^3 - 
 (fac1^2*(2*s^2 + 4*s*t + t^2)*Log[-u]^4)/3 + 
 Log[-t]^3*(((-4*I)/3)*fac1^2*Pi*t*(s + t) + (4*fac1^2*t*(s + t)*Log[-u])/
    3) + Log[s]^3*(((4*I)/3)*fac1^2*Pi*(3*s^2 + 8*s*t + 2*t^2) + 
   (4*fac1^2*s*(5*s + 9*t)*Log[-t])/3 - 
   (4*fac1^2*(s^2 - 9*s*t - 6*t^2)*Log[-u])/3) + 
 4*fac1^2*Pi^2*s*(s + 2*t)*PolyLog[2, -(t/s)] + 
 Log[-t]^2*(2*fac1^2*Pi^2*s*t - (4*I)*fac1^2*Pi*(s^2 - t^2)*Log[-u] - 
   2*fac1^2*s*(3*s + 5*t)*Log[-u]^2 + 4*fac1^2*t*(2*s + t)*
    PolyLog[2, -(t/s)]) + Log[s]^2*((2*fac1^2*Pi^2*(3*s^2 + 8*s*t + t^2))/3 + 
   2*fac1^2*(-3*s^2 - 3*s*t + t^2)*Log[-t]^2 - 
   (4*I)*fac1^2*Pi*(s^2 + 5*s*t + 2*t^2)*Log[-u] + 
   2*fac1^2*(3*s^2 - 3*s*t - 5*t^2)*Log[-u]^2 + 
   Log[-t]*((-4*I)*fac1^2*Pi*s*(2*s + 3*t) - 4*fac1^2*(2*s^2 + 6*s*t + t^2)*
      Log[-u]) - 4*fac1^2*s*(s + 2*t)*PolyLog[2, -(t/s)]) + 
 Log[-u]^2*((-2*fac1^2*Pi^2*(5*s^2 + 5*s*t - t^2))/3 + 
   4*fac1^2*(s^2 - t^2)*PolyLog[2, -(t/s)]) + (8*I)*fac1^2*Pi*(s^2 - t^2)*
  PolyLog[3, -(t/s)] - (8*I)*fac1^2*Pi*t*(2*s + t)*PolyLog[3, -(u/s)] + 
 Log[s]*(((4*I)/3)*fac1^2*Pi^3*(2*s^2 - 2*s*t - t^2) - 
   (4*fac1^2*s*t*Log[-t]^3)/3 + (4*I)*fac1^2*Pi*t*(3*s + 2*t)*Log[-u]^2 + 
   (4*fac1^2*(-2*s^2 + s*t + 3*t^2)*Log[-u]^3)/3 + 
   Log[-t]^2*((4*I)*fac1^2*Pi*s*(s + t) + 4*fac1^2*(3*s^2 + 4*s*t - t^2)*
      Log[-u]) + (8*I)*fac1^2*Pi*s*(s + 2*t)*PolyLog[2, -(t/s)] + 
   Log[-u]*((4*fac1^2*Pi^2*(s^2 - t^2))/3 + 8*fac1^2*t*(2*s + t)*
      PolyLog[2, -(t/s)]) + Log[-t]*((-16*fac1^2*Pi^2*s*(s + 2*t))/3 + 
     (8*I)*fac1^2*Pi*s*(s + 2*t)*Log[-u] - 4*fac1^2*(s^2 - 2*s*t - 2*t^2)*
      Log[-u]^2 + 8*fac1^2*(s^2 - t^2)*PolyLog[2, -(t/s)]) + 
   8*fac1^2*(-s^2 + t^2)*PolyLog[3, -(t/s)] + 8*fac1^2*t*(2*s + t)*
    PolyLog[3, -(u/s)]) + 8*fac1^2*(-s^2 + t^2)*PolyLog[4, -(t/s)] - 
 8*fac1^2*s*(s + 2*t)*PolyLog[4, -(t/u)] + 8*fac1^2*t*(2*s + t)*
  PolyLog[4, -(u/s)] + Log[-t]*((-4*I)*fac1^2*Pi*t*(2*s + t)*Log[-u]^2 + 
   (4*fac1^2*(4*s^2 + 3*s*t - 2*t^2)*Log[-u]^3)/3 - 
   (8*I)*fac1^2*Pi*(s^2 - t^2)*PolyLog[2, -(t/s)] + 
   Log[-u]*((4*fac1^2*Pi^2*s*(4*s + 5*t))/3 - 8*fac1^2*s*(s + 2*t)*
      PolyLog[2, -(t/s)]) - 8*fac1^2*t*(2*s + t)*PolyLog[3, -(t/s)] - 
   8*fac1^2*s*(s + 2*t)*PolyLog[3, -(u/s)] + 
   (8*fac1^2*s*(I*Pi^3*t + 3*(s + 2*t)*Zeta[3]))/3) + 
 Log[-u]*((-8*I)*fac1^2*Pi*t*(2*s + t)*PolyLog[2, -(t/s)] + 
   8*fac1^2*s*(s + 2*t)*PolyLog[3, -(t/s)] + 8*fac1^2*(s^2 - t^2)*
    PolyLog[3, -(u/s)] - ((4*I)/3)*fac1^2*(Pi^3*(2*s^2 - t^2) - 
     (6*I)*s*(s + 2*t)*Zeta[3]))
