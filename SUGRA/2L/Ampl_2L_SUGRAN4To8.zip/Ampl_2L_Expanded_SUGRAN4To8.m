(* Created with the Wolfram Language : www.wolfram.com *)
(2*(24*s^4 + 116*s^3*t - 18*Ds*s^3*t + 16*Nf*s^3*t + 3*Ds*Nf*s^3*t + 
    436*s^2*t^2 - 130*Ds*s^2*t^2 + 72*Nf*s^2*t^2 + 15*Ds*Nf*s^2*t^2 + 
    832*s*t^3 - 224*Ds*s*t^3 + 112*Nf*s*t^3 + 24*Ds*Nf*s*t^3 + 416*t^4 - 
    112*Ds*t^4 + 56*Nf*t^4 + 12*Ds*Nf*t^4)*Log[s]^4)/(3*s^2*(s + t)) + 
 ((-96*s^3*t^2 + 40*Nf*s^3*t^2 - Ds*Nf*s^3*t^2 - 76*s^2*t^3 - 38*Ds*s^2*t^3 + 
    144*Nf*s^2*t^3 - 3*Ds*Nf*s^2*t^3 + 132*s*t^4 - 82*Ds*s*t^4 + 
    192*Nf*s*t^4 - 2*Ds*Nf*s*t^4 + 88*t^5 - 44*Ds*t^5 + 88*Nf*t^5)*Log[-t]^4)/
  (3*s^3*(s + t)) + (4*(-6*s^5 + 3*Ds*s^5 - 6*Nf*s^5 - 84*s^4*t + 
    6*Ds*s^4*t + 6*Nf*s^4*t + (12*I)*Pi*s^4*t + 20*s^3*t^2 - 58*Ds*s^3*t^2 + 
    80*Nf*s^3*t^2 + 6*Ds*Nf*s^3*t^2 + (48*I)*Pi*s^3*t^2 + 
    (18*I)*Ds*Pi*s^3*t^2 - (12*I)*Nf*Pi*s^3*t^2 - (3*I)*Ds*Nf*Pi*s^3*t^2 + 
    516*s^2*t^3 - 222*Ds*s^2*t^3 + 306*Nf*s^2*t^3 + 12*Ds*Nf*s^2*t^3 - 
    (384*I)*Pi*s^2*t^3 + (108*I)*Ds*Pi*s^2*t^3 - (84*I)*Nf*Pi*s^2*t^3 - 
    (9*I)*Ds*Nf*Pi*s^2*t^3 + 564*s*t^4 - 234*Ds*s*t^4 + 384*Nf*s*t^4 + 
    6*Ds*Nf*s*t^4 - (372*I)*Pi*s*t^4 + (138*I)*Ds*Pi*s*t^4 - 
    (192*I)*Nf*Pi*s*t^4 - (6*I)*Ds*Nf*Pi*s*t^4 + 146*t^5 - 73*Ds*t^5 + 
    146*Nf*t^5 - (96*I)*Pi*t^5 + (48*I)*Ds*Pi*t^5 - (96*I)*Nf*Pi*t^5)*
   Log[-u]^3)/(9*s^3*t) + 
 ((32*s^5 + 104*s^4*t + 12*Ds*s^4*t - 20*Nf*s^4*t - 2*Ds*Nf*s^4*t - 
    96*s^3*t^2 + 96*Ds*s^3*t^2 - 140*Nf*s^3*t^2 - 7*Ds*Nf*s^3*t^2 - 
    476*s^2*t^3 + 226*Ds*s^2*t^3 - 376*Nf*s^2*t^3 - 7*Ds*Nf*s^2*t^3 - 
    468*s*t^4 + 218*Ds*s*t^4 - 408*Nf*s*t^4 - 2*Ds*Nf*s*t^4 - 152*t^5 + 
    76*Ds*t^5 - 152*Nf*t^5)*Log[-u]^4)/(3*s^3*(s + t)) + 
 Log[-t]^3*((4*((144*I)*Pi*s^5*t - (24*I)*Nf*Pi*s^5*t + 102*s^4*t^2 - 
      27*Ds*s^4*t^2 + 42*Nf*s^4*t^2 + (228*I)*Pi*s^4*t^2 + 
      (24*I)*Ds*Pi*s^4*t^2 - (60*I)*Nf*Pi*s^4*t^2 - (3*I)*Ds*Nf*Pi*s^4*t^2 + 
      396*s^3*t^3 - 66*Ds*s^3*t^3 + 6*Nf*s^3*t^3 + 6*Ds*Nf*s^3*t^3 - 
      (72*I)*Pi*s^3*t^3 + (42*I)*Ds*Pi*s^3*t^3 + (48*I)*Nf*Pi*s^3*t^3 - 
      (12*I)*Ds*Nf*Pi*s^3*t^3 + 280*s^2*t^4 + 16*Ds*s^2*t^4 - 
      230*Nf*s^2*t^4 + 12*Ds*Nf*s^2*t^4 - (144*I)*Pi*s^2*t^4 - 
      (36*I)*Ds*Pi*s^2*t^4 + (276*I)*Nf*Pi*s^2*t^4 - 
      (15*I)*Ds*Nf*Pi*s^2*t^4 - 166*s*t^5 + 131*Ds*s*t^5 - 346*Nf*s*t^5 + 
      6*Ds*Nf*s*t^5 + (108*I)*Pi*s*t^5 - (102*I)*Ds*Pi*s*t^5 + 
      (288*I)*Nf*Pi*s*t^5 - (6*I)*Ds*Nf*Pi*s*t^5 - 146*t^6 + 73*Ds*t^6 - 
      146*Nf*t^6 + (96*I)*Pi*t^6 - (48*I)*Ds*Pi*t^6 + (96*I)*Nf*Pi*t^6))/
    (9*s^3*(s + t)^2) - (4*(-8*s^3*t + 8*Nf*s^3*t - 32*s^2*t^2 - 
      8*Ds*s^2*t^2 + 38*Nf*s^2*t^2 - Ds*Nf*s^2*t^2 + 24*s*t^3 - 28*Ds*s*t^3 + 
      84*Nf*s*t^3 - 2*Ds*Nf*s*t^3 + 52*t^4 - 26*Ds*t^4 + 52*Nf*t^4)*Log[-u])/
    (3*s^3)) + Log[s]^3*
  ((4*(6*s^6 - 3*Ds*s^6 + 6*Nf*s^6 + 90*s^5*t - 9*Ds*s^5*t - 
      (156*I)*Pi*s^5*t - 758*s^4*t^2 + 175*Ds*s^4*t^2 - 8*Nf*s^4*t^2 - 
      24*Ds*Nf*s^4*t^2 - (468*I)*Pi*s^4*t^2 + (36*I)*Ds*Pi*s^4*t^2 - 
      (36*I)*Nf*Pi*s^4*t^2 - (6*I)*Ds*Nf*Pi*s^4*t^2 - 3220*s^3*t^3 + 
      746*Ds*s^3*t^3 - 100*Nf*s^3*t^3 - 96*Ds*Nf*s^3*t^3 - 
      (1176*I)*Pi*s^3*t^3 + (300*I)*Ds*Pi*s^3*t^3 - (192*I)*Nf*Pi*s^3*t^3 - 
      (36*I)*Ds*Nf*Pi*s^3*t^3 - 4268*s^2*t^4 + 1030*Ds*s^2*t^4 - 
      188*Nf*s^2*t^4 - 132*Ds*Nf*s^2*t^4 - (2544*I)*Pi*s^2*t^4 + 
      (720*I)*Ds*Pi*s^2*t^4 - (396*I)*Nf*Pi*s^2*t^4 - 
      (78*I)*Ds*Nf*Pi*s^2*t^4 - 2268*s*t^5 + 558*Ds*s*t^5 - 108*Nf*s*t^5 - 
      72*Ds*Nf*s*t^5 - (2520*I)*Pi*s*t^5 + (684*I)*Ds*Pi*s*t^5 - 
      (360*I)*Nf*Pi*s*t^5 - (72*I)*Ds*Nf*Pi*s*t^5 - 372*t^6 + 90*Ds*t^6 - 
      12*Nf*t^6 - 12*Ds*Nf*t^6 - (840*I)*Pi*t^6 + (228*I)*Ds*Pi*t^6 - 
      (120*I)*Nf*Pi*t^6 - (24*I)*Ds*Nf*Pi*t^6))/(9*s^2*t*(s + t)^2) + 
   (8*(-32*s^5 - 72*s^4*t + 6*Ds*s^4*t - Ds*Nf*s^4*t - 152*s^3*t^2 + 
      38*Ds*s^3*t^2 + 6*Nf*s^3*t^2 - 6*Ds*Nf*s^3*t^2 - 280*s^2*t^3 + 
      52*Ds*s^2*t^3 + 50*Nf*s^2*t^3 - 11*Ds*Nf*s^2*t^3 - 100*s*t^4 + 
      2*Ds*s*t^4 + 80*Nf*s*t^4 - 6*Ds*Nf*s*t^4 + 36*t^5 - 18*Ds*t^5 + 
      36*Nf*t^5)*Log[-t])/(3*s^3*(s + t)) - 
   (8*(-8*s^5 + 44*s^4*t - 12*Ds*s^4*t + 16*Nf*s^4*t + 2*Ds*Nf*s^4*t + 
      284*s^3*t^2 - 92*Ds*s^3*t^2 + 78*Nf*s^3*t^2 + 9*Ds*Nf*s^3*t^2 + 
      552*s^2*t^3 - 172*Ds*s^2*t^3 + 162*Nf*s^2*t^3 + 13*Ds*Nf*s^2*t^3 + 
      316*s*t^4 - 110*Ds*s*t^4 + 136*Nf*s*t^4 + 6*Ds*Nf*s*t^4 + 36*t^5 - 
      18*Ds*t^5 + 36*Nf*t^5)*Log[-u])/(3*s^3*(s + t))) + 
 ((16*Pi^2*s^2)/(s + t) - (16*s^2*Log[s]^2)/(s + t) - 
   (16*t^2*Log[-t]^2)/(s + t) - (32*I)*Pi*s*Log[-u] - 16*(s + t)*Log[-u]^2 + 
   Log[s]*(((32*I)*Pi*s^2)/(s + t) - (32*s*t*Log[-t])/(s + t) + 
     32*s*Log[-u]) + Log[-t]*(((32*I)*Pi*s*t)/(s + t) + 32*t*Log[-u]))/ep^2 + 
 (((8*I)*(2*Pi*s^2*t - Ds*Pi*s^2*t + 2*Nf*Pi*s^2*t - 4*Pi^3*s^2*t + 
      Nf*Pi^3*s^2*t + 2*Pi^3*s*t^2 - Ds*Pi^3*s*t^2 + 2*Nf*Pi^3*s*t^2 + 
      2*Pi^3*t^3 - Ds*Pi^3*t^3 + 2*Nf*Pi^3*t^3))/s^2 - 
   (8*(-4*s^2*t^2 + Nf*s^2*t^2 + 2*s*t^3 - Ds*s*t^3 + 2*Nf*s*t^3 + 2*t^4 - 
      Ds*t^4 + 2*Nf*t^4)*Log[-t]^3)/s^3 + 
   (8*t*(2*s^4 - Ds*s^4 + 2*Nf*s^4 - (2*I)*Pi*s^4 + I*Ds*Pi*s^4 - 
      (2*I)*Nf*Pi*s^4 + Nf*Pi^2*s^4 + 4*s^3*t - 2*Ds*s^3*t + 4*Nf*s^3*t - 
      (6*I)*Pi*s^3*t + (3*I)*Ds*Pi*s^3*t - (6*I)*Nf*Pi*s^3*t - 6*Pi^2*s^3*t - 
      Ds*Pi^2*s^3*t + 4*Nf*Pi^2*s^3*t + 2*s^2*t^2 - Ds*s^2*t^2 + 
      2*Nf*s^2*t^2 - (4*I)*Pi*s^2*t^2 + (2*I)*Ds*Pi*s^2*t^2 - 
      (4*I)*Nf*Pi*s^2*t^2 + 2*Pi^2*s^2*t^2 - 3*Ds*Pi^2*s^2*t^2 + 
      7*Nf*Pi^2*s^2*t^2 + 6*Pi^2*s*t^3 - 3*Ds*Pi^2*s*t^3 + 6*Nf*Pi^2*s*t^3 + 
      2*Pi^2*t^4 - Ds*Pi^2*t^4 + 2*Nf*Pi^2*t^4)*Log[-u])/(s^3*(s + t)) + 
   (8*t*(-2*s^2 + Ds*s^2 - 2*Nf*s^2 - (8*I)*Pi*s^2 + I*Nf*Pi*s^2 - 6*s*t + 
      3*Ds*s*t - 6*Nf*s*t + (2*I)*Pi*s*t - I*Ds*Pi*s*t + (2*I)*Nf*Pi*s*t - 
      4*t^2 + 2*Ds*t^2 - 4*Nf*t^2 + (2*I)*Pi*t^2 - I*Ds*Pi*t^2 + 
      (2*I)*Nf*Pi*t^2)*Log[-u]^2)/s^2 - 
   (8*(s + t)*(4*s^2*t - Nf*s^2*t - 2*s*t^2 + Ds*s*t^2 - 2*Nf*s*t^2 - 2*t^3 + 
      Ds*t^3 - 2*Nf*t^3)*Log[-u]^3)/s^3 + 
   Log[s]^2*(32*s*Log[-t] - (32*s*t*Log[-u])/(s + t)) + 
   Log[-t]^2*((8*((-8*I)*Pi*s^2*t + I*Nf*Pi*s^2*t - 2*s*t^2 + Ds*s*t^2 - 
        2*Nf*s*t^2 + (2*I)*Pi*s*t^2 - I*Ds*Pi*s*t^2 + (2*I)*Nf*Pi*s*t^2 - 
        4*t^3 + 2*Ds*t^3 - 4*Nf*t^3 + (2*I)*Pi*t^3 - I*Ds*Pi*t^3 + 
        (2*I)*Nf*Pi*t^3))/s^2 + (8*(-8*s^4*t + Nf*s^4*t - 14*s^3*t^2 - 
        Ds*s^3*t^2 + 6*Nf*s^3*t^2 - 2*s^2*t^3 - 5*Ds*s^2*t^3 + 
        13*Nf*s^2*t^3 + 14*s*t^4 - 7*Ds*s*t^4 + 14*Nf*s*t^4 + 6*t^5 - 
        3*Ds*t^5 + 6*Nf*t^5)*Log[-u])/(s^3*(s + t))) + 
   Log[-t]*((-8*(4*Pi^2*s^4 - (2*I)*Pi*s^3*t + I*Ds*Pi*s^3*t - 
        (2*I)*Nf*Pi*s^3*t + 2*s^2*t^2 - Ds*s^2*t^2 + 2*Nf*s^2*t^2 - 
        (4*I)*Pi*s^2*t^2 + (2*I)*Ds*Pi*s^2*t^2 - (4*I)*Nf*Pi*s^2*t^2 - 
        4*Pi^2*s^2*t^2 + Nf*Pi^2*s^2*t^2 + 2*Pi^2*s*t^3 - Ds*Pi^2*s*t^3 + 
        2*Nf*Pi^2*s*t^3 + 2*Pi^2*t^4 - Ds*Pi^2*t^4 + 2*Nf*Pi^2*t^4))/s^3 + 
     (8*((8*I)*Pi*s^4 + 2*s^3*t - Ds*s^3*t + 2*Nf*s^3*t + (16*I)*Pi*s^3*t - 
        (2*I)*Nf*Pi*s^3*t + 10*s^2*t^2 - 5*Ds*s^2*t^2 + 10*Nf*s^2*t^2 + 
        (12*I)*Pi*s^2*t^2 + (2*I)*Ds*Pi*s^2*t^2 - (6*I)*Nf*Pi*s^2*t^2 + 
        16*s*t^3 - 8*Ds*s*t^3 + 16*Nf*s*t^3 - (8*I)*Pi*s*t^3 + 
        (4*I)*Ds*Pi*s*t^3 - (8*I)*Nf*Pi*s*t^3 + 8*t^4 - 4*Ds*t^4 + 8*Nf*t^4 - 
        (4*I)*Pi*t^4 + (2*I)*Ds*Pi*t^4 - (4*I)*Nf*Pi*t^4)*Log[-u])/
      (s^2*(s + t)) + (8*(4*s^4 + 8*s^3*t - 2*Nf*s^3*t + 8*s^2*t^2 + 
        2*Ds*s^2*t^2 - 7*Nf*s^2*t^2 - 10*s*t^3 + 5*Ds*s*t^3 - 10*Nf*s*t^3 - 
        6*t^4 + 3*Ds*t^4 - 6*Nf*t^4)*Log[-u]^2)/s^3) + 
   Log[s]*((8*t*(-2*s^2 + Ds*s^2 - 2*Nf*s^2 + 4*Pi^2*s^2 - Nf*Pi^2*s^2 - 
        2*Pi^2*s*t + Ds*Pi^2*s*t - 2*Nf*Pi^2*s*t - 2*Pi^2*t^2 + Ds*Pi^2*t^2 - 
        2*Nf*Pi^2*t^2))/s^2 - (8*(-8*s^2*t + Nf*s^2*t + 2*s*t^2 - Ds*s*t^2 + 
        2*Nf*s*t^2 + 2*t^3 - Ds*t^3 + 2*Nf*t^3)*Log[-t]^2)/s^2 + 
     (8*t*(2*s^2 - Ds*s^2 + 2*Nf*s^2 + (8*I)*Pi*s^2 + 6*s*t - 3*Ds*s*t + 
        6*Nf*s*t + 4*t^2 - 2*Ds*t^2 + 4*Nf*t^2)*Log[-u])/(s*(s + t)) + 
     (8*(8*s^2*t - Nf*s^2*t - 2*s*t^2 + Ds*s*t^2 - 2*Nf*s*t^2 - 2*t^3 + 
        Ds*t^3 - 2*Nf*t^3)*Log[-u]^2)/s^2 + 
     Log[-t]*((8*((-8*I)*Pi*s^2 - 2*s*t + Ds*s*t - 2*Nf*s*t - 4*t^2 + 
          2*Ds*t^2 - 4*Nf*t^2))/s + (16*(-4*s^4 - 8*s^3*t + Nf*s^3*t - 
          6*s^2*t^2 - Ds*s^2*t^2 + 3*Nf*s^2*t^2 + 4*s*t^3 - 2*Ds*s*t^3 + 
          4*Nf*s*t^3 + 2*t^4 - Ds*t^4 + 2*Nf*t^4)*Log[-u])/(s^2*(s + t)))))/
  ep - (4*(48*Pi^2*s^5 - (384*I)*Pi*s^4*t + (96*I)*Ds*Pi*s^4*t - 
    (24*I)*Nf*Pi*s^4*t - (12*I)*Ds*Nf*Pi*s^4*t + 60*Pi^2*s^4*t + 
    6*Ds*Pi^2*s^4*t + 4*Nf*Pi^2*s^4*t - Ds*Nf*Pi^2*s^4*t - 
    (1152*I)*Pi*s^3*t^2 + (288*I)*Ds*Pi*s^3*t^2 - (72*I)*Nf*Pi*s^3*t^2 - 
    (36*I)*Ds*Nf*Pi*s^3*t^2 - 140*Pi^2*s^3*t^2 + 34*Ds*Pi^2*s^3*t^2 - 
    20*Nf*Pi^2*s^3*t^2 - 3*Ds*Nf*Pi^2*s^3*t^2 - (768*I)*Pi*s^2*t^3 + 
    (192*I)*Ds*Pi*s^2*t^3 - (48*I)*Nf*Pi*s^2*t^3 - (24*I)*Ds*Nf*Pi*s^2*t^3 - 
    200*Pi^2*s^2*t^3 + 76*Ds*Pi^2*s^2*t^3 - 120*Nf*Pi^2*s^2*t^3 - 
    2*Ds*Nf*Pi^2*s^2*t^3 - 160*Pi^2*s*t^4 + 80*Ds*Pi^2*s*t^4 - 
    160*Nf*Pi^2*s*t^4 - 64*Pi^2*t^5 + 32*Ds*Pi^2*t^5 - 64*Nf*Pi^2*t^5)*
   PolyLog[2, -(t/s)])/(3*s^3*(s + t)) + 
 Log[s]^2*((-2*((12*I)*Pi*s^7 - (6*I)*Ds*Pi*s^7 + (12*I)*Nf*Pi*s^7 + 
      10*s^6*t - 5*Ds*s^6*t + 10*Nf*s^6*t + (180*I)*Pi*s^6*t - 
      (18*I)*Ds*Pi*s^6*t + 36*Pi^2*s^6*t + 382*s^5*t^2 - 95*Ds*s^5*t^2 + 
      22*Nf*s^5*t^2 + 12*Ds*Nf*s^5*t^2 - (204*I)*Pi*s^5*t^2 + 
      (78*I)*Ds*Pi*s^5*t^2 - (24*I)*Nf*Pi*s^5*t^2 - (12*I)*Ds*Nf*Pi*s^5*t^2 + 
      100*Pi^2*s^5*t^2 + 14*Nf*Pi^2*s^5*t^2 + 744*s^4*t^3 - 180*Ds*s^4*t^3 + 
      24*Nf*s^4*t^3 + 24*Ds*Nf*s^4*t^3 - (1536*I)*Pi*s^4*t^3 + 
      (384*I)*Ds*Pi*s^4*t^3 - (96*I)*Nf*Pi*s^4*t^3 - 
      (48*I)*Ds*Nf*Pi*s^4*t^3 + 60*Pi^2*s^4*t^3 - 14*Ds*Pi^2*s^4*t^3 + 
      32*Nf*Pi^2*s^4*t^3 + 2*Ds*Nf*Pi^2*s^4*t^3 + 372*s^3*t^4 - 
      90*Ds*s^3*t^4 + 12*Nf*s^3*t^4 + 12*Ds*Nf*s^3*t^4 - 
      (1920*I)*Pi*s^3*t^4 + (480*I)*Ds*Pi*s^3*t^4 - (120*I)*Nf*Pi*s^3*t^4 - 
      (60*I)*Ds*Nf*Pi*s^3*t^4 + 92*Pi^2*s^3*t^4 - 22*Ds*Pi^2*s^3*t^4 - 
      46*Nf*Pi^2*s^3*t^4 + 8*Ds*Nf*Pi^2*s^3*t^4 - (768*I)*Pi*s^2*t^5 + 
      (192*I)*Ds*Pi*s^2*t^5 - (48*I)*Nf*Pi*s^2*t^5 - 
      (24*I)*Ds*Nf*Pi*s^2*t^5 + 84*Pi^2*s^2*t^5 + 30*Ds*Pi^2*s^2*t^5 - 
      196*Nf*Pi^2*s^2*t^5 + 10*Ds*Nf*Pi^2*s^2*t^5 - 76*Pi^2*s*t^6 + 
      70*Ds*Pi^2*s*t^6 - 196*Nf*Pi^2*s*t^6 + 4*Ds*Nf*Pi^2*s*t^6 - 
      64*Pi^2*t^7 + 32*Ds*Pi^2*t^7 - 64*Nf*Pi^2*t^7))/(3*s^3*t*(s + t)^2) - 
   (4*(-12*s^5 - 8*s^4*t + 3*Nf*s^4*t + 6*s^3*t^2 - 3*Ds*s^3*t^2 + 
      21*Nf*s^3*t^2 - Ds*Nf*s^3*t^2 - 8*s^2*t^3 - 16*Ds*s^2*t^3 + 
      72*Nf*s^2*t^3 - 3*Ds*Nf*s^2*t^3 + 26*s*t^4 - 29*Ds*s*t^4 + 
      86*Nf*s*t^4 - 2*Ds*Nf*s*t^4 + 32*t^5 - 16*Ds*t^5 + 32*Nf*t^5)*
     Log[-t]^2)/(s^3*(s + t)) + 
   (4*(-6*s^5 + 3*Ds*s^5 - 6*Nf*s^5 - 86*s^4*t + 7*Ds*s^4*t + 4*Nf*s^4*t + 
      (60*I)*Pi*s^4*t + 568*s^3*t^2 - 128*Ds*s^3*t^2 - 2*Nf*s^3*t^2 + 
      18*Ds*Nf*s^3*t^2 + (144*I)*Pi*s^3*t^2 - (18*I)*Ds*Pi*s^3*t^2 + 
      (36*I)*Nf*Pi*s^3*t^2 + (3*I)*Ds*Nf*Pi*s^3*t^2 + 1778*s^2*t^3 - 
      409*Ds*s^2*t^3 + 38*Nf*s^2*t^3 + 54*Ds*Nf*s^2*t^3 + 
      (444*I)*Pi*s^2*t^3 - (150*I)*Ds*Pi*s^2*t^3 + (132*I)*Nf*Pi*s^2*t^3 + 
      (15*I)*Ds*Nf*Pi*s^2*t^3 + 1500*s*t^4 - 366*Ds*s*t^4 + 60*Nf*s*t^4 + 
      48*Ds*Nf*s*t^4 + (912*I)*Pi*s*t^4 - (264*I)*Ds*Pi*s*t^4 + 
      (192*I)*Nf*Pi*s*t^4 + (24*I)*Ds*Nf*Pi*s*t^4 + 372*t^5 - 90*Ds*t^5 + 
      12*Nf*t^5 + 12*Ds*Nf*t^5 + (456*I)*Pi*t^5 - (132*I)*Ds*Pi*t^5 + 
      (96*I)*Nf*Pi*t^5 + (12*I)*Ds*Nf*Pi*t^5)*Log[-u])/(3*s^2*t*(s + t)) - 
   (4*(20*s^5 + 4*s^4*t + 6*Ds*s^4*t - 13*Nf*s^4*t - Ds*Nf*s^4*t - 
      126*s^3*t^2 + 51*Ds*s^3*t^2 - 63*Nf*s^3*t^2 - 4*Ds*Nf*s^3*t^2 - 
      280*s^2*t^3 + 104*Ds*s^2*t^3 - 140*Nf*s^2*t^3 - 5*Ds*Nf*s^2*t^3 - 
      190*s*t^4 + 79*Ds*s*t^4 - 130*Nf*s*t^4 - 2*Ds*Nf*s*t^4 - 40*t^5 + 
      20*Ds*t^5 - 40*Nf*t^5)*Log[-u]^2)/(s^3*(s + t)) + 
   Log[-t]*((4*(2*s^5 - Ds*s^5 + 2*Nf*s^5 + (96*I)*Pi*s^5 + 276*s^4*t - 
        54*Ds*s^4*t + 6*Nf*s^4*t + 6*Ds*Nf*s^4*t + (264*I)*Pi*s^4*t - 
        (18*I)*Ds*Pi*s^4*t + (3*I)*Ds*Nf*Pi*s^4*t + 874*s^3*t^2 - 
        209*Ds*s^3*t^2 + 64*Nf*s^3*t^2 + 24*Ds*Nf*s^3*t^2 + 
        (588*I)*Pi*s^3*t^2 - (132*I)*Ds*Pi*s^3*t^2 + (24*I)*Nf*Pi*s^3*t^2 + 
        (18*I)*Ds*Nf*Pi*s^3*t^2 + 990*s^2*t^3 - 255*Ds*s^2*t^3 + 
        90*Nf*s^2*t^3 + 30*Ds*Nf*s^2*t^3 + (1188*I)*Pi*s^2*t^3 - 
        (306*I)*Ds*Pi*s^2*t^3 + (72*I)*Nf*Pi*s^2*t^3 + (39*I)*Ds*Nf*Pi*s^2*
         t^3 + 396*s*t^4 - 102*Ds*s*t^4 + 36*Nf*s*t^4 + 12*Ds*Nf*s*t^4 + 
        (1152*I)*Pi*s*t^4 - (288*I)*Ds*Pi*s*t^4 + (72*I)*Nf*Pi*s*t^4 + 
        (36*I)*Ds*Nf*Pi*s*t^4 + (384*I)*Pi*t^5 - (96*I)*Ds*Pi*t^5 + 
        (24*I)*Nf*Pi*t^5 + (12*I)*Ds*Nf*Pi*t^5))/(3*s^2*(s + t)^2) - 
     (8*(-12*s^5 - 56*s^4*t + 6*Ds*s^4*t - 3*Nf*s^4*t - Ds*Nf*s^4*t - 
        158*s^3*t^2 + 41*Ds*s^3*t^2 - 15*Nf*s^3*t^2 - 5*Ds*Nf*s^3*t^2 - 
        272*s^2*t^3 + 68*Ds*s^2*t^3 - 22*Nf*s^2*t^3 - 8*Ds*Nf*s^2*t^3 - 
        126*s*t^4 + 31*Ds*s*t^4 - 6*Nf*s*t^4 - 4*Ds*Nf*s*t^4 + 4*t^5 - 
        2*Ds*t^5 + 4*Nf*t^5)*Log[-u])/(s^3*(s + t))) + 
   (64*s*(s + 2*t)*PolyLog[2, -(t/s)])/(s + t)) + 
 Log[-u]^2*((2*((-12*I)*Pi*s^6 + (6*I)*Ds*Pi*s^6 - (12*I)*Nf*Pi*s^6 - 
      10*s^5*t + 5*Ds*s^5*t - 10*Nf*s^5*t - (176*I)*Pi*s^5*t + 
      (16*I)*Ds*Pi*s^5*t + (4*I)*Nf*Pi*s^5*t + 76*Pi^2*s^5*t - 508*s^4*t^2 + 
      158*Ds*s^4*t^2 - 148*Nf*s^4*t^2 - 12*Ds*Nf*s^4*t^2 + 
      (68*I)*Pi*s^4*t^2 - (82*I)*Ds*Pi*s^4*t^2 + (68*I)*Nf*Pi*s^4*t^2 + 
      (12*I)*Ds*Nf*Pi*s^4*t^2 + 176*Pi^2*s^4*t^2 - 26*Nf*Pi^2*s^4*t^2 - 
      1528*s^3*t^3 + 476*Ds*s^3*t^3 - 448*Nf*s^3*t^3 - 36*Ds*Nf*s^3*t^3 + 
      (1128*I)*Pi*s^3*t^3 - (348*I)*Ds*Pi*s^3*t^3 + (228*I)*Nf*Pi*s^3*t^3 + 
      (36*I)*Ds*Nf*Pi*s^3*t^3 + 184*Pi^2*s^3*t^3 + 26*Ds*Pi^2*s^3*t^3 - 
      112*Nf*Pi^2*s^3*t^3 + Ds*Nf*Pi^2*s^3*t^3 - 1572*s^2*t^4 + 
      498*Ds*s^2*t^4 - 492*Nf*s^2*t^4 - 36*Ds*Nf*s^2*t^4 + 
      (1384*I)*Pi*s^2*t^4 - (404*I)*Ds*Pi*s^2*t^4 + (304*I)*Nf*Pi*s^2*t^4 + 
      (36*I)*Ds*Nf*Pi*s^2*t^4 - 40*Pi^2*s^2*t^4 + 84*Ds*Pi^2*s^2*t^4 - 
      230*Nf*Pi^2*s^2*t^4 + 3*Ds*Nf*Pi^2*s^2*t^4 - 542*s*t^5 + 175*Ds*s*t^5 - 
      182*Nf*s*t^5 - 12*Ds*Nf*s*t^5 + (488*I)*Pi*s*t^5 - 
      (148*I)*Ds*Pi*s*t^5 + (128*I)*Nf*Pi*s*t^5 + (12*I)*Ds*Nf*Pi*s*t^5 - 
      160*Pi^2*s*t^5 + 96*Ds*Pi^2*s*t^5 - 220*Nf*Pi^2*s*t^5 + 
      2*Ds*Nf*Pi^2*s*t^5 - 76*Pi^2*t^6 + 38*Ds*Pi^2*t^6 - 76*Nf*Pi^2*t^6))/
    (3*s^3*t*(s + t)) - (16*(4*s^4 + 4*s^3*t - 2*Nf*s^3*t + 2*Ds*s^2*t^2 - 
      5*Nf*s^2*t^2 - 6*s*t^3 + 3*Ds*s*t^3 - 6*Nf*s*t^3 - 2*t^4 + Ds*t^4 - 
      2*Nf*t^4)*PolyLog[2, -(t/s)])/s^3) + 
 Log[-t]^2*((-2*(-48*Pi^2*s^6 + (24*I)*Pi*s^5*t - (12*I)*Ds*Pi*s^5*t + 
      (24*I)*Nf*Pi*s^5*t - 96*Pi^2*s^5*t + 64*s^4*t^2 - 32*Ds*s^4*t^2 + 
      64*Nf*s^4*t^2 + (108*I)*Pi*s^4*t^2 + (18*I)*Ds*Pi*s^4*t^2 - 
      (72*I)*Nf*Pi*s^4*t^2 - 36*Pi^2*s^4*t^2 - 6*Nf*Pi^2*s^4*t^2 - 
      Ds*Nf*Pi^2*s^4*t^2 + 660*s^3*t^3 - 234*Ds*s^3*t^3 + 300*Nf*s^3*t^3 + 
      12*Ds*Nf*s^3*t^3 - (472*I)*Pi*s^3*t^3 + (212*I)*Ds*Pi*s^3*t^3 - 
      (292*I)*Nf*Pi*s^3*t^3 - (12*I)*Ds*Nf*Pi*s^3*t^3 + 28*Pi^2*s^3*t^3 + 
      8*Ds*Pi^2*s^3*t^3 - 4*Ds*Nf*Pi^2*s^3*t^3 + 1138*s^2*t^4 - 
      377*Ds*s^2*t^4 + 418*Nf*s^2*t^4 + 24*Ds*Nf*s^2*t^4 - 
      (1056*I)*Pi*s^2*t^4 + (336*I)*Ds*Pi*s^2*t^4 - (336*I)*Nf*Pi*s^2*t^4 - 
      (24*I)*Ds*Nf*Pi*s^2*t^4 - 36*Pi^2*s^2*t^4 + 18*Ds*Pi^2*s^2*t^4 + 
      14*Nf*Pi^2*s^2*t^4 - 5*Ds*Nf*Pi^2*s^2*t^4 + 542*s*t^5 - 175*Ds*s*t^5 + 
      182*Nf*s*t^5 + 12*Ds*Nf*s*t^5 - (488*I)*Pi*s*t^5 + 
      (148*I)*Ds*Pi*s*t^5 - (128*I)*Nf*Pi*s*t^5 - (12*I)*Ds*Nf*Pi*s*t^5 - 
      56*Pi^2*s*t^5 + 12*Ds*Pi^2*s*t^5 + 4*Nf*Pi^2*s*t^5 - 
      2*Ds*Nf*Pi^2*s*t^5 - 4*Pi^2*t^6 + 2*Ds*Pi^2*t^6 - 4*Nf*Pi^2*t^6))/
    (3*s^3*(s + t)^2) + (4*(-52*s^4*t + 2*Ds*s^4*t + 8*Nf*s^4*t - 
      (60*I)*Pi*s^4*t - 154*s^3*t^2 - 7*Ds*s^3*t^2 + 56*Nf*s^3*t^2 - 
      (36*I)*Pi*s^3*t^2 - (36*I)*Nf*Pi*s^3*t^2 + (3*I)*Ds*Nf*Pi*s^3*t^2 - 
      124*s^2*t^3 - 46*Ds*s^2*t^3 + 206*Nf*s^2*t^3 - 6*Ds*Nf*s^2*t^3 + 
      (60*I)*Pi*s^2*t^3 + (30*I)*Ds*Pi*s^2*t^3 - (180*I)*Nf*Pi*s^2*t^3 + 
      (9*I)*Ds*Nf*Pi*s^2*t^3 + 126*s*t^4 - 111*Ds*s*t^4 + 306*Nf*s*t^4 - 
      6*Ds*Nf*s*t^4 - (60*I)*Pi*s*t^4 + (78*I)*Ds*Pi*s*t^4 - 
      (240*I)*Nf*Pi*s*t^4 + (6*I)*Ds*Nf*Pi*s*t^4 + 146*t^5 - 73*Ds*t^5 + 
      146*Nf*t^5 - (96*I)*Pi*t^5 + (48*I)*Ds*Pi*t^5 - (96*I)*Nf*Pi*t^5)*
     Log[-u])/(3*s^3*(s + t)) - 
   (2*(-24*s^5 - 64*s^4*t - 2*Nf*s^4*t - 36*s^3*t^2 + 2*Ds*s^3*t^2 + 
      14*Nf*s^3*t^2 - Ds*Nf*s^3*t^2 - 44*s^2*t^3 - 14*Ds*s^2*t^3 + 
      76*Nf*s^2*t^3 - 3*Ds*Nf*s^2*t^3 + 48*s*t^4 - 40*Ds*s*t^4 + 
      108*Nf*s*t^4 - 2*Ds*Nf*s*t^4 + 48*t^5 - 24*Ds*t^5 + 48*Nf*t^5)*
     Log[-u]^2)/(s^3*(s + t)) + 
   (16*(-4*s^4*t - Nf*s^4*t - 6*s^3*t^2 + Ds*s^3*t^2 - 2*Nf*s^3*t^2 - 
      6*s^2*t^3 + Ds*s^2*t^3 - Nf*s^2*t^3 + 2*s*t^4 - Ds*s*t^4 + 2*Nf*s*t^4 + 
      2*t^5 - Ds*t^5 + 2*Nf*t^5)*PolyLog[2, -(t/s)])/(s^3*(s + t))) + 
 (8*((-48*I)*Pi*s^4 + 40*s^3*t + 4*Ds*s^3*t - 20*Nf*s^3*t - (24*I)*Pi*s^3*t - 
    (18*I)*Ds*Pi*s^3*t + (18*I)*Nf*Pi*s^3*t + (3*I)*Ds*Nf*Pi*s^3*t + 
    34*s^2*t^2 + 7*Ds*s^2*t^2 - 26*Nf*s^2*t^2 + (432*I)*Pi*s^2*t^2 - 
    (132*I)*Ds*Pi*s^2*t^2 + (78*I)*Nf*Pi*s^2*t^2 + (15*I)*Ds*Nf*Pi*s^2*t^2 + 
    180*s*t^3 - 42*Ds*s*t^3 + 6*Ds*Nf*s*t^3 + (840*I)*Pi*s*t^3 - 
    (228*I)*Ds*Pi*s*t^3 + (120*I)*Nf*Pi*s*t^3 + (24*I)*Ds*Nf*Pi*s*t^3 + 
    186*t^4 - 45*Ds*t^4 + 6*Nf*t^4 + 6*Ds*Nf*t^4 + (420*I)*Pi*t^4 - 
    (114*I)*Ds*Pi*t^4 + (60*I)*Nf*Pi*t^4 + (12*I)*Ds*Nf*Pi*t^4)*
   PolyLog[3, -(t/s)])/(3*s^2*(s + t)) + 
 (8*((-12*I)*Pi*s^4 + 232*s^3*t - 44*Ds*s^3*t - 8*Nf*s^3*t + 6*Ds*Nf*s^3*t + 
    (48*I)*Pi*s^3*t - (18*I)*Ds*Pi*s^3*t + (18*I)*Nf*Pi*s^3*t + 
    (3*I)*Ds*Nf*Pi*s^3*t + 610*s^2*t^2 - 137*Ds*s^2*t^2 + 10*Nf*s^2*t^2 + 
    18*Ds*Nf*s^2*t^2 + (432*I)*Pi*s^2*t^2 - (132*I)*Ds*Pi*s^2*t^2 + 
    (78*I)*Nf*Pi*s^2*t^2 + (15*I)*Ds*Nf*Pi*s^2*t^2 + 564*s*t^3 - 
    138*Ds*s*t^3 + 24*Nf*s*t^3 + 18*Ds*Nf*s*t^3 + (840*I)*Pi*s*t^3 - 
    (228*I)*Ds*Pi*s*t^3 + (120*I)*Nf*Pi*s*t^3 + (24*I)*Ds*Nf*Pi*s*t^3 + 
    186*t^4 - 45*Ds*t^4 + 6*Nf*t^4 + 6*Ds*Nf*t^4 + (420*I)*Pi*t^4 - 
    (114*I)*Ds*Pi*t^4 + (60*I)*Nf*Pi*t^4 + (12*I)*Ds*Nf*Pi*t^4)*
   PolyLog[3, -(u/s)])/(3*s^2*(s + t)) - 
 (8*(-8*s^3 - 4*s^2*t - 6*Ds*s^2*t + 8*Nf*s^2*t + Ds*Nf*s^2*t + 144*s*t^2 - 
    40*Ds*s*t^2 + 24*Nf*s*t^2 + 4*Ds*Nf*s*t^2 + 144*t^3 - 40*Ds*t^3 + 
    24*Nf*t^3 + 4*Ds*Nf*t^3)*PolyLog[4, -(t/s)])/s^2 - 
 (8*(-8*s^5 + 20*s^4*t - 6*Ds*s^4*t - 4*Nf*s^4*t + Ds*Nf*s^4*t + 
    140*s^3*t^2 - 34*Ds*s^3*t^2 + 20*Nf*s^3*t^2 + 3*Ds*Nf*s^3*t^2 + 
    200*s^2*t^3 - 76*Ds*s^2*t^3 + 120*Nf*s^2*t^3 + 2*Ds*Nf*s^2*t^3 + 
    160*s*t^4 - 80*Ds*s*t^4 + 160*Nf*s*t^4 + 64*t^5 - 32*Ds*t^5 + 64*Nf*t^5)*
   PolyLog[4, -(t/u)])/(s^3*(s + t)) - 
 (8*(4*s^3*t - 6*Ds*s^3*t + 8*Nf*s^3*t + Ds*Nf*s^3*t + 140*s^2*t^2 - 
    46*Ds*s^2*t^2 + 32*Nf*s^2*t^2 + 5*Ds*Nf*s^2*t^2 + 288*s*t^3 - 
    80*Ds*s*t^3 + 48*Nf*s*t^3 + 8*Ds*Nf*s*t^3 + 144*t^4 - 40*Ds*t^4 + 
    24*Nf*t^4 + 4*Ds*Nf*t^4)*PolyLog[4, -(u/s)])/(s^2*(s + t)) + 
 (-240*Pi^2*s^5 + 120*Ds*Pi^2*s^5 - 240*Nf*Pi^2*s^5 - 120*Pi^4*s^5 - 
   360*s^4*t + 360*Ds*s^4*t - 90*Ds^2*s^4*t - 360*Nf*s^4*t + 
   180*Ds*Nf*s^4*t + (2520*I)*Pi*s^4*t - (1260*I)*Ds*Pi*s^4*t + 
   (2520*I)*Nf*Pi*s^4*t - 1200*Pi^2*s^4*t + 600*Ds*Pi^2*s^4*t - 
   1200*Nf*Pi^2*s^4*t + (520*I)*Pi^3*s^4*t - (20*I)*Ds*Pi^3*s^4*t - 
   (80*I)*Nf*Pi^3*s^4*t + 676*Pi^4*s^4*t - 90*Ds*Pi^4*s^4*t + 
   72*Nf*Pi^4*s^4*t + 15*Ds*Nf*Pi^4*s^4*t - 360*s^3*t^2 + 360*Ds*s^3*t^2 - 
   90*Ds^2*s^3*t^2 - 360*Nf*s^3*t^2 + 180*Ds*Nf*s^3*t^2 + 
   (2520*I)*Pi*s^3*t^2 - (1260*I)*Ds*Pi*s^3*t^2 + (2520*I)*Nf*Pi*s^3*t^2 - 
   14020*Pi^2*s^3*t^2 + 4130*Ds*Pi^2*s^3*t^2 - 3220*Nf*Pi^2*s^3*t^2 - 
   360*Ds*Nf*Pi^2*s^3*t^2 + (7480*I)*Pi^3*s^3*t^2 - 
   (1580*I)*Ds*Pi^3*s^3*t^2 - (320*I)*Nf*Pi^3*s^3*t^2 + 
   (240*I)*Ds*Nf*Pi^3*s^3*t^2 + 2340*Pi^4*s^3*t^2 - 642*Ds*Pi^4*s^3*t^2 + 
   132*Nf*Pi^4*s^3*t^2 + 92*Ds*Nf*Pi^4*s^3*t^2 - 25640*Pi^2*s^2*t^3 + 
   7060*Ds*Pi^2*s^2*t^3 - 4040*Nf*Pi^2*s^2*t^3 - 720*Ds*Nf*Pi^2*s^2*t^3 + 
   (17760*I)*Pi^3*s^2*t^3 - (4080*I)*Ds*Pi^3*s^2*t^3 - 
   (240*I)*Nf*Pi^3*s^2*t^3 + (600*I)*Ds*Nf*Pi^3*s^2*t^3 + 4468*Pi^4*s^2*t^3 - 
   934*Ds*Pi^4*s^2*t^3 - 492*Nf*Pi^4*s^2*t^3 + 171*Ds*Nf*Pi^4*s^2*t^3 - 
   12820*Pi^2*s*t^4 + 3530*Ds*Pi^2*s*t^4 - 2020*Nf*Pi^2*s*t^4 - 
   360*Ds*Nf*Pi^2*s*t^4 + (10800*I)*Pi^3*s*t^4 - (2520*I)*Ds*Pi^3*s*t^4 + 
   (360*I)*Ds*Nf*Pi^3*s*t^4 + 1724*Pi^4*s*t^4 - 110*Ds*Pi^4*s*t^4 - 
   1096*Nf*Pi^4*s*t^4 + 94*Ds*Nf*Pi^4*s*t^4 - 544*Pi^4*t^5 + 
   272*Ds*Pi^4*t^5 - 544*Nf*Pi^4*t^5 + (1440*I)*Pi*s^5*Zeta[3] - 
   27840*s^4*t*Zeta[3] + 5280*Ds*s^4*t*Zeta[3] + 960*Nf*s^4*t*Zeta[3] - 
   720*Ds*Nf*s^4*t*Zeta[3] - 50880*s^3*t^2*Zeta[3] + 
   16800*Ds*s^3*t^2*Zeta[3] - 22080*Nf*s^3*t^2*Zeta[3] - 
   720*Ds*Nf*s^3*t^2*Zeta[3] - 46080*s^2*t^3*Zeta[3] + 
   23040*Ds*s^2*t^3*Zeta[3] - 46080*Nf*s^2*t^3*Zeta[3] - 
   23040*s*t^4*Zeta[3] + 11520*Ds*s*t^4*Zeta[3] - 23040*Nf*s*t^4*Zeta[3])/
  (45*s^3*(s + t)) + 
 Log[-t]*((4*(2*s^5 - Ds*s^5 + 2*Nf*s^5 + 354*s^4*t - 45*Ds*s^4*t - 
      36*Nf*s^4*t + 6*Ds*Nf*s^4*t + (96*I)*Pi*s^4*t - (18*I)*Ds*Pi*s^4*t + 
      (24*I)*Nf*Pi*s^4*t + (3*I)*Ds*Nf*Pi*s^4*t + 734*s^3*t^2 - 
      79*Ds*s^3*t^2 - 166*Nf*s^3*t^2 + 18*Ds*Nf*s^3*t^2 + 
      (408*I)*Pi*s^3*t^2 - (138*I)*Ds*Pi*s^3*t^2 + (132*I)*Nf*Pi*s^3*t^2 + 
      (12*I)*Ds*Nf*Pi*s^3*t^2 + 296*s^2*t^3 + 56*Ds*s^2*t^3 - 
      394*Nf*s^2*t^3 + 18*Ds*Nf*s^2*t^3 + (804*I)*Pi*s^2*t^3 - 
      (270*I)*Ds*Pi*s^2*t^3 + (324*I)*Nf*Pi*s^2*t^3 + 
      (15*I)*Ds*Nf*Pi*s^2*t^3 - 232*s*t^4 + 164*Ds*s*t^4 - 412*Nf*s*t^4 + 
      6*Ds*Nf*s*t^4 + (492*I)*Pi*s*t^4 - (198*I)*Ds*Pi*s*t^4 + 
      (312*I)*Nf*Pi*s*t^4 + (6*I)*Ds*Nf*Pi*s*t^4 - 146*t^5 + 73*Ds*t^5 - 
      146*Nf*t^5 + (96*I)*Pi*t^5 - (48*I)*Ds*Pi*t^5 + (96*I)*Nf*Pi*t^5)*
     Log[-u]^2)/(3*s^3*(s + t)) + 
   (4*(-56*s^5 - 72*s^4*t - 12*Ds*s^4*t + 18*Nf*s^4*t + 2*Ds*Nf*s^4*t + 
      172*s^3*t^2 - 94*Ds*s^3*t^2 + 128*Nf*s^3*t^2 + 7*Ds*Nf*s^3*t^2 + 
      480*s^2*t^3 - 216*Ds*s^2*t^3 + 350*Nf*s^2*t^3 + 7*Ds*Nf*s^2*t^3 + 
      440*s*t^4 - 204*Ds*s*t^4 + 380*Nf*s*t^4 + 2*Ds*Nf*s*t^4 + 140*t^5 - 
      70*Ds*t^5 + 140*Nf*t^5)*Log[-u]^3)/(3*s^3*(s + t)) + 
   (8*((48*I)*Pi*s^3 - 40*s^2*t - 4*Ds*s^2*t + 20*Nf*s^2*t + 
      (24*I)*Pi*s^2*t - (18*I)*Nf*Pi*s^2*t + 6*s*t^2 - 3*Ds*s*t^2 + 
      6*Nf*s*t^2 - (36*I)*Pi*s*t^2 + (18*I)*Ds*Pi*s*t^2 - 
      (36*I)*Nf*Pi*s*t^2 - 186*t^3 + 45*Ds*t^3 - 6*Nf*t^3 - 6*Ds*Nf*t^3 - 
      (36*I)*Pi*t^3 + (18*I)*Ds*Pi*t^3 - (36*I)*Nf*Pi*t^3)*
     PolyLog[2, -(t/s)])/(3*s^2) + 
   Log[-u]*((-4*((-4*I)*Pi*s^5 + (2*I)*Ds*Pi*s^5 - (4*I)*Nf*Pi*s^5 + 
        56*Pi^2*s^5 - 44*s^4*t + 22*Ds*s^4*t - 44*Nf*s^4*t - 
        (164*I)*Pi*s^4*t + (10*I)*Ds*Pi*s^4*t + (16*I)*Nf*Pi*s^4*t + 
        96*Pi^2*s^4*t + 6*Nf*Pi^2*s^4*t - 586*s^3*t^2 + 197*Ds*s^3*t^2 - 
        226*Nf*s^3*t^2 - 12*Ds*Nf*s^3*t^2 - (60*I)*Pi*s^3*t^2 - 
        (42*I)*Ds*Pi*s^3*t^2 + (120*I)*Nf*Pi*s^3*t^2 + 60*Pi^2*s^3*t^2 - 
        6*Ds*Pi^2*s^3*t^2 - 8*Nf*Pi^2*s^3*t^2 + 2*Ds*Nf*Pi^2*s^3*t^2 - 
        1084*s^2*t^3 + 350*Ds*s^2*t^3 - 364*Nf*s^2*t^3 - 24*Ds*Nf*s^2*t^3 + 
        (592*I)*Pi*s^2*t^3 - (200*I)*Ds*Pi*s^2*t^3 + (232*I)*Nf*Pi*s^2*t^3 + 
        (12*I)*Ds*Nf*Pi*s^2*t^3 + 68*Pi^2*s^2*t^3 + 10*Ds*Pi^2*s^2*t^3 - 
        102*Nf*Pi^2*s^2*t^3 + 6*Ds*Nf*Pi^2*s^2*t^3 - 542*s*t^4 + 
        175*Ds*s*t^4 - 182*Nf*s*t^4 - 12*Ds*Nf*s*t^4 + (488*I)*Pi*s*t^4 - 
        (148*I)*Ds*Pi*s*t^4 + (128*I)*Nf*Pi*s*t^4 + (12*I)*Ds*Nf*Pi*s*t^4 - 
        36*Pi^2*s*t^4 + 50*Ds*Pi^2*s*t^4 - 156*Nf*Pi^2*s*t^4 + 
        4*Ds*Nf*Pi^2*s*t^4 - 68*Pi^2*t^5 + 34*Ds*Pi^2*t^5 - 68*Nf*Pi^2*t^5))/
      (3*s^3*(s + t)) + (16*(8*s^5 + 20*s^4*t - Nf*s^4*t + 10*s^3*t^2 + 
        Ds*s^3*t^2 - 5*Nf*s^3*t^2 + 4*Ds*s^2*t^3 - 10*Nf*s^2*t^3 - 10*s*t^4 + 
        5*Ds*s*t^4 - 10*Nf*s*t^4 - 4*t^5 + 2*Ds*t^5 - 4*Nf*t^5)*
       PolyLog[2, -(t/s)])/(s^3*(s + t))) - 
   (8*(8*s^4*t - 8*Nf*s^4*t - 12*s^3*t^2 + 8*Ds*s^3*t^2 - 10*Nf*s^3*t^2 - 
      Ds*Nf*s^3*t^2 - 56*s^2*t^3 + 4*Ds*s^2*t^3 + 34*Nf*s^2*t^3 - 
      3*Ds*Nf*s^2*t^3 + 12*s*t^4 - 22*Ds*s*t^4 + 72*Nf*s*t^4 - 
      2*Ds*Nf*s*t^4 + 36*t^5 - 18*Ds*t^5 + 36*Nf*t^5)*PolyLog[3, -(t/s)])/
    (s^3*(s + t)) - (8*(-8*s^5 - 20*s^4*t - 12*s^3*t^2 + 14*Nf*s^3*t^2 - 
      Ds*Nf*s^3*t^2 - 24*s^2*t^3 - 12*Ds*s^2*t^3 + 66*Nf*s^2*t^3 - 
      3*Ds*Nf*s^2*t^3 + 28*s*t^4 - 30*Ds*s*t^4 + 88*Nf*s*t^4 - 
      2*Ds*Nf*s*t^4 + 36*t^5 - 18*Ds*t^5 + 36*Nf*t^5)*PolyLog[3, -(u/s)])/
    (s^3*(s + t)) + (4*((132*I)*Pi*s^5*t - (66*I)*Ds*Pi*s^5*t + 
      (132*I)*Nf*Pi*s^5*t - 144*Pi^2*s^5*t + 36*Nf*Pi^2*s^5*t + 
      (72*I)*Pi^3*s^5*t - (42*I)*Nf*Pi^3*s^5*t - 126*s^4*t^2 + 
      63*Ds*s^4*t^2 - 126*Nf*s^4*t^2 + (1626*I)*Pi*s^4*t^2 - 
      (525*I)*Ds*Pi*s^4*t^2 + (546*I)*Nf*Pi*s^4*t^2 + 
      (36*I)*Ds*Nf*Pi*s^4*t^2 + 48*Pi^2*s^4*t^2 + 12*Ds*Pi^2*s^4*t^2 - 
      102*Nf*Pi^2*s^4*t^2 + 6*Ds*Nf*Pi^2*s^4*t^2 + (144*I)*Pi^3*s^4*t^2 + 
      (42*I)*Ds*Pi^3*s^4*t^2 - (132*I)*Nf*Pi^3*s^4*t^2 - 
      (3*I)*Ds*Nf*Pi^3*s^4*t^2 - 252*s^3*t^3 + 126*Ds*s^3*t^3 - 
      252*Nf*s^3*t^3 + (2886*I)*Pi*s^3*t^3 - (867*I)*Ds*Pi*s^3*t^3 + 
      (726*I)*Nf*Pi*s^3*t^3 + (72*I)*Ds*Nf*Pi*s^3*t^3 + 180*Pi^2*s^3*t^3 + 
      126*Ds*Pi^2*s^3*t^3 - 480*Nf*Pi^2*s^3*t^3 + 12*Ds*Nf*Pi^2*s^3*t^3 - 
      (156*I)*Pi^3*s^3*t^3 + (96*I)*Ds*Pi^3*s^3*t^3 - 
      (78*I)*Nf*Pi^3*s^3*t^3 - (12*I)*Ds*Nf*Pi^3*s^3*t^3 - 126*s^2*t^4 + 
      63*Ds*s^2*t^4 - 126*Nf*s^2*t^4 + (1392*I)*Pi*s^2*t^4 - 
      (408*I)*Ds*Pi*s^2*t^4 + (312*I)*Nf*Pi*s^2*t^4 + 
      (36*I)*Ds*Nf*Pi*s^2*t^4 - 398*Pi^2*s^2*t^4 + 307*Ds*Pi^2*s^2*t^4 - 
      728*Nf*Pi^2*s^2*t^4 + 6*Ds*Nf*Pi^2*s^2*t^4 - (252*I)*Pi^3*s^2*t^4 + 
      (18*I)*Ds*Pi^3*s^2*t^4 + (168*I)*Nf*Pi^3*s^2*t^4 - 
      (15*I)*Ds*Nf*Pi^3*s^2*t^4 - 520*Pi^2*s*t^5 + 260*Ds*Pi^2*s*t^5 - 
      520*Nf*Pi^2*s*t^5 + (72*I)*Pi^3*s*t^5 - (84*I)*Ds*Pi^3*s*t^5 + 
      (252*I)*Nf*Pi^3*s*t^5 - (6*I)*Ds*Nf*Pi^3*s*t^5 - 146*Pi^2*t^6 + 
      73*Ds*Pi^2*t^6 - 146*Nf*Pi^2*t^6 + (96*I)*Pi^3*t^6 - 
      (48*I)*Ds*Pi^3*t^6 + (96*I)*Nf*Pi^3*t^6 - 144*s^6*Zeta[3] - 
      504*s^5*t*Zeta[3] - 360*s^4*t^2*Zeta[3]))/(9*s^3*(s + t)^2)) + 
 Log[s]*((-8*(4*s^4*t - 4*Nf*s^4*t - 4*s^3*t^2 + 4*Ds*s^3*t^2 - 
      9*Nf*s^3*t^2 - 22*s^2*t^3 + 5*Ds*s^2*t^3 - 7*Nf*s^2*t^3 + 4*s*t^4 - 
      2*Ds*s*t^4 + 4*Nf*s*t^4 + 6*t^5 - 3*Ds*t^5 + 6*Nf*t^5)*Log[-t]^3)/
    (3*s^3*(s + t)) + (4*(6*s^5 - 3*Ds*s^5 + 6*Nf*s^5 + 88*s^4*t - 
      8*Ds*s^4*t - 2*Nf*s^4*t - (12*I)*Pi*s^4*t - 266*s^3*t^2 + 
      85*Ds*s^3*t^2 - 26*Nf*s^3*t^2 - 12*Ds*Nf*s^3*t^2 - (60*I)*Pi*s^3*t^2 - 
      (24*I)*Nf*Pi*s^3*t^2 - 1174*s^2*t^3 + 311*Ds*s^2*t^3 - 124*Nf*s^2*t^3 - 
      36*Ds*Nf*s^2*t^3 + (24*I)*Ds*Pi*s^2*t^3 - (72*I)*Nf*Pi*s^2*t^3 - 
      1256*s*t^4 + 340*Ds*s*t^4 - 176*Nf*s*t^4 - 36*Ds*Nf*s*t^4 - 
      (96*I)*Pi*s*t^4 + (48*I)*Ds*Pi*s*t^4 - (96*I)*Nf*Pi*s*t^4 - 430*t^5 + 
      119*Ds*t^5 - 70*Nf*t^5 - 12*Ds*Nf*t^5 - (48*I)*Pi*t^5 + 
      (24*I)*Ds*Pi*t^5 - (48*I)*Nf*Pi*t^5)*Log[-u]^2)/(3*s^2*t*(s + t)) + 
   (8*(12*s^4 - 4*s^3*t - 5*Nf*s^3*t + 2*s^2*t^2 + 5*Ds*s^2*t^2 - 
      13*Nf*s^2*t^2 - 16*s*t^3 + 8*Ds*s*t^3 - 16*Nf*s*t^3 - 6*t^4 + 
      3*Ds*t^4 - 6*Nf*t^4)*Log[-u]^3)/(3*s^3) + 
   Log[-t]^2*((4*(52*s^4*t - 2*Ds*s^4*t - 8*Nf*s^4*t + (12*I)*Pi*s^4*t + 
        (12*I)*Nf*Pi*s^4*t + 128*s^3*t^2 + 20*Ds*s^3*t^2 - 82*Nf*s^3*t^2 + 
        (36*I)*Pi*s^3*t^2 - (12*I)*Ds*Pi*s^3*t^2 + (48*I)*Nf*Pi*s^3*t^2 - 
        22*s^2*t^3 + 71*Ds*s^2*t^3 - 172*Nf*s^2*t^3 + (72*I)*Pi*s^2*t^3 - 
        (36*I)*Ds*Pi*s^2*t^3 + (84*I)*Nf*Pi*s^2*t^3 - 162*s*t^4 + 
        81*Ds*s*t^4 - 162*Nf*s*t^4 + (72*I)*Pi*s*t^4 - (36*I)*Ds*Pi*s*t^4 + 
        (72*I)*Nf*Pi*s*t^4 - 58*t^5 + 29*Ds*t^5 - 58*Nf*t^5 + (24*I)*Pi*t^5 - 
        (12*I)*Ds*Pi*t^5 + (24*I)*Nf*Pi*t^5))/(3*s^2*(s + t)^2) + 
     (8*(-12*s^5 - 20*s^4*t + Nf*s^4*t - 10*s^3*t^2 - Ds*s^3*t^2 + 
        18*Nf*s^3*t^2 - Ds*Nf*s^3*t^2 - 22*s^2*t^3 - 15*Ds*s^2*t^3 + 
        73*Nf*s^2*t^3 - 3*Ds*Nf*s^2*t^3 + 34*s*t^4 - 33*Ds*s*t^4 + 
        94*Nf*s*t^4 - 2*Ds*Nf*s*t^4 + 38*t^5 - 19*Ds*t^5 + 38*Nf*t^5)*
       Log[-u])/(s^3*(s + t))) + 
   (16*((-8*I)*Pi*s^3 - 32*s^2*t + 8*Ds*s^2*t - 2*Nf*s^2*t - Ds*Nf*s^2*t - 
      (16*I)*Pi*s^2*t - 96*s*t^2 + 24*Ds*s*t^2 - 6*Nf*s*t^2 - 3*Ds*Nf*s*t^2 - 
      64*t^3 + 16*Ds*t^3 - 4*Nf*t^3 - 2*Ds*Nf*t^3)*PolyLog[2, -(t/s)])/
    (s*(s + t)) + Log[-t]*
    ((4*((-4*I)*Pi*s^6 + (2*I)*Ds*Pi*s^6 - (4*I)*Nf*Pi*s^6 + 56*Pi^2*s^6 - 
        44*s^5*t + 22*Ds*s^5*t - 44*Nf*s^5*t - (168*I)*Pi*s^5*t + 
        (12*I)*Ds*Pi*s^5*t + (12*I)*Nf*Pi*s^5*t + 152*Pi^2*s^5*t + 
        6*Nf*Pi^2*s^5*t - 542*s^4*t^2 + 175*Ds*s^4*t^2 - 182*Nf*s^4*t^2 - 
        12*Ds*Nf*s^4*t^2 - (212*I)*Pi*s^4*t^2 + (34*I)*Ds*Pi*s^4*t^2 - 
        (32*I)*Nf*Pi*s^4*t^2 + 120*Pi^2*s^4*t^2 - 6*Ds*Pi^2*s^4*t^2 + 
        4*Nf*Pi^2*s^4*t^2 + Ds*Nf*Pi^2*s^4*t^2 - 962*s^3*t^3 + 
        289*Ds*s^3*t^3 - 242*Nf*s^3*t^3 - 24*Ds*Nf*s^3*t^3 - 
        (60*I)*Pi*s^3*t^3 + (30*I)*Ds*Pi*s^3*t^3 - (60*I)*Nf*Pi*s^3*t^3 + 
        84*Pi^2*s^3*t^3 - 62*Nf*Pi^2*s^3*t^3 + 4*Ds*Nf*Pi^2*s^3*t^3 - 
        464*s^2*t^4 + 136*Ds*s^2*t^4 - 104*Nf*s^2*t^4 - 12*Ds*Nf*s^2*t^4 - 
        (24*I)*Pi*s^2*t^4 + (12*I)*Ds*Pi*s^2*t^4 - (24*I)*Nf*Pi*s^2*t^4 + 
        20*Pi^2*s^2*t^4 + 42*Ds*Pi^2*s^2*t^4 - 160*Nf*Pi^2*s^2*t^4 + 
        5*Ds*Nf*Pi^2*s^2*t^4 - 88*Pi^2*s*t^5 + 60*Ds*Pi^2*s*t^5 - 
        148*Nf*Pi^2*s*t^5 + 2*Ds*Nf*Pi^2*s*t^5 - 48*Pi^2*t^6 + 
        24*Ds*Pi^2*t^6 - 48*Nf*Pi^2*t^6))/(3*s^3*(s + t)^2) + 
     (8*(-2*s^4 + Ds*s^4 - 2*Nf*s^4 - (48*I)*Pi*s^4 - 314*s^3*t + 
        49*Ds*s^3*t + 16*Nf*s^3*t - 6*Ds*Nf*s^3*t - (132*I)*Pi*s^3*t + 
        (18*I)*Ds*Pi*s^3*t - (12*I)*Nf*Pi*s^3*t - (3*I)*Ds*Nf*Pi*s^3*t - 
        640*s^2*t^2 + 116*Ds*s^2*t^2 + 50*Nf*s^2*t^2 - 18*Ds*Nf*s^2*t^2 - 
        (444*I)*Pi*s^2*t^2 + (126*I)*Ds*Pi*s^2*t^2 - (60*I)*Nf*Pi*s^2*t^2 - 
        (15*I)*Ds*Nf*Pi*s^2*t^2 - 268*s*t^3 + 38*Ds*s*t^3 + 92*Nf*s*t^3 - 
        12*Ds*Nf*s*t^3 - (816*I)*Pi*s*t^3 + (216*I)*Ds*Pi*s*t^3 - 
        (96*I)*Nf*Pi*s*t^3 - (24*I)*Ds*Nf*Pi*s*t^3 + 58*t^4 - 29*Ds*t^4 + 
        58*Nf*t^4 - (408*I)*Pi*t^4 + (108*I)*Ds*Pi*t^4 - (48*I)*Nf*Pi*t^4 - 
        (12*I)*Ds*Nf*Pi*t^4)*Log[-u])/(3*s^2*(s + t)) + 
     (8*(8*s^5 - 20*s^4*t + 6*Ds*s^4*t - 6*Nf*s^4*t - Ds*Nf*s^4*t - 
        136*s^3*t^2 + 44*Ds*s^3*t^2 - 39*Nf*s^3*t^2 - 4*Ds*Nf*s^3*t^2 - 
        258*s^2*t^3 + 87*Ds*s^2*t^3 - 103*Nf*s^2*t^3 - 5*Ds*Nf*s^2*t^3 - 
        164*s*t^4 + 66*Ds*s*t^4 - 104*Nf*s*t^4 - 2*Ds*Nf*s*t^4 - 34*t^5 + 
        17*Ds*t^5 - 34*Nf*t^5)*Log[-u]^2)/(s^3*(s + t)) + 
     (16*(-8*s^3 - 4*s^2*t + 3*Nf*s^2*t + 6*s*t^2 - 3*Ds*s*t^2 + 6*Nf*s*t^2 + 
        6*t^3 - 3*Ds*t^3 + 6*Nf*t^3)*PolyLog[2, -(t/s)])/s^2) + 
   Log[-u]*((4*((12*I)*Pi*s^6 - (6*I)*Ds*Pi*s^6 + (12*I)*Nf*Pi*s^6 + 
        10*s^5*t - 5*Ds*s^5*t + 10*Nf*s^5*t + (172*I)*Pi*s^5*t - 
        (14*I)*Ds*Pi*s^5*t - (8*I)*Nf*Pi*s^5*t - 20*Pi^2*s^5*t + 
        440*s^4*t^2 - 124*Ds*s^4*t^2 + 80*Nf*s^4*t^2 + 12*Ds*Nf*s^4*t^2 - 
        (208*I)*Pi*s^4*t^2 + (80*I)*Ds*Pi*s^4*t^2 - (28*I)*Nf*Pi*s^4*t^2 - 
        (12*I)*Ds*Nf*Pi*s^4*t^2 - 80*Pi^2*s^4*t^2 + 20*Nf*Pi^2*s^4*t^2 + 
        894*s^3*t^3 - 255*Ds*s^3*t^3 + 174*Nf*s^3*t^3 + 24*Ds*Nf*s^3*t^3 - 
        (1116*I)*Pi*s^3*t^3 + (270*I)*Ds*Pi*s^3*t^3 - (36*I)*Nf*Pi*s^3*t^3 - 
        (36*I)*Ds*Nf*Pi*s^3*t^3 - 52*Pi^2*s^3*t^3 - 20*Ds*Pi^2*s^3*t^3 + 
        56*Nf*Pi^2*s^3*t^3 + Ds*Nf*Pi^2*s^3*t^3 + 464*s^2*t^4 - 
        136*Ds*s^2*t^4 + 104*Nf*s^2*t^4 + 12*Ds*Nf*s^2*t^4 - 
        (744*I)*Pi*s^2*t^4 + (180*I)*Ds*Pi*s^2*t^4 - (24*I)*Nf*Pi*s^2*t^4 - 
        (24*I)*Ds*Nf*Pi*s^2*t^4 + 84*Pi^2*s^2*t^4 - 38*Ds*Pi^2*s^2*t^4 + 
        44*Nf*Pi^2*s^2*t^4 + 3*Ds*Nf*Pi^2*s^2*t^4 + 52*Pi^2*s*t^5 - 
        10*Ds*Pi^2*s*t^5 - 8*Nf*Pi^2*s*t^5 + 2*Ds*Nf*Pi^2*s*t^5 - 
        16*Pi^2*t^6 + 8*Ds*Pi^2*t^6 - 16*Nf*Pi^2*t^6))/(3*s^3*t*(s + t)) + 
     (16*(-4*s^3*t - 3*Nf*s^3*t - 2*s^2*t^2 + 3*Ds*s^2*t^2 - 9*Nf*s^2*t^2 - 
        12*s*t^3 + 6*Ds*s*t^3 - 12*Nf*s*t^3 - 6*t^4 + 3*Ds*t^4 - 6*Nf*t^4)*
       PolyLog[2, -(t/s)])/(s^2*(s + t))) - 
   (8*(-16*s^4 - 8*s^3*t - 6*Ds*s^3*t + 6*Nf*s^3*t + Ds*Nf*s^3*t + 
      144*s^2*t^2 - 44*Ds*s^2*t^2 + 26*Nf*s^2*t^2 + 5*Ds*Nf*s^2*t^2 + 
      280*s*t^3 - 76*Ds*s*t^3 + 40*Nf*s*t^3 + 8*Ds*Nf*s*t^3 + 140*t^4 - 
      38*Ds*t^4 + 20*Nf*t^4 + 4*Ds*Nf*t^4)*PolyLog[3, -(t/s)])/
    (s^2*(s + t)) - (8*(-4*s^4 + 16*s^3*t - 6*Ds*s^3*t + 6*Nf*s^3*t + 
      Ds*Nf*s^3*t + 144*s^2*t^2 - 44*Ds*s^2*t^2 + 26*Nf*s^2*t^2 + 
      5*Ds*Nf*s^2*t^2 + 280*s*t^3 - 76*Ds*s*t^3 + 40*Nf*s*t^3 + 
      8*Ds*Nf*s*t^3 + 140*t^4 - 38*Ds*t^4 + 20*Nf*t^4 + 4*Ds*Nf*t^4)*
     PolyLog[3, -(u/s)])/(s^2*(s + t)) + 
   (4*(-12*Pi^2*s^6 + 6*Ds*Pi^2*s^6 - 12*Nf*Pi^2*s^6 + (30*I)*Pi*s^5*t - 
      (15*I)*Ds*Pi*s^5*t + (30*I)*Nf*Pi*s^5*t - 180*Pi^2*s^5*t + 
      18*Ds*Pi^2*s^5*t - (108*I)*Pi^3*s^5*t - 126*s^4*t^2 + 63*Ds*s^4*t^2 - 
      126*Nf*s^4*t^2 + (1146*I)*Pi*s^4*t^2 - (285*I)*Ds*Pi*s^4*t^2 + 
      (66*I)*Nf*Pi*s^4*t^2 + (36*I)*Ds*Nf*Pi*s^4*t^2 + 338*Pi^2*s^4*t^2 - 
      61*Ds*Pi^2*s^4*t^2 - 52*Nf*Pi^2*s^4*t^2 + 12*Ds*Nf*Pi^2*s^4*t^2 - 
      (192*I)*Pi^3*s^4*t^2 - (18*I)*Ds*Pi^3*s^4*t^2 + 
      (54*I)*Nf*Pi^3*s^4*t^2 + (3*I)*Ds*Nf*Pi^3*s^4*t^2 - 252*s^3*t^3 + 
      126*Ds*s^3*t^3 - 252*Nf*s^3*t^3 + (2232*I)*Pi*s^3*t^3 - 
      (540*I)*Ds*Pi*s^3*t^3 + (72*I)*Nf*Pi*s^3*t^3 + 
      (72*I)*Ds*Nf*Pi*s^3*t^3 + 1432*Pi^2*s^3*t^3 - 260*Ds*Pi^2*s^3*t^3 - 
      68*Nf*Pi^2*s^3*t^3 + 36*Ds*Nf*Pi^2*s^3*t^3 + (276*I)*Pi^3*s^3*t^3 - 
      (186*I)*Ds*Pi^3*s^3*t^3 + (240*I)*Nf*Pi^3*s^3*t^3 + 
      (18*I)*Ds*Nf*Pi^3*s^3*t^3 - 126*s^2*t^4 + 63*Ds*s^2*t^4 - 
      126*Nf*s^2*t^4 + (1116*I)*Pi*s^2*t^4 - (270*I)*Ds*Pi*s^2*t^4 + 
      (36*I)*Nf*Pi*s^2*t^4 + (36*I)*Ds*Nf*Pi*s^2*t^4 + 1514*Pi^2*s^2*t^4 - 
      337*Ds*Pi^2*s^2*t^4 + 44*Nf*Pi^2*s^2*t^4 + 42*Ds*Nf*Pi^2*s^2*t^4 + 
      (1344*I)*Pi^3*s^2*t^4 - (468*I)*Ds*Pi^3*s^2*t^4 + 
      (450*I)*Nf*Pi^3*s^2*t^4 + (39*I)*Ds*Nf*Pi^3*s^2*t^4 + 804*Pi^2*s*t^5 - 
      210*Ds*Pi^2*s*t^5 + 84*Nf*Pi^2*s*t^5 + 24*Ds*Nf*Pi^2*s*t^5 + 
      (1476*I)*Pi^3*s*t^5 - (450*I)*Ds*Pi^3*s*t^5 + (396*I)*Nf*Pi^3*s*t^5 + 
      (36*I)*Ds*Nf*Pi^3*s*t^5 + 204*Pi^2*t^6 - 54*Ds*Pi^2*t^6 + 
      24*Nf*Pi^2*t^6 + 6*Ds*Nf*Pi^2*t^6 + (492*I)*Pi^3*t^6 - 
      (150*I)*Ds*Pi^3*t^6 + (132*I)*Nf*Pi^3*t^6 + (12*I)*Ds*Nf*Pi^3*t^6 - 
      72*s^5*t*Zeta[3] - 72*s^4*t^2*Zeta[3]))/(9*s^2*t*(s + t)^2)) + 
 Log[-u]*((8*(232*s^3*t - 44*Ds*s^3*t - 8*Nf*s^3*t + 6*Ds*Nf*s^3*t + 
      (24*I)*Pi*s^3*t + (18*I)*Nf*Pi*s^3*t + 610*s^2*t^2 - 137*Ds*s^2*t^2 + 
      10*Nf*s^2*t^2 + 18*Ds*Nf*s^2*t^2 + (12*I)*Pi*s^2*t^2 - 
      (18*I)*Ds*Pi*s^2*t^2 + (54*I)*Nf*Pi*s^2*t^2 + 564*s*t^3 - 
      138*Ds*s*t^3 + 24*Nf*s*t^3 + 18*Ds*Nf*s*t^3 + (72*I)*Pi*s*t^3 - 
      (36*I)*Ds*Pi*s*t^3 + (72*I)*Nf*Pi*s*t^3 + 186*t^4 - 45*Ds*t^4 + 
      6*Nf*t^4 + 6*Ds*Nf*t^4 + (36*I)*Pi*t^4 - (18*I)*Ds*Pi*t^4 + 
      (36*I)*Nf*Pi*t^4)*PolyLog[2, -(t/s)])/(3*s^2*(s + t)) - 
   (8*(16*s^5 + 6*Ds*s^4*t + 2*Nf*s^4*t - Ds*Nf*s^4*t - 132*s^3*t^2 + 
      36*Ds*s^3*t^2 - 16*Nf*s^3*t^2 - 4*Ds*Nf*s^3*t^2 - 224*s^2*t^3 + 
      72*Ds*s^2*t^3 - 74*Nf*s^2*t^3 - 5*Ds*Nf*s^2*t^3 - 152*s*t^4 + 
      60*Ds*s*t^4 - 92*Nf*s*t^4 - 2*Ds*Nf*s*t^4 - 36*t^5 + 18*Ds*t^5 - 
      36*Nf*t^5)*PolyLog[3, -(t/s)])/(s^3*(s + t)) - 
   (8*(12*s^4 - 8*s^3*t + 6*Ds*s^3*t - 6*Nf*s^3*t - Ds*Nf*s^3*t - 
      124*s^2*t^2 + 38*Ds*s^2*t^2 - 34*Nf*s^2*t^2 - 3*Ds*Nf*s^2*t^2 - 
      132*s*t^3 + 50*Ds*s*t^3 - 72*Nf*s*t^3 - 2*Ds*Nf*s*t^3 - 36*t^4 + 
      18*Ds*t^4 - 36*Nf*t^4)*PolyLog[3, -(u/s)])/s^3 + 
   (4*(12*Pi^2*s^6 - 6*Ds*Pi^2*s^6 + 12*Nf*Pi^2*s^6 - (30*I)*Pi*s^5*t + 
      (15*I)*Ds*Pi*s^5*t - (30*I)*Nf*Pi*s^5*t + 168*Pi^2*s^5*t - 
      12*Ds*Pi^2*s^5*t - 12*Nf*Pi^2*s^5*t + (108*I)*Pi^3*s^5*t + 
      126*s^4*t^2 - 63*Ds*s^4*t^2 + 126*Nf*s^4*t^2 - (1320*I)*Pi*s^4*t^2 + 
      (372*I)*Ds*Pi*s^4*t^2 - (240*I)*Nf*Pi*s^4*t^2 - 
      (36*I)*Ds*Nf*Pi*s^4*t^2 - 362*Pi^2*s^4*t^2 + 73*Ds*Pi^2*s^4*t^2 + 
      28*Nf*Pi^2*s^4*t^2 - 12*Ds*Nf*Pi^2*s^4*t^2 + (156*I)*Pi^3*s^4*t^2 + 
      (18*I)*Ds*Pi^3*s^4*t^2 - (48*I)*Nf*Pi^3*s^4*t^2 - 
      (3*I)*Ds*Nf*Pi^3*s^4*t^2 + 252*s^3*t^3 - 126*Ds*s^3*t^3 + 
      252*Nf*s^3*t^3 - (2682*I)*Pi*s^3*t^3 + (765*I)*Ds*Pi*s^3*t^3 - 
      (522*I)*Nf*Pi*s^3*t^3 - (72*I)*Ds*Nf*Pi*s^3*t^3 - 1118*Pi^2*s^3*t^3 + 
      175*Ds*Pi^2*s^3*t^3 + 142*Nf*Pi^2*s^3*t^3 - 30*Ds*Nf*Pi^2*s^3*t^3 - 
      (360*I)*Pi^3*s^3*t^3 + (162*I)*Ds*Pi^3*s^3*t^3 - 
      (204*I)*Nf*Pi^3*s^3*t^3 - (12*I)*Ds*Nf*Pi^3*s^3*t^3 + 126*s^2*t^4 - 
      63*Ds*s^2*t^4 + 126*Nf*s^2*t^4 - (1392*I)*Pi*s^2*t^4 + 
      (408*I)*Ds*Pi*s^2*t^4 - (312*I)*Nf*Pi*s^2*t^4 - 
      (36*I)*Ds*Nf*Pi*s^2*t^4 - 576*Pi^2*s^2*t^4 + 36*Ds*Pi^2*s^2*t^4 + 
      294*Nf*Pi^2*s^2*t^4 - 24*Ds*Nf*Pi^2*s^2*t^4 - (900*I)*Pi^3*s^2*t^4 + 
      (318*I)*Ds*Pi^3*s^2*t^4 - (420*I)*Nf*Pi^3*s^2*t^4 - 
      (15*I)*Ds*Nf*Pi^3*s^2*t^4 + 170*Pi^2*s*t^5 - 133*Ds*Pi^2*s*t^5 + 
      350*Nf*Pi^2*s*t^5 - 6*Ds*Nf*Pi^2*s*t^5 - (540*I)*Pi^3*s*t^5 + 
      (222*I)*Ds*Pi^3*s*t^5 - (360*I)*Nf*Pi^3*s*t^5 - 
      (6*I)*Ds*Nf*Pi^3*s*t^5 + 146*Pi^2*t^6 - 73*Ds*Pi^2*t^6 + 
      146*Nf*Pi^2*t^6 - (96*I)*Pi^3*t^6 + (48*I)*Ds*Pi^3*t^6 - 
      (96*I)*Nf*Pi^3*t^6 + 216*s^5*t*Zeta[3] + 360*s^4*t^2*Zeta[3]))/
    (9*s^3*t*(s + t)))
