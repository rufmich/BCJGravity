(* Created with the Wolfram Language : www.wolfram.com *)
(2*M4tree*((-I)*Pi*s + t*(-Log[s] + Log[-t]) + u*(-Log[s] + Log[-u])))/ep + 
 M4tree*(-2*Log[s]*((-I)*Pi*s + t*(-Log[s] + Log[-t]) + 
     u*(-Log[s] + Log[-u])) + 
   s*((-2*t*(I*Pi - Log[s] + Log[-t])*(-Log[s] + Log[-u]))/s - 
     (2*u*(-Log[s] + Log[-t])*(I*Pi - Log[s] + Log[-u]))/s)) + 
 ep*M4tree*(2*(-1/12*Pi^2 + Log[s]^2/2)*((-I)*Pi*s + t*(-Log[s] + Log[-t]) + 
     u*(-Log[s] + Log[-u])) - 
   s*Log[s]*((-2*t*(I*Pi - Log[s] + Log[-t])*(-Log[s] + Log[-u]))/s - 
     (2*u*(-Log[s] + Log[-t])*(I*Pi - Log[s] + Log[-u]))/s) + 
   s*(-1/3*(t*(-Log[s] + Log[-t])^3)/s - I*Pi*(1 + t/s)*
      ((-2*Pi^2)/3 + (-Log[s] + Log[-t])^2) - (-Log[s] + Log[-t])*
      (I*Pi - Log[s] + Log[-t])*(-Log[s] + Log[-u]) - 
     (u*(-Log[s] + Log[-u])^3)/(3*s) - (-Log[s] + Log[-t])*
      (-Log[s] + Log[-u])*(I*Pi - Log[s] + Log[-u]) - 
     I*Pi*(1 + u/s)*((-2*Pi^2)/3 + (-Log[s] + Log[-u])^2) - 
     2*(2 + t/s)*((((-2*Pi^2)/3 + (-Log[s] + Log[-t])^2)*(-Log[s] + Log[-u]))/
        2 + (I*Pi - Log[s] + Log[-t])*(Pi^2/6 - (-Log[s] + Log[-t])*
          (-Log[s] + Log[-u]) - PolyLog[2, -(t/s)]) + PolyLog[3, -(t/s)] - 
       Zeta[3]/3) - 2*(2 + u/s)*
      (((-Log[s] + Log[-t])*((-2*Pi^2)/3 + (-Log[s] + Log[-u])^2))/2 + 
       (I*Pi - Log[s] + Log[-u])*PolyLog[2, -(t/s)] + PolyLog[3, -(u/s)] - 
       Zeta[3]/3)))
