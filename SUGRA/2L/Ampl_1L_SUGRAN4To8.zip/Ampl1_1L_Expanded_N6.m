(* Created with the Wolfram Language : www.wolfram.com *)
(2*M4tree*((-I)*Pi*s + t*(-Log[s] + Log[-t]) + u*(-Log[s] + Log[-u])))/ep + 
 M4tree*(-2*Log[s]*((-I)*Pi*s + t*(-Log[s] + Log[-t]) + 
     u*(-Log[s] + Log[-u])) + 
   s*((-2*t*(I*Pi - Log[s] + Log[-t])*(-Log[s] + Log[-u]))/s - 
     (2*u*(-Log[s] + Log[-t])*(I*Pi - Log[s] + Log[-u]))/s) + 
   s*(-1/2*(t*(1 + t/s)*(Pi^2 + (Log[-t] - Log[-u])^2))/s - 
     (u*(1 + u/s)*(Pi^2 + (-Log[-t] + Log[-u])^2))/(2*s))) + 
 ep*M4tree*(2*(-1/12*Pi^2 + Log[s]^2/2)*((-I)*Pi*s + t*(-Log[s] + Log[-t]) + 
     u*(-Log[s] + Log[-u])) - 
   Log[s]*(s*((-2*t*(I*Pi - Log[s] + Log[-t])*(-Log[s] + Log[-u]))/s - 
       (2*u*(-Log[s] + Log[-t])*(I*Pi - Log[s] + Log[-u]))/s) + 
     s*(-1/2*(t*(1 + t/s)*(Pi^2 + (Log[-t] - Log[-u])^2))/s - 
       (u*(1 + u/s)*(Pi^2 + (-Log[-t] + Log[-u])^2))/(2*s))) + 
   s*(-1/2*(Pi^2*(1 + (t*(1 + t/s))/s)) - (Pi^2*(1 + (u*(1 + u/s))/s))/2 - 
     (-((t*(I*Pi - Log[s] + Log[-t]))/s) + (1 + t/s)*(I*Pi - Log[s] + 
          Log[-u]))^2/2 - ((1 + u/s)*(I*Pi - Log[s] + Log[-t]) - 
        (u*(I*Pi - Log[s] + Log[-u]))/s)^2/2 - 
     (2*t*(1 + t/s)*(-1/2*(Pi^2*(-Log[s] + Log[-t])) - (-Log[s] + Log[-t])^3/
         3 - (-Log[s] + Log[-t])*PolyLog[2, -(t/s)] + PolyLog[3, -(t/s)]))/
      s - (2*u*(1 + u/s)*(-1/2*(Pi^2*(-Log[s] + Log[-u])) - 
        (-Log[s] + Log[-u])^3/3 - (-Log[s] + Log[-u])*
         (Pi^2/6 - (-Log[s] + Log[-t])*(-Log[s] + Log[-u]) - 
          PolyLog[2, -(t/s)]) + PolyLog[3, -(u/s)]))/s) + 
   s*(-1/3*(t*(-Log[s] + Log[-t])^3)/s - I*Pi*(1 + t/s)*
      ((-2*Pi^2)/3 + (-Log[s] + Log[-t])^2) - (-Log[s] + Log[-t])*
      (I*Pi - Log[s] + Log[-t])*(-Log[s] + Log[-u]) - 
     (u*(-Log[s] + Log[-u])^3)/(3*s) - (-Log[s] + Log[-t])*
      (-Log[s] + Log[-u])*(I*Pi - Log[s] + Log[-u]) - 
     I*Pi*(1 + u/s)*((-2*Pi^2)/3 + (-Log[s] + Log[-u])^2) - 
     2*(2 + t/s)*((((-2*Pi^2)/3 + (-Log[s] + Log[-t])^2)*(-Log[s] + Log[-u]))/
        2 + (I*Pi - Log[s] + Log[-t])*(Pi^2/6 - (-Log[s] + Log[-t])*
          (-Log[s] + Log[-u]) - PolyLog[2, -(t/s)]) + PolyLog[3, -(t/s)] - 
       Zeta[3]/3) - 2*(2 + u/s)*
      (((-Log[s] + Log[-t])*((-2*Pi^2)/3 + (-Log[s] + Log[-u])^2))/2 + 
       (I*Pi - Log[s] + Log[-u])*PolyLog[2, -(t/s)] + PolyLog[3, -(u/s)] - 
       Zeta[3]/3)))
